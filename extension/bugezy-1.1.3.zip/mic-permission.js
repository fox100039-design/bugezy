// src/types.ts
var LANG_KEY = "bugezy:language";
var MIC_KEY = "bugezy:mic-enabled";

// src/i18n.ts
function getUILang(speechLang) {
  if (speechLang === "zh" || speechLang === "yue") return "zh";
  return "en";
}
var dict = {
  // ── 登入 ──
  "login-hint": { zh: "\u767B\u5165\u5F8C\u958B\u59CB\u4F7F\u7528", en: "Sign in to get started" },
  "login-google": { zh: "\u7528 Google \u767B\u5165", en: "Sign in with Google" },
  "login-loading": { zh: "\u767B\u5165\u4E2D...", en: "Signing in..." },
  "login-failed": { zh: "\u767B\u5165\u5931\u6557\uFF0C\u91CD\u8A66", en: "Login failed, retry" },
  // ── 頂部 ──
  logout: { zh: "\u767B\u51FA", en: "Logout" },
  "voice-bug-report": { zh: "\u8A9E\u97F3 Bug \u56DE\u5831", en: "Voice Bug Report" },
  "voice-mode": { zh: "\u8A9E\u97F3\u6A21\u5F0F", en: "Voice Mode" },
  "mode-realtime": { zh: "\u5373\u6642\u5B57\u5E55", en: "Live Caption" },
  "mode-whisper": { zh: "\u7CBE\u6E96\u8F49\u9304", en: "Precise" },
  "settings-locked": { zh: "\u{1F512} \u9304\u88FD\u4E2D\uFF0C\u8A2D\u5B9A\u5DF2\u9396\u5B9A", en: "\u{1F512} Recording, settings locked" },
  // ── 三大模式卡片 ──
  "mode-record": { zh: "\u9304\u88FD", en: "Record" },
  "mode-record-desc": { zh: "DOM + \u8A9E\u97F3 + Console", en: "DOM + Voice + Console" },
  "mode-rewind": { zh: "\u56DE\u6EAF 30s", en: "Rewind 30s" },
  "mode-rewind-desc": { zh: "\u6293\u525B\u624D\u7684 Bug", en: "Catch recent Bug" },
  "mode-screenshot": { zh: "\u622A\u5716\u6A19\u6CE8", en: "Screenshot" },
  "mode-screenshot-desc": { zh: "\u5FEB\u901F\u64F7\u53D6 + \u756B\u91CD\u9EDE", en: "Capture + Annotate" },
  // ── 用量（動態）──
  unlimited: { zh: "\u2728 \u7121\u9650\u6B21", en: "\u2728 Unlimited" },
  remaining: { zh: "\u5269 {n} \u6B21", en: "{n} left" },
  "used-up": { zh: "\u5DF2\u7528\u5B8C\uFF08\u5347\u7D1A\u89E3\u9396\uFF09", en: "Used up (upgrade)" },
  // ── 日票 / 月費 ──
  "upgrade-unlock": { zh: "\u5347\u7D1A\u89E3\u9396\u7121\u9650\u6B21", en: "Upgrade for unlimited" },
  "my-reports": { zh: "\u{1F4CB} \u6211\u7684\u5831\u544A", en: "\u{1F4CB} My Reports" },
  // PM-184
  // PM-185：截圖敏感偵測 + 馬賽克
  "sf-password": { zh: "\u5BC6\u78BC\u6B04\u4F4D", en: "password fields" },
  "sf-token": { zh: "Token \u6B04\u4F4D", en: "token fields" },
  "sf-secret": { zh: "Secret \u6B04\u4F4D", en: "secret fields" },
  "sf-key": { zh: "API Key \u6B04\u4F4D", en: "API key fields" },
  "sf-card": { zh: "\u4FE1\u7528\u5361\u6B04\u4F4D", en: "credit card fields" },
  "sf-cvv": { zh: "CVV \u6B04\u4F4D", en: "CVV fields" },
  "sf-marked": { zh: "\u6A19\u8A18\u70BA\u654F\u611F\u7684\u5143\u7D20", en: "sensitive-marked elements" },
  "sensitive-sep": { zh: "\u3001", en: ", " },
  "sensitive-title": { zh: "\u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D", en: "Sensitive fields detected" },
  "sensitive-page-has": { zh: "\u9801\u9762\u4E0A\u6709\uFF1A{fields}", en: "This page contains: {fields}" },
  "sensitive-hint": {
    zh: "\u622A\u5716\u5F8C\u53EF\u7528 \u{1F512} \u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u654F\u611F\u5340\u57DF\u518D\u4E0A\u50B3",
    en: "Use the \u{1F512} mosaic brush to cover sensitive areas before uploading"
  },
  "sensitive-continue": { zh: "\u7E7C\u7E8C\u622A\u5716", en: "Continue" },
  "sensitive-cancel": { zh: "\u53D6\u6D88", en: "Cancel" },
  "sensitive-tip": {
    zh: "\u{1F512} \u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D\uFF0C\u5EFA\u8B70\u7528\u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u518D\u4E0A\u50B3",
    en: "\u{1F512} Sensitive fields detected \u2014 use the mosaic brush to cover them before uploading"
  },
  "annotate-mosaic": { zh: "\u{1F512} \u99AC\u8CFD\u514B", en: "\u{1F512} Mosaic" },
  // PM-186：自動遮罩
  "auto-masked": { zh: "\u{1F512} \u5DF2\u81EA\u52D5\u906E\u7F69 {n} \u500B\u654F\u611F\u6B04\u4F4D", en: "\u{1F512} Auto-masked {n} sensitive field(s)" },
  "undo-mask": { zh: "\u64A4\u92B7\u906E\u7F69", en: "Undo mask" },
  "day-pass-btn": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr\uFF09", en: "\u26A1 Day Pass NT$20 (24hr)" },
  "monthly-btn": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708", en: "\u2728 Monthly NT$80/mo" },
  // PM-170：用完升級引導 overlay
  "usage-exhausted": { zh: "\u672C\u6708\u984D\u5EA6\u5DF2\u7528\u5B8C", en: "Monthly quota exhausted" },
  "usage-desc-record": { zh: "\u9304\u88FD {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Recording {used}/{max} used" },
  "usage-desc-rewind": { zh: "\u56DE\u6EAF {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Rewind {used}/{max} used" },
  "usage-desc-mcp": { zh: "MCP AI \u8B80\u53D6 {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "MCP AI reads {used}/{max} used" },
  "usage-reset-hint": { zh: "\u{1F4A1} \u514D\u8CBB\u984D\u5EA6\u6BCF\u6708\u81EA\u52D5\u91CD\u7F6E", en: "\u{1F4A1} Free quota resets monthly" },
  "day-pass-btn-full": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr \u7121\u9650\uFF09", en: "\u26A1 Day Pass NT$20 (24hr unlimited)" },
  "monthly-btn-full": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708\uFF08\u6700\u5212\u7B97\uFF09", en: "\u2728 Monthly NT$80/mo (best value)" },
  // PM-171：非台灣付費 coming soon
  "intl-coming-soon": { zh: "\u{1F30F} \u570B\u969B\u4ED8\u6B3E\u5373\u5C07\u958B\u653E", en: "\u{1F30F} International Payments Coming Soon!" },
  "intl-desc": {
    zh: "\u6211\u5011\u6B63\u5728\u958B\u901A\u570B\u969B\u4FE1\u7528\u5361\u4ED8\u6B3E\uFF0C\u656C\u8ACB\u671F\u5F85\uFF01",
    en: "We're working on enabling international credit card payments. Stay tuned!"
  },
  "intl-free-hint": {
    zh: "\u{1F4A1} \u514D\u8CBB\u7248\u73FE\u5728\u5C31\u80FD\u7528 \u2014 \u6BCF\u6708 10 \u6B21\u9304\u88FD + 20 \u6B21 MCP AI \u8B80\u53D6",
    en: "\u{1F4A1} Free plan available now \u2014 10 recordings + 20 MCP AI reads per month"
  },
  "day-pass-badge": { zh: "\u26A1 \u65E5\u7968", en: "\u26A1 Day Pass" },
  "day-pass-remaining": { zh: "\u5269\u9918 {h}h {m}m {s}s", en: "{h}h {m}m {s}s left" },
  "day-pass-expire-hint": {
    zh: "\u65E5\u7968\u5230\u671F\u5F8C\u53EF\u5347\u7D1A\u6708\u8CBB",
    en: "Upgrade to monthly after day pass expires"
  },
  "paid-badge": { zh: "\u2728 \u4ED8\u8CBB\u7248\u6703\u54E1", en: "\u2728 Premium Member" },
  "cancel-sub": { zh: "\u53D6\u6D88\u8A02\u95B1", en: "Cancel" },
  "cancelled-prefix": { zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\uFF0C\u53EF\u7528\u5230", en: "Cancelled, active until" },
  resub: { zh: "\u91CD\u65B0\u8A02\u95B1", en: "Resubscribe" },
  // ── 進階設定 ──
  "lang-label": { zh: "\u{1F310} \u8A9E\u97F3\u8A9E\u8A00", en: "\u{1F310} Voice Language" },
  "advanced-settings": { zh: "\u2699\uFE0F \u9032\u968E\u8A2D\u5B9A", en: "\u2699\uFE0F Advanced Settings" },
  "monitor-toggle": { zh: "\u{1F50D} \u5373\u6642\u76E3\u63A7\uFF08AI \u53EF\u67E5 error\uFF09", en: "\u{1F50D} Live Monitor (AI reads errors)" },
  "keyboard-toggle": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F\uFF08\u95DC\u9589\u8A9E\u97F3\uFF09", en: "\u{1F507} Keyboard Mode (no voice)" },
  "hq-toggle": { zh: "\u{1F4F8} \u9AD8\u756B\u8CEA AI \u5206\u6790\uFF08\u9AD8 Token\uFF09", en: "\u{1F4F8} HQ AI Analysis (high Token)" },
  "effect-toggle": { zh: "\u2728 \u5DE5\u5177\u5217\u7279\u6548", en: "\u2728 Toolbar Effects" },
  // ── AI 輪盤 ──
  "carousel-title": { zh: "\u4E00\u9375\u8907\u88FD\u6307\u4EE4\u8CBC\u7D66 AI", en: "Copy prompt to AI" },
  "copy-btn": { zh: "\u8907\u88FD", en: "Copy" },
  "edit-btn": { zh: "\u270F\uFE0F \u7DE8\u8F2F", en: "\u270F\uFE0F Edit" },
  "save-btn": { zh: "\u{1F4BE} \u5132\u5B58", en: "\u{1F4BE} Save" },
  "cancel-btn": { zh: "\u53D6\u6D88", en: "Cancel" },
  // ── 錄製中 / 完成 ──
  "stop-recording": { zh: "\u23F9 \u505C\u6B62\u9304\u88FD", en: "\u23F9 Stop Recording" },
  "done-title": { zh: "\u2705 \u9304\u88FD\u5B8C\u6210\uFF01", en: "\u2705 Recording Done!" },
  "sum-dom": { zh: "DOM \u4E8B\u4EF6", en: "DOM Events" },
  "sum-console": { zh: "Console", en: "Console" },
  "sum-network": { zh: "Network \u932F\u8AA4", en: "Network Errors" },
  "sum-voice": { zh: "\u8A9E\u97F3\u7247\u6BB5", en: "Voice Clips" },
  "sum-time": { zh: "\u6642\u9593", en: "Duration" },
  "duration-sec": { zh: "{n} \u79D2", en: "{n}s" },
  "copy-json": { zh: "\u{1F4CB} \u8907\u88FD JSON", en: "\u{1F4CB} Copy JSON" },
  "export-json": { zh: "\u{1F4BE} \u532F\u51FA JSON\uFF08\u7D66 AI \u8B80\uFF09", en: "\u{1F4BE} Export JSON (for AI)" },
  "clear-restart": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\uFF0C\u91CD\u65B0\u9304\u88FD", en: "\u{1F5D1}\uFE0F Clear & Restart" },
  "copy-link": { zh: "\u{1F4CB} \u8907\u88FD\u9023\u7D50", en: "\u{1F4CB} Copy Link" },
  // PM-189：JSON 複製/匯出改付費功能 + 敏感資料免責警語
  "json-paid-only": { zh: "\u6B64\u70BA\u6703\u54E1\u9032\u968E\u529F\u80FD\uFF0C\u8ACB\u5347\u7D1A\u5F8C\u4F7F\u7528", en: "This is a member feature. Please upgrade to use." },
  "json-warning-title": { zh: "\u26A0\uFE0F JSON \u8CC7\u6599\u5305\u542B\u5B8C\u6574\u9664\u932F\u7D00\u9304", en: "\u26A0\uFE0F JSON data contains full debug records" },
  "json-warning-body": {
    zh: "\u6B64\u8CC7\u6599\u53EF\u80FD\u5305\u542B\u654F\u611F\u8CC7\u8A0A\uFF08API \u91D1\u9470\u3001Token\u3001\u932F\u8AA4\u8A0A\u606F\u7B49\uFF09\uFF0C\u8ACB\u52FF\u5C07 JSON \u8CC7\u6599\u5206\u4EAB\u7D66\u4E0D\u4FE1\u4EFB\u7684\u5C0D\u8C61\u3002\u56E0\u8CC7\u6599\u5916\u6D29\u9020\u6210\u7684\u640D\u5931\uFF0CBugEzy \u4E0D\u627F\u64D4\u8CAC\u4EFB\u3002",
    en: "This data may contain sensitive information (API keys, tokens, error messages, etc.). Do not share JSON data with untrusted parties. BugEzy is not responsible for any loss caused by data leakage."
  },
  "json-confirm": { zh: "\u6211\u4E86\u89E3\uFF0C\u7E7C\u7E8C", en: "I understand, continue" },
  "json-cancel": { zh: "\u53D6\u6D88", en: "Cancel" },
  "json-copy-locked": { zh: "\u{1F512} \u8907\u88FD JSON\uFF08\u6703\u54E1\uFF09", en: "\u{1F512} Copy JSON (member)" },
  "json-export-locked": { zh: "\u{1F512} \u532F\u51FA JSON\uFF08\u6703\u54E1\uFF09", en: "\u{1F512} Export JSON (member)" },
  // PM-191：一鍵複製 MCP 設定
  "copy-mcp": { zh: "\u{1F4CB} \u8907\u88FD MCP \u8A2D\u5B9A", en: "\u{1F4CB} Copy MCP Config" },
  "copy-mcp-done": { zh: "\u2705 \u5DF2\u8907\u88FD\uFF01\u8CBC\u5230 Claude/Cursor \u8A2D\u5B9A\u5373\u53EF", en: "\u2705 Copied! Paste into your Claude/Cursor settings" },
  "copy-mcp-login": { zh: "\u8ACB\u5148\u767B\u5165 BugEzy \u518D\u8907\u88FD MCP \u8A2D\u5B9A", en: "Please sign in to BugEzy before copying the MCP config" },
  "mcp-config-hint": { zh: "\u7576 AI \u7121\u6CD5\u8B80\u53D6\u4F60\u7684\u5831\u544A\u6642\uFF0C\u6309\u6B64\u8907\u88FD\uFF0C\u8CBC\u7D66\u4F60\u7684 AI \u91CD\u65B0\u8A2D\u5B9A", en: "If AI cannot read your reports, copy this and paste to your AI to reconfigure" },
  // PM-193：精準轉錄麥克風授權引導
  "mic-fallback-tip": {
    zh: "\u26A0\uFE0F \u7CBE\u6E96\u8F49\u9304\u9EA5\u514B\u98A8\u6388\u6B0A\u4E0D\u8DB3\uFF0C\u5DF2\u5207\u63DB\u70BA\u5373\u6642\u5B57\u5E55\u6A21\u5F0F\u3002\u4E0B\u6B21\u8ACB\u9078\u300C\u5141\u8A31\u9019\u500B\u7DB2\u7AD9\u4F7F\u7528\u300D\u3002",
    en: '\u26A0\uFE0F Whisper mic permission denied. Switched to realtime mode. Next time select "Always allow".'
  },
  "mic-perm-hint": {
    zh: "\u{1F4A1} \u7CBE\u6E96\u8F49\u9304\u9700\u9078\u300C\u6C38\u4E45\u5141\u8A31\u300D\u6B64\u7DB2\u7AD9\u4F7F\u7528\u9EA5\u514B\u98A8",
    en: '\u{1F4A1} Whisper requires "Always allow" microphone permission'
  },
  // ── mic OFF 提示 ──
  "mic-prompt-title": { zh: "\u9EA5\u514B\u98A8\u76EE\u524D\u95DC\u9589", en: "Microphone is off" },
  "mic-prompt-desc": { zh: "\u8981\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \u55CE\uFF1F", en: "Use voice to describe the bug?" },
  "mic-prompt-on": { zh: "\u958B\u555F\u4E26\u9304\u88FD", en: "Turn on & record" },
  "mic-prompt-skip": { zh: "\u76F4\u63A5\u9304\u88FD\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Record without voice" },
  // ── 版本（動態）──
  "update-available": {
    zh: "\u{1F195} \u76EE\u524D v{cur} \u2192 \u65B0\u7248 v{new} \u53EF\u7528",
    en: "\u{1F195} v{cur} \u2192 v{new} available"
  },
  // ── PM-139：截圖工具列（content.ts）──
  "toolbar-fullpage": { zh: "\u{1F4F7} \u6574\u9801", en: "\u{1F4F7} Full Page" },
  "toolbar-region": { zh: "\u2B1C \u5340\u57DF\uFF08\u5169\u9EDE\uFF09", en: "\u2B1C Region (2 clicks)" },
  "toolbar-freeform": { zh: "\u2702\uFE0F \u81EA\u7531\u5F62\u72C0", en: "\u2702\uFE0F Freeform" },
  "toolbar-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "toolbar-select-mode": { zh: "\u9078\u64C7\u622A\u5716\u6A21\u5F0F", en: "Select screenshot mode" },
  "toolbar-region-hint": { zh: "\u53EF\u81EA\u7531\u6372\u52D5\u9801\u9762\uFF0C\u9EDE\u7B2C\u4E8C\u4E0B\u6A19\u8A18\u7D42\u9EDE", en: "Scroll freely, click again to set the end point" },
  "transcribing": { zh: "\u23F3 \u8A9E\u97F3\u8F49\u9304\u4E2D\u2026", en: "\u23F3 Transcribing\u2026" },
  // ── PM-139：即時監控（inject.ts，經 it()）──
  "monitor-active": { zh: "\u{1F7E2} BugEzy \u76E3\u63A7\u4E2D", en: "\u{1F7E2} BugEzy Monitoring" },
  "monitor-errors": { zh: "\u26A0\uFE0F \u767C\u73FE {n} \u500B\u932F\u8AA4\uFF08\u9EDE\u6211\u67E5\u770B\uFF09", en: "\u26A0\uFE0F {n} error(s) found (click to view)" },
  "monitor-errors-title": { zh: "BugEzy \u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4\uFF0C\u9EDE\u6211\u67E5\u770B", en: "BugEzy found {n} error(s), click to view" },
  "monitor-panel-title": { zh: "\u{1F41B} \u5373\u6642\u76E3\u63A7\u932F\u8AA4", en: "\u{1F41B} Live Monitor Errors" },
  "monitor-empty": { zh: "\u2713 \u76EE\u524D\u7121\u932F\u8AA4", en: "\u2713 No errors" },
  "monitor-upload": { zh: "\u{1F4E4} \u4E0A\u50B3\u5831\u544A\u8B93 AI \u5206\u6790", en: "\u{1F4E4} Upload report for AI analysis" },
  "monitor-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D\u2026", en: "\u23F3 Uploading\u2026" },
  "monitor-uploaded": { zh: "\u2705 \u5DF2\u4E0A\u50B3\uFF01\u9EDE\u6B64\u67E5\u770B\u5831\u544A", en: "\u2705 Uploaded! Click to view report" },
  "monitor-upload-fail": { zh: "\u274C \u4E0A\u50B3\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66", en: "\u274C Upload failed, click to retry" },
  "monitor-desc": { zh: "\u5373\u6642\u76E3\u63A7\u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4", en: "Live monitor found {n} error(s)" },
  // ── PM-139：錄製字幕 / 麥克風授權（inject.ts，經 it()）──
  "caption-recording": { zh: "\u{1F399} \u9304\u88FD\u4E2D\uFF0C\u53EF\u4EE5\u7528\u4E2D\u6587\u63CF\u8FF0\u554F\u984C\u2026", en: "\u{1F399} Recording \u2014 describe the issue by voice\u2026" },
  "caption-voice-log": { zh: "\u{1F4DD} \u8A9E\u97F3\u8A18\u9304", en: "\u{1F4DD} Voice Log" },
  "keyboard-bar": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F \u2014 \u9304\u88FD\u4E2D\uFF08\u8A9E\u97F3\u5DF2\u95DC\u9589\uFF09", en: "\u{1F507} Keyboard mode \u2014 recording (voice off)" },
  "whisper-bar": { zh: "\u{1F399}\uFE0F \u9304\u97F3\u4E2D\u2026\uFF08\u505C\u6B62\u5F8C\u81EA\u52D5\u8F49\u9304\uFF09", en: "\u{1F399}\uFE0F Recording\u2026\uFF08auto-transcribe on stop\uFF09" },
  // PM-216：即時字幕浮動條狀態文字（inject.ts setVoiceStatus）
  "caption-listening": { zh: "\u{1F7E2} \u807D\u53D6\u4E2D\u2026", en: "\u{1F7E2} Listening\u2026" },
  "caption-restarting": { zh: "\u{1F7E1} \u91CD\u555F\u4E2D\u2026", en: "\u{1F7E1} Restarting\u2026" },
  "caption-stopped": { zh: "\u{1F534} \u5DF2\u505C\u6B62", en: "\u{1F534} Stopped" },
  "caption-note-restart": { zh: "\u6309 \u{1F504} \u91CD\u555F", en: "Press \u{1F504} to restart" },
  "caption-note-denied": { zh: "\u9EA5\u514B\u98A8\u88AB\u62D2\u7D55", en: "Microphone denied" },
  "caption-note-nocapture": { zh: "\u9EA5\u514B\u98A8\u7121\u6CD5\u64F7\u53D6\uFF0C\u8ACB\u6AA2\u67E5\u88DD\u7F6E", en: "Can't capture mic \u2014 check your device" },
  "caption-note-noaccess": { zh: "\u9EA5\u514B\u98A8\u7121\u6CD5\u5B58\u53D6", en: "Microphone unavailable" },
  "caption-note-restart-fail": { zh: "\u91CD\u555F\u5931\u6557\uFF0C\u8ACB\u91CD\u65B0\u6574\u7406\u9801\u9762", en: "Restart failed \u2014 please refresh the page" },
  // PM-216：麥克風授權頁（mic-permission）
  "mperm-title": { zh: "BugEzy \u9EA5\u514B\u98A8\u6388\u6B0A", en: "BugEzy Microphone Permission" },
  "mperm-h": { zh: "BugEzy \u9700\u8981\u9EA5\u514B\u98A8\u6B0A\u9650", en: "BugEzy needs microphone access" },
  "mperm-desc": {
    zh: "\u5141\u8A31\u5F8C\u5373\u53EF\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug\u3002<br />\u6B64\u6388\u6B0A\u53EA\u9700\u4E00\u6B21\uFF0C\u4E4B\u5F8C\u81EA\u52D5\u555F\u7528\u3002",
    en: "Allow access to describe bugs by voice.<br />One-time only \u2014 enabled automatically afterwards."
  },
  "mperm-requesting": { zh: "\u6B63\u5728\u8ACB\u6C42\u6388\u6B0A...", en: "Requesting permission\u2026" },
  "mperm-granted": {
    zh: "\u2705 \u9EA5\u514B\u98A8\u5DF2\u6388\u6B0A\u6210\u529F\uFF01\u6B64\u9801\u9762 3 \u79D2\u5F8C\u81EA\u52D5\u95DC\u9589...",
    en: "\u2705 Microphone granted! This page closes in 3 seconds\u2026"
  },
  "mperm-denied": {
    zh: "\u274C \u6388\u6B0A\u88AB\u62D2\u7D55\u3002\u8ACB\u5728\u700F\u89BD\u5668\u8A2D\u5B9A\u4E2D\u5141\u8A31\u9EA5\u514B\u98A8\u5F8C\u91CD\u8A66\u3002",
    en: "\u274C Permission denied. Please allow microphone in browser settings and retry."
  },
  "mic-perm-title": { zh: "BugEzy \u9700\u8981\u9EA5\u514B\u98A8\u6B0A\u9650", en: "BugEzy needs microphone access" },
  "mic-perm-desc": { zh: "\u5141\u8A31\u5F8C\u53EF\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \xB7 \u6B64\u7DB2\u7AD9\u53EA\u9700\u6388\u6B0A\u4E00\u6B21", en: "Allow to describe bugs by voice \xB7 one-time per site" },
  "mic-perm-allow": { zh: "\u5141\u8A31\u9EA5\u514B\u98A8", en: "Allow microphone" },
  "mic-perm-skip": { zh: "\u8DF3\u904E\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Skip (no voice)" },
  // ── PM-139：截圖標注頁（annotate）──
  "annotate-pen": { zh: "\u270F\uFE0F \u756B\u7B46", en: "\u270F\uFE0F Pen" },
  "annotate-arrow": { zh: "\u27A1\uFE0F \u7BAD\u982D", en: "\u27A1\uFE0F Arrow" },
  "annotate-rect": { zh: "\u2B1C \u6846\u6846", en: "\u2B1C Box" },
  "annotate-text": { zh: "\u{1F4DD} \u6587\u5B57", en: "\u{1F4DD} Text" },
  "annotate-color": { zh: "\u984F\u8272", en: "Color" },
  "annotate-thickness": { zh: "\u7C97\u7D30", en: "Width" },
  "annotate-thin": { zh: "\u7D30", en: "Thin" },
  "annotate-mid": { zh: "\u4E2D", en: "Medium" },
  "annotate-thick": { zh: "\u7C97", en: "Thick" },
  "annotate-undo": { zh: "\u21A9\uFE0F \u5FA9\u539F", en: "\u21A9\uFE0F Undo" },
  "annotate-clear": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\u5168\u90E8", en: "\u{1F5D1}\uFE0F Clear All" },
  "annotate-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "annotate-save": { zh: "\u2705 \u5B8C\u6210\u5132\u5B58", en: "\u2705 Save" },
  "annotate-next": { zh: "\u{1F4E4} \u4E0B\u4E00\u6B65", en: "\u{1F4E4} Next" },
  // PM-204：截圖標注完導到編輯報告頁
  "annotate-desc-label": { zh: "\u{1F4AC} \u554F\u984C\u63CF\u8FF0\uFF08\u9078\u586B\uFF09", en: "\u{1F4AC} Description (optional)" },
  "annotate-desc-ph": { zh: "\u63CF\u8FF0\u4F60\u770B\u5230\u7684\u554F\u984C\uFF0C\u6216\u6309\u53F3\u908A\u9EA5\u514B\u98A8\u8A9E\u97F3\u8F38\u5165...", en: "Describe the issue, or tap the mic on the right to dictate..." },
  "annotate-listening": { zh: "\u{1F534} \u8046\u807D\u4E2D\uFF0C\u908A\u756B\u908A\u8AAA\u63CF\u8FF0\u554F\u984C...", en: "\u{1F534} Listening \u2014 describe while you draw..." },
  "annotate-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D...", en: "\u23F3 Uploading..." },
  // ── PM-215：編輯報告頁（edit-report）i18n ──
  "er-tag": { zh: "\u5831\u544A\u7DE8\u8F2F", en: "Edit Report" },
  "er-summary-h": { zh: "\u{1F4CA} \u9304\u88FD\u6458\u8981", en: "\u{1F4CA} Recording Summary" },
  "er-marker-h": { zh: "\u{1F4CC} \u6642\u9593\u8EF8\u6A19\u8A18", en: "\u{1F4CC} Timeline Markers" },
  "er-clean": { zh: "\u{1F9F9} \u4E7E\u6DE8\u6A21\u5F0F", en: "\u{1F9F9} Clean View" },
  "er-mark": { zh: "\u{1F4CC} \u6A19\u8A18\u6B64\u523B", en: "\u{1F4CC} Mark Now" },
  "er-voice-h": { zh: "\u{1F3A4} \u8A9E\u97F3\u8A18\u9304\uFF08\u81EA\u52D5\u8FA8\u8B58\uFF09", en: "\u{1F3A4} Voice Transcript (auto)" },
  "er-ai-correct": { zh: "\u{1F527} AI \u6821\u6B63", en: "\u{1F527} AI Fix" },
  "er-ai-summarize": { zh: "\u{1F916} AI \u7CBE\u7C21", en: "\u{1F916} AI Summarize" },
  "er-voice-ph": { zh: "\uFF08\u9019\u6B21\u9304\u88FD\u6C92\u6709\u8A9E\u97F3\uFF09", en: "(No voice in this recording)" },
  "er-desc-h": { zh: "\u{1F4AC} \u88DC\u5145\u8AAA\u660E\uFF08\u9078\u586B\uFF09", en: "\u{1F4AC} Notes (optional)" },
  "er-desc-ph": { zh: "\u6253\u5B57\u6216\u6309\u53F3\u908A\u9EA5\u514B\u98A8\u8A9E\u97F3\u88DC\u5145...", en: "Type, or use the mic on the right to dictate..." },
  "er-token-h": { zh: "\u{1F4CA} Token \u4F30\u7B97", en: "\u{1F4CA} Token Estimate" },
  "er-discard": { zh: "\u2717 \u6368\u68C4\u5831\u544A", en: "\u2717 Discard" },
  "er-upload": { zh: "\u2705 \u4E0A\u50B3\u5831\u544A", en: "\u2705 Upload Report" },
  // dynamic
  "er-no-report": { zh: "\u627E\u4E0D\u5230\u5831\u544A\u8CC7\u6599", en: "Report data not found" },
  "er-row-screenshot": { zh: "\u622A\u5716", en: "Screenshots" },
  "er-row-dom": { zh: "DOM \u4E8B\u4EF6", en: "DOM events" },
  "er-row-voice": { zh: "\u8A9E\u97F3\u7247\u6BB5", en: "Voice segments" },
  "er-row-duration": { zh: "\u6642\u9577", en: "Duration" },
  "er-row-page": { zh: "\u9801\u9762", en: "Page" },
  "er-sec": { zh: "\u79D2", en: "s" },
  "er-screenshot-preview": { zh: "\u{1F4F8} \u622A\u5716\u9810\u89BD", en: "\u{1F4F8} Screenshot Preview" },
  "er-screenshot-voice": {
    zh: "\u{1F4F8} \u622A\u5716\u6A21\u5F0F\uFF1A\u8A9E\u97F3\u5167\u5BB9\u5DF2\u5305\u542B\u5728\u88DC\u5145\u8AAA\u660E\u4E2D",
    en: "\u{1F4F8} Screenshot mode: voice content is included in the description below."
  },
  "er-listening": { zh: "\u{1F534} \u8046\u807D\u4E2D...", en: "\u{1F534} Listening..." },
  "er-no-sr": { zh: "\u6B64\u700F\u89BD\u5668\u4E0D\u652F\u63F4\u8A9E\u97F3\u8FA8\u8B58", en: "Voice recognition not supported in this browser" },
  "er-no-mic": { zh: "\u274C \u9EA5\u514B\u98A8\u7121\u6CD5\u5B58\u53D6", en: "\u274C Microphone unavailable" },
  "er-restarted": { zh: "\u{1F534} \u8A9E\u97F3\u5DF2\u91CD\u555F...", en: "\u{1F534} Voice restarted..." },
  "er-voice-interrupted": { zh: "\u26A0 \u8A9E\u97F3\u4E2D\u65B7\uFF0C\u6309 \u{1F3A4} \u91CD\u65B0\u555F\u52D5", en: "\u26A0 Voice interrupted \u2014 press \u{1F3A4} to restart" },
  "er-voice-error": { zh: "\u8A9E\u97F3\u932F\u8AA4\uFF1A", en: "Voice error: " },
  "er-keyboard": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F", en: "\u{1F507} Keyboard mode" },
  "er-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D...", en: "\u23F3 Uploading..." },
  "er-uploaded": { zh: "\u2705 \u5DF2\u4E0A\u50B3\uFF01\u5206\u4EAB\u9023\u7D50\uFF1A", en: "\u2705 Uploaded! Share link: " },
  "er-copy-link": { zh: "\u8907\u88FD\u9023\u7D50", en: "Copy link" },
  "er-upload-done": { zh: "\u2705 \u5DF2\u4E0A\u50B3", en: "\u2705 Uploaded" },
  "er-close": { zh: "\u95DC\u9589", en: "Close" },
  "er-upload-fail": { zh: "\u274C \u4E0A\u50B3\u5931\u6557\uFF1A", en: "\u274C Upload failed: " },
  "er-unknown-err": { zh: "\u672A\u77E5\u932F\u8AA4\uFF0C\u8ACB\u91CD\u8A66", en: "Unknown error, please retry" },
  "er-correcting": { zh: "\u{1F527} \u6821\u6B63\u4E2D...", en: "\u{1F527} Fixing..." },
  "er-corrected": { zh: "\u2705 \u5DF2\u6821\u6B63", en: "\u2705 Fixed" },
  "er-correct-fail": { zh: "\u274C \u6821\u6B63\u5931\u6557", en: "\u274C Fix failed" },
  "er-too-short": { zh: "\u8A9E\u97F3\u8A18\u9304\u592A\u77ED\uFF0C\u7121\u9700\u7CBE\u7C21", en: "Transcript too short to summarize" },
  "er-summarizing": { zh: "\u{1F916} \u7CBE\u7C21\u4E2D...", en: "\u{1F916} Summarizing..." },
  "er-summarized": { zh: "\u2705 \u5DF2\u7CBE\u7C21\uFF08\u4E0D\u53EF\u91CD\u8907\uFF09", en: "\u2705 Summarized (once only)" },
  "er-fail": { zh: "\u274C \u5931\u6557", en: "\u274C Failed" },
  // Token 估算面板
  "er-tok-voice": { zh: "\u8A9E\u97F3\u8A18\u9304", en: "Voice transcript" },
  "er-tok-desc": { zh: "\u88DC\u5145\u8AAA\u660E", en: "Notes" },
  "er-tok-markers": { zh: "\u6642\u9593\u8EF8\u6A19\u8A18", en: "Timeline markers" },
  "er-tok-dom": { zh: "DOM \u6458\u8981", en: "DOM summary" },
  "er-tok-total": { zh: "AI \u8B80\u53D6\u7E3D\u8A08", en: "AI read total" },
  "er-tok-compare": { zh: "\u{1F4A1} \u540C\u5834\u666F Claude in Chrome\uFF1A", en: "\u{1F4A1} Same task with Claude in Chrome: " },
  "er-tok-saved": { zh: "\u2705 BugEzy \u70BA\u4F60\u7701\u4E86", en: "\u2705 BugEzy saves you" },
  // ── PM-139：alert / confirm（popup.ts）──
  "confirm-cancel-sub": {
    zh: "\u78BA\u5B9A\u8981\u53D6\u6D88\u6708\u8CBB\u8A02\u95B1\u55CE\uFF1F\n\u53D6\u6D88\u5F8C\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\uFF0C\u5230\u671F\u5F8C\u81EA\u52D5\u964D\u56DE\u514D\u8CBB\u7248\u3002",
    en: "Cancel your monthly subscription?\nYou can still use premium features until the end of your billing period."
  },
  "alert-cancelled": {
    zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\u3002\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\u3002",
    en: "Subscription cancelled. Premium features remain active until end of billing period."
  },
  "alert-cancel-fail": { zh: "\u53D6\u6D88\u5931\u6557\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66", en: "Cancellation failed, please try again later" }
};
function t(key, lang, params) {
  const entry = dict[key];
  let text = entry?.[lang] || entry?.["zh"] || key;
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      text = text.replace(`{${k}}`, String(v));
    }
  }
  return text;
}

// src/mic-permission.ts
(async () => {
  const langStore = await chrome.storage.local.get(LANG_KEY);
  const uiLang = getUILang(langStore[LANG_KEY] || "zh");
  const T = (key) => t(key, uiLang);
  document.title = T("mperm-title");
  const permH = document.getElementById("permH");
  if (permH) permH.textContent = T("mperm-h");
  const permDesc = document.getElementById("permDesc");
  if (permDesc) permDesc.innerHTML = T("mperm-desc");
  const status = document.getElementById("status");
  if (!status) return;
  status.textContent = T("mperm-requesting");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t2) => t2.stop());
    status.textContent = T("mperm-granted");
    status.style.color = "#3fb950";
    await chrome.runtime.sendMessage({ type: "MIC_PERMISSION_GRANTED" });
    await chrome.storage.local.set({ [MIC_KEY]: true });
    setTimeout(() => window.close(), 3e3);
  } catch {
    status.textContent = T("mperm-denied");
    status.style.color = "#f85149";
  }
})();
//# sourceMappingURL=mic-permission.js.map
