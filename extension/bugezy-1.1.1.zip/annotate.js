// src/types.ts
var API_BASE = "https://bugezy.dev";
var BUGEZY_DEBUG = true;
var SESSION_KEY = "bugezy:session";
var SESSION_TOKEN_KEY = "bugezy:session-token";
var LANG_KEY = "bugezy:language";
var KEYBOARD_MODE_KEY = "bugezy:keyboardMode";
var ALLOW_SCREENSHOT_KEY = "bugezy:allow-screenshot-images";
var TOOLBAR_EFFECT_KEY = "bugezy:toolbar-effect";
var MIC_MODE_KEY = "bugezy:mic-mode";
var USER_PLAN_KEY = "bugezy:user-plan";
function blog(...args) {
  if (BUGEZY_DEBUG) console.log("[BugEzy]", ...args);
}

// src/auth.ts
async function getAuthToken() {
  const store = await chrome.storage.local.get(SESSION_TOKEN_KEY);
  return store[SESSION_TOKEN_KEY];
}
async function getAuthHeaders() {
  const token = await getAuthToken();
  return {
    "Content-Type": "application/json",
    ...token ? { Authorization: `Bearer ${token}` } : {}
  };
}
async function getAuthHeaderOnly() {
  const token = await getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// src/i18n.ts
function getUILang(speechLang) {
  if (speechLang === "zh" || speechLang === "yue") return "zh";
  return "en";
}
var dict = {
  // ── 登入 ──
  "login-hint": { zh: "\u767B\u5165\u5F8C\u958B\u59CB\u4F7F\u7528", en: "Sign in to get started" },
  "login-google": { zh: "\u7528 Google \u767B\u5165", en: "Sign in with Google" },
  "login-loading": { zh: "\u767B\u5165\u4E2D...", en: "Signing in..." },
  "login-failed": { zh: "\u767B\u5165\u5931\u6557\uFF0C\u91CD\u8A66", en: "Login failed, retry" },
  // ── 頂部 ──
  logout: { zh: "\u767B\u51FA", en: "Logout" },
  "voice-bug-report": { zh: "\u8A9E\u97F3 Bug \u56DE\u5831", en: "Voice Bug Report" },
  "voice-mode": { zh: "\u8A9E\u97F3\u6A21\u5F0F", en: "Voice Mode" },
  "mode-realtime": { zh: "\u5373\u6642\u5B57\u5E55", en: "Live Caption" },
  "mode-whisper": { zh: "\u7CBE\u6E96\u8F49\u9304", en: "Precise" },
  "settings-locked": { zh: "\u{1F512} \u9304\u88FD\u4E2D\uFF0C\u8A2D\u5B9A\u5DF2\u9396\u5B9A", en: "\u{1F512} Recording, settings locked" },
  // ── 三大模式卡片 ──
  "mode-record": { zh: "\u9304\u88FD", en: "Record" },
  "mode-record-desc": { zh: "DOM + \u8A9E\u97F3 + Console", en: "DOM + Voice + Console" },
  "mode-rewind": { zh: "\u56DE\u6EAF 30s", en: "Rewind 30s" },
  "mode-rewind-desc": { zh: "\u6293\u525B\u624D\u7684 Bug", en: "Catch recent Bug" },
  "mode-screenshot": { zh: "\u622A\u5716\u6A19\u6CE8", en: "Screenshot" },
  "mode-screenshot-desc": { zh: "\u5FEB\u901F\u64F7\u53D6 + \u756B\u91CD\u9EDE", en: "Capture + Annotate" },
  // ── 用量（動態）──
  unlimited: { zh: "\u2728 \u7121\u9650\u6B21", en: "\u2728 Unlimited" },
  remaining: { zh: "\u5269 {n} \u6B21", en: "{n} left" },
  "used-up": { zh: "\u5DF2\u7528\u5B8C\uFF08\u5347\u7D1A\u89E3\u9396\uFF09", en: "Used up (upgrade)" },
  // ── 日票 / 月費 ──
  "upgrade-unlock": { zh: "\u5347\u7D1A\u89E3\u9396\u7121\u9650\u6B21", en: "Upgrade for unlimited" },
  "my-reports": { zh: "\u{1F4CB} \u6211\u7684\u5831\u544A", en: "\u{1F4CB} My Reports" },
  // PM-184
  // PM-185：截圖敏感偵測 + 馬賽克
  "sf-password": { zh: "\u5BC6\u78BC\u6B04\u4F4D", en: "password fields" },
  "sf-token": { zh: "Token \u6B04\u4F4D", en: "token fields" },
  "sf-secret": { zh: "Secret \u6B04\u4F4D", en: "secret fields" },
  "sf-key": { zh: "API Key \u6B04\u4F4D", en: "API key fields" },
  "sf-card": { zh: "\u4FE1\u7528\u5361\u6B04\u4F4D", en: "credit card fields" },
  "sf-cvv": { zh: "CVV \u6B04\u4F4D", en: "CVV fields" },
  "sf-marked": { zh: "\u6A19\u8A18\u70BA\u654F\u611F\u7684\u5143\u7D20", en: "sensitive-marked elements" },
  "sensitive-sep": { zh: "\u3001", en: ", " },
  "sensitive-title": { zh: "\u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D", en: "Sensitive fields detected" },
  "sensitive-page-has": { zh: "\u9801\u9762\u4E0A\u6709\uFF1A{fields}", en: "This page contains: {fields}" },
  "sensitive-hint": {
    zh: "\u622A\u5716\u5F8C\u53EF\u7528 \u{1F512} \u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u654F\u611F\u5340\u57DF\u518D\u4E0A\u50B3",
    en: "Use the \u{1F512} mosaic brush to cover sensitive areas before uploading"
  },
  "sensitive-continue": { zh: "\u7E7C\u7E8C\u622A\u5716", en: "Continue" },
  "sensitive-cancel": { zh: "\u53D6\u6D88", en: "Cancel" },
  "sensitive-tip": {
    zh: "\u{1F512} \u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D\uFF0C\u5EFA\u8B70\u7528\u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u518D\u4E0A\u50B3",
    en: "\u{1F512} Sensitive fields detected \u2014 use the mosaic brush to cover them before uploading"
  },
  "annotate-mosaic": { zh: "\u{1F512} \u99AC\u8CFD\u514B", en: "\u{1F512} Mosaic" },
  // PM-186：自動遮罩
  "auto-masked": { zh: "\u{1F512} \u5DF2\u81EA\u52D5\u906E\u7F69 {n} \u500B\u654F\u611F\u6B04\u4F4D", en: "\u{1F512} Auto-masked {n} sensitive field(s)" },
  "undo-mask": { zh: "\u64A4\u92B7\u906E\u7F69", en: "Undo mask" },
  "day-pass-btn": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr\uFF09", en: "\u26A1 Day Pass NT$20 (24hr)" },
  "monthly-btn": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708", en: "\u2728 Monthly NT$80/mo" },
  // PM-170：用完升級引導 overlay
  "usage-exhausted": { zh: "\u672C\u6708\u984D\u5EA6\u5DF2\u7528\u5B8C", en: "Monthly quota exhausted" },
  "usage-desc-record": { zh: "\u9304\u88FD {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Recording {used}/{max} used" },
  "usage-desc-rewind": { zh: "\u56DE\u6EAF {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Rewind {used}/{max} used" },
  "usage-desc-mcp": { zh: "MCP AI \u8B80\u53D6 {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "MCP AI reads {used}/{max} used" },
  "usage-reset-hint": { zh: "\u{1F4A1} \u514D\u8CBB\u984D\u5EA6\u6BCF\u6708\u81EA\u52D5\u91CD\u7F6E", en: "\u{1F4A1} Free quota resets monthly" },
  "day-pass-btn-full": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr \u7121\u9650\uFF09", en: "\u26A1 Day Pass NT$20 (24hr unlimited)" },
  "monthly-btn-full": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708\uFF08\u6700\u5212\u7B97\uFF09", en: "\u2728 Monthly NT$80/mo (best value)" },
  // PM-171：非台灣付費 coming soon
  "intl-coming-soon": { zh: "\u{1F30F} \u570B\u969B\u4ED8\u6B3E\u5373\u5C07\u958B\u653E", en: "\u{1F30F} International Payments Coming Soon!" },
  "intl-desc": {
    zh: "\u6211\u5011\u6B63\u5728\u958B\u901A\u570B\u969B\u4FE1\u7528\u5361\u4ED8\u6B3E\uFF0C\u656C\u8ACB\u671F\u5F85\uFF01",
    en: "We're working on enabling international credit card payments. Stay tuned!"
  },
  "intl-free-hint": {
    zh: "\u{1F4A1} \u514D\u8CBB\u7248\u73FE\u5728\u5C31\u80FD\u7528 \u2014 \u6BCF\u6708 10 \u6B21\u9304\u88FD + 20 \u6B21 MCP AI \u8B80\u53D6",
    en: "\u{1F4A1} Free plan available now \u2014 10 recordings + 20 MCP AI reads per month"
  },
  "day-pass-badge": { zh: "\u26A1 \u65E5\u7968", en: "\u26A1 Day Pass" },
  "day-pass-remaining": { zh: "\u5269\u9918 {h}h {m}m {s}s", en: "{h}h {m}m {s}s left" },
  "day-pass-expire-hint": {
    zh: "\u65E5\u7968\u5230\u671F\u5F8C\u53EF\u5347\u7D1A\u6708\u8CBB",
    en: "Upgrade to monthly after day pass expires"
  },
  "paid-badge": { zh: "\u2728 \u4ED8\u8CBB\u7248\u6703\u54E1", en: "\u2728 Premium Member" },
  "cancel-sub": { zh: "\u53D6\u6D88\u8A02\u95B1", en: "Cancel" },
  "cancelled-prefix": { zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\uFF0C\u53EF\u7528\u5230", en: "Cancelled, active until" },
  resub: { zh: "\u91CD\u65B0\u8A02\u95B1", en: "Resubscribe" },
  // ── 進階設定 ──
  "lang-label": { zh: "\u{1F310} \u8A9E\u97F3\u8A9E\u8A00", en: "\u{1F310} Voice Language" },
  "advanced-settings": { zh: "\u2699\uFE0F \u9032\u968E\u8A2D\u5B9A", en: "\u2699\uFE0F Advanced Settings" },
  "monitor-toggle": { zh: "\u{1F50D} \u5373\u6642\u76E3\u63A7\uFF08AI \u53EF\u67E5 error\uFF09", en: "\u{1F50D} Live Monitor (AI reads errors)" },
  "keyboard-toggle": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F\uFF08\u95DC\u9589\u8A9E\u97F3\uFF09", en: "\u{1F507} Keyboard Mode (no voice)" },
  "hq-toggle": { zh: "\u{1F4F8} \u9AD8\u756B\u8CEA AI \u5206\u6790\uFF08\u9AD8 Token\uFF09", en: "\u{1F4F8} HQ AI Analysis (high Token)" },
  "effect-toggle": { zh: "\u2728 \u5DE5\u5177\u5217\u7279\u6548", en: "\u2728 Toolbar Effects" },
  // ── AI 輪盤 ──
  "carousel-title": { zh: "\u4E00\u9375\u8907\u88FD\u6307\u4EE4\u8CBC\u7D66 AI", en: "Copy prompt to AI" },
  "copy-btn": { zh: "\u8907\u88FD", en: "Copy" },
  "edit-btn": { zh: "\u270F\uFE0F \u7DE8\u8F2F", en: "\u270F\uFE0F Edit" },
  "save-btn": { zh: "\u{1F4BE} \u5132\u5B58", en: "\u{1F4BE} Save" },
  "cancel-btn": { zh: "\u53D6\u6D88", en: "Cancel" },
  // ── 錄製中 / 完成 ──
  "stop-recording": { zh: "\u23F9 \u505C\u6B62\u9304\u88FD", en: "\u23F9 Stop Recording" },
  "done-title": { zh: "\u2705 \u9304\u88FD\u5B8C\u6210\uFF01", en: "\u2705 Recording Done!" },
  "sum-dom": { zh: "DOM \u4E8B\u4EF6", en: "DOM Events" },
  "sum-console": { zh: "Console", en: "Console" },
  "sum-network": { zh: "Network \u932F\u8AA4", en: "Network Errors" },
  "sum-voice": { zh: "\u8A9E\u97F3\u7247\u6BB5", en: "Voice Clips" },
  "sum-time": { zh: "\u6642\u9593", en: "Duration" },
  "duration-sec": { zh: "{n} \u79D2", en: "{n}s" },
  "copy-json": { zh: "\u{1F4CB} \u8907\u88FD JSON", en: "\u{1F4CB} Copy JSON" },
  "export-json": { zh: "\u{1F4BE} \u532F\u51FA JSON\uFF08\u7D66 AI \u8B80\uFF09", en: "\u{1F4BE} Export JSON (for AI)" },
  "clear-restart": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\uFF0C\u91CD\u65B0\u9304\u88FD", en: "\u{1F5D1}\uFE0F Clear & Restart" },
  "copy-link": { zh: "\u{1F4CB} \u8907\u88FD\u9023\u7D50", en: "\u{1F4CB} Copy Link" },
  // PM-189：JSON 複製/匯出改付費功能 + 敏感資料免責警語
  "json-paid-only": { zh: "\u6B64\u70BA\u6703\u54E1\u9032\u968E\u529F\u80FD\uFF0C\u8ACB\u5347\u7D1A\u5F8C\u4F7F\u7528", en: "This is a member feature. Please upgrade to use." },
  "json-warning-title": { zh: "\u26A0\uFE0F JSON \u8CC7\u6599\u5305\u542B\u5B8C\u6574\u9664\u932F\u7D00\u9304", en: "\u26A0\uFE0F JSON data contains full debug records" },
  "json-warning-body": {
    zh: "\u6B64\u8CC7\u6599\u53EF\u80FD\u5305\u542B\u654F\u611F\u8CC7\u8A0A\uFF08API \u91D1\u9470\u3001Token\u3001\u932F\u8AA4\u8A0A\u606F\u7B49\uFF09\uFF0C\u8ACB\u52FF\u5C07 JSON \u8CC7\u6599\u5206\u4EAB\u7D66\u4E0D\u4FE1\u4EFB\u7684\u5C0D\u8C61\u3002\u56E0\u8CC7\u6599\u5916\u6D29\u9020\u6210\u7684\u640D\u5931\uFF0CBugEzy \u4E0D\u627F\u64D4\u8CAC\u4EFB\u3002",
    en: "This data may contain sensitive information (API keys, tokens, error messages, etc.). Do not share JSON data with untrusted parties. BugEzy is not responsible for any loss caused by data leakage."
  },
  "json-confirm": { zh: "\u6211\u4E86\u89E3\uFF0C\u7E7C\u7E8C", en: "I understand, continue" },
  "json-cancel": { zh: "\u53D6\u6D88", en: "Cancel" },
  "json-copy-locked": { zh: "\u{1F512} \u8907\u88FD JSON\uFF08\u6703\u54E1\uFF09", en: "\u{1F512} Copy JSON (member)" },
  "json-export-locked": { zh: "\u{1F512} \u532F\u51FA JSON\uFF08\u6703\u54E1\uFF09", en: "\u{1F512} Export JSON (member)" },
  // PM-191：一鍵複製 MCP 設定
  "copy-mcp": { zh: "\u{1F4CB} \u8907\u88FD MCP \u8A2D\u5B9A", en: "\u{1F4CB} Copy MCP Config" },
  "copy-mcp-done": { zh: "\u2705 \u5DF2\u8907\u88FD\uFF01\u8CBC\u5230 Claude/Cursor \u8A2D\u5B9A\u5373\u53EF", en: "\u2705 Copied! Paste into your Claude/Cursor settings" },
  "copy-mcp-login": { zh: "\u8ACB\u5148\u767B\u5165 BugEzy \u518D\u8907\u88FD MCP \u8A2D\u5B9A", en: "Please sign in to BugEzy before copying the MCP config" },
  "mcp-config-hint": { zh: "\u7576 AI \u7121\u6CD5\u8B80\u53D6\u4F60\u7684\u5831\u544A\u6642\uFF0C\u6309\u6B64\u8907\u88FD\uFF0C\u8CBC\u7D66\u4F60\u7684 AI \u91CD\u65B0\u8A2D\u5B9A", en: "If AI cannot read your reports, copy this and paste to your AI to reconfigure" },
  // PM-193：精準轉錄麥克風授權引導
  "mic-fallback-tip": {
    zh: "\u26A0\uFE0F \u7CBE\u6E96\u8F49\u9304\u9EA5\u514B\u98A8\u6388\u6B0A\u4E0D\u8DB3\uFF0C\u5DF2\u5207\u63DB\u70BA\u5373\u6642\u5B57\u5E55\u6A21\u5F0F\u3002\u4E0B\u6B21\u8ACB\u9078\u300C\u5141\u8A31\u9019\u500B\u7DB2\u7AD9\u4F7F\u7528\u300D\u3002",
    en: '\u26A0\uFE0F Whisper mic permission denied. Switched to realtime mode. Next time select "Always allow".'
  },
  "mic-perm-hint": {
    zh: "\u{1F4A1} \u7CBE\u6E96\u8F49\u9304\u9700\u9078\u300C\u6C38\u4E45\u5141\u8A31\u300D\u6B64\u7DB2\u7AD9\u4F7F\u7528\u9EA5\u514B\u98A8",
    en: '\u{1F4A1} Whisper requires "Always allow" microphone permission'
  },
  // ── mic OFF 提示 ──
  "mic-prompt-title": { zh: "\u9EA5\u514B\u98A8\u76EE\u524D\u95DC\u9589", en: "Microphone is off" },
  "mic-prompt-desc": { zh: "\u8981\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \u55CE\uFF1F", en: "Use voice to describe the bug?" },
  "mic-prompt-on": { zh: "\u958B\u555F\u4E26\u9304\u88FD", en: "Turn on & record" },
  "mic-prompt-skip": { zh: "\u76F4\u63A5\u9304\u88FD\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Record without voice" },
  // ── 版本（動態）──
  "update-available": {
    zh: "\u{1F195} \u76EE\u524D v{cur} \u2192 \u65B0\u7248 v{new} \u53EF\u7528",
    en: "\u{1F195} v{cur} \u2192 v{new} available"
  },
  // ── PM-139：截圖工具列（content.ts）──
  "toolbar-fullpage": { zh: "\u{1F4F7} \u6574\u9801", en: "\u{1F4F7} Full Page" },
  "toolbar-region": { zh: "\u2B1C \u5340\u57DF\uFF08\u5169\u9EDE\uFF09", en: "\u2B1C Region (2 clicks)" },
  "toolbar-freeform": { zh: "\u2702\uFE0F \u81EA\u7531\u5F62\u72C0", en: "\u2702\uFE0F Freeform" },
  "toolbar-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "toolbar-select-mode": { zh: "\u9078\u64C7\u622A\u5716\u6A21\u5F0F", en: "Select screenshot mode" },
  "toolbar-region-hint": { zh: "\u53EF\u81EA\u7531\u6372\u52D5\u9801\u9762\uFF0C\u9EDE\u7B2C\u4E8C\u4E0B\u6A19\u8A18\u7D42\u9EDE", en: "Scroll freely, click again to set the end point" },
  "transcribing": { zh: "\u23F3 \u8A9E\u97F3\u8F49\u9304\u4E2D\u2026", en: "\u23F3 Transcribing\u2026" },
  // ── PM-139：即時監控（inject.ts，經 it()）──
  "monitor-active": { zh: "\u{1F7E2} BugEzy \u76E3\u63A7\u4E2D", en: "\u{1F7E2} BugEzy Monitoring" },
  "monitor-errors": { zh: "\u26A0\uFE0F \u767C\u73FE {n} \u500B\u932F\u8AA4\uFF08\u9EDE\u6211\u67E5\u770B\uFF09", en: "\u26A0\uFE0F {n} error(s) found (click to view)" },
  "monitor-errors-title": { zh: "BugEzy \u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4\uFF0C\u9EDE\u6211\u67E5\u770B", en: "BugEzy found {n} error(s), click to view" },
  "monitor-panel-title": { zh: "\u{1F41B} \u5373\u6642\u76E3\u63A7\u932F\u8AA4", en: "\u{1F41B} Live Monitor Errors" },
  "monitor-empty": { zh: "\u2713 \u76EE\u524D\u7121\u932F\u8AA4", en: "\u2713 No errors" },
  "monitor-upload": { zh: "\u{1F4E4} \u4E0A\u50B3\u5831\u544A\u8B93 AI \u5206\u6790", en: "\u{1F4E4} Upload report for AI analysis" },
  "monitor-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D\u2026", en: "\u23F3 Uploading\u2026" },
  "monitor-uploaded": { zh: "\u2705 \u5DF2\u4E0A\u50B3\uFF01\u9EDE\u6B64\u67E5\u770B\u5831\u544A", en: "\u2705 Uploaded! Click to view report" },
  "monitor-upload-fail": { zh: "\u274C \u4E0A\u50B3\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66", en: "\u274C Upload failed, click to retry" },
  "monitor-desc": { zh: "\u5373\u6642\u76E3\u63A7\u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4", en: "Live monitor found {n} error(s)" },
  // ── PM-139：錄製字幕 / 麥克風授權（inject.ts，經 it()）──
  "caption-recording": { zh: "\u{1F399} \u9304\u88FD\u4E2D\uFF0C\u53EF\u4EE5\u7528\u4E2D\u6587\u63CF\u8FF0\u554F\u984C\u2026", en: "\u{1F399} Recording \u2014 describe the issue by voice\u2026" },
  "caption-voice-log": { zh: "\u{1F4DD} \u8A9E\u97F3\u8A18\u9304", en: "\u{1F4DD} Voice Log" },
  "keyboard-bar": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F \u2014 \u9304\u88FD\u4E2D\uFF08\u8A9E\u97F3\u5DF2\u95DC\u9589\uFF09", en: "\u{1F507} Keyboard mode \u2014 recording (voice off)" },
  "whisper-bar": { zh: "\u{1F399}\uFE0F \u9304\u97F3\u4E2D\u2026\uFF08\u505C\u6B62\u5F8C\u81EA\u52D5\u8F49\u9304\uFF09", en: "\u{1F399}\uFE0F Recording\u2026\uFF08auto-transcribe on stop\uFF09" },
  "mic-perm-title": { zh: "BugEzy \u9700\u8981\u9EA5\u514B\u98A8\u6B0A\u9650", en: "BugEzy needs microphone access" },
  "mic-perm-desc": { zh: "\u5141\u8A31\u5F8C\u53EF\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \xB7 \u6B64\u7DB2\u7AD9\u53EA\u9700\u6388\u6B0A\u4E00\u6B21", en: "Allow to describe bugs by voice \xB7 one-time per site" },
  "mic-perm-allow": { zh: "\u5141\u8A31\u9EA5\u514B\u98A8", en: "Allow microphone" },
  "mic-perm-skip": { zh: "\u8DF3\u904E\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Skip (no voice)" },
  // ── PM-139：截圖標注頁（annotate）──
  "annotate-pen": { zh: "\u270F\uFE0F \u756B\u7B46", en: "\u270F\uFE0F Pen" },
  "annotate-arrow": { zh: "\u27A1\uFE0F \u7BAD\u982D", en: "\u27A1\uFE0F Arrow" },
  "annotate-rect": { zh: "\u2B1C \u6846\u6846", en: "\u2B1C Box" },
  "annotate-text": { zh: "\u{1F4DD} \u6587\u5B57", en: "\u{1F4DD} Text" },
  "annotate-color": { zh: "\u984F\u8272", en: "Color" },
  "annotate-thickness": { zh: "\u7C97\u7D30", en: "Width" },
  "annotate-thin": { zh: "\u7D30", en: "Thin" },
  "annotate-mid": { zh: "\u4E2D", en: "Medium" },
  "annotate-thick": { zh: "\u7C97", en: "Thick" },
  "annotate-undo": { zh: "\u21A9\uFE0F \u5FA9\u539F", en: "\u21A9\uFE0F Undo" },
  "annotate-clear": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\u5168\u90E8", en: "\u{1F5D1}\uFE0F Clear All" },
  "annotate-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "annotate-save": { zh: "\u2705 \u5B8C\u6210\u5132\u5B58", en: "\u2705 Save" },
  "annotate-desc-label": { zh: "\u{1F4AC} \u554F\u984C\u63CF\u8FF0\uFF08\u9078\u586B\uFF09", en: "\u{1F4AC} Description (optional)" },
  "annotate-desc-ph": { zh: "\u63CF\u8FF0\u4F60\u770B\u5230\u7684\u554F\u984C\uFF0C\u6216\u6309\u53F3\u908A\u9EA5\u514B\u98A8\u8A9E\u97F3\u8F38\u5165...", en: "Describe the issue, or tap the mic on the right to dictate..." },
  "annotate-listening": { zh: "\u{1F534} \u8046\u807D\u4E2D\uFF0C\u908A\u756B\u908A\u8AAA\u63CF\u8FF0\u554F\u984C...", en: "\u{1F534} Listening \u2014 describe while you draw..." },
  "annotate-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D...", en: "\u23F3 Uploading..." },
  // ── PM-139：alert / confirm（popup.ts）──
  "confirm-cancel-sub": {
    zh: "\u78BA\u5B9A\u8981\u53D6\u6D88\u6708\u8CBB\u8A02\u95B1\u55CE\uFF1F\n\u53D6\u6D88\u5F8C\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\uFF0C\u5230\u671F\u5F8C\u81EA\u52D5\u964D\u56DE\u514D\u8CBB\u7248\u3002",
    en: "Cancel your monthly subscription?\nYou can still use premium features until the end of your billing period."
  },
  "alert-cancelled": {
    zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\u3002\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\u3002",
    en: "Subscription cancelled. Premium features remain active until end of billing period."
  },
  "alert-cancel-fail": { zh: "\u53D6\u6D88\u5931\u6557\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66", en: "Cancellation failed, please try again later" }
};
function t(key2, lang, params2) {
  const entry = dict[key2];
  let text = entry?.[lang] || entry?.["zh"] || key2;
  if (params2) {
    for (const [k, v] of Object.entries(params2)) {
      text = text.replace(`{${k}}`, String(v));
    }
  }
  return text;
}

// src/net.ts
function getNetworkSnapshot() {
  const conn = navigator.connection;
  return {
    online: navigator.onLine,
    effectiveType: conn?.effectiveType || "unknown",
    rtt: conn?.rtt ?? null,
    downlink: conn?.downlink ?? null,
    saveData: conn?.saveData ?? false,
    type: conn?.type || "unknown"
  };
}

// src/annotate.ts
var annotateUILang = "zh";
function applyAnnotateTranslations() {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key2 = el.getAttribute("data-i18n");
    if (key2) el.textContent = t(key2, annotateUILang);
  });
  document.querySelectorAll("[data-i18n-ph]").forEach((el) => {
    const key2 = el.getAttribute("data-i18n-ph");
    if (key2) el.placeholder = t(key2, annotateUILang);
  });
}
void chrome.storage.local.get(LANG_KEY, (r) => {
  annotateUILang = getUILang(r[LANG_KEY] || "zh");
  applyAnnotateTranslations();
});
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing #${id}`);
  return el;
};
var canvas = $("canvas");
var ctx = canvas.getContext("2d");
if (!ctx) throw new Error("canvas 2d context \u4E0D\u53EF\u7528");
var penTool = $("penTool");
var arrowTool = $("arrowTool");
var rectTool = $("rectTool");
var textTool = $("textTool");
var mosaicTool = $("mosaicTool");
var colorPicker = $("colorPicker");
var lineWidthSel = $("lineWidth");
var undoBtn = $("undoBtn");
var clearBtn = $("clearBtn");
var cancelBtn = $("cancelBtn");
var saveBtn = $("saveBtn");
var descInput = $("descInput");
var voiceInputBtn = $("voiceInputBtn");
var voiceStatus = $("voiceStatus");
var toolbar = document.querySelector(".toolbar");
toolbar?.addEventListener("mousedown", (e) => {
  const tag = e.target.tagName.toLowerCase();
  if (tag !== "input" && tag !== "select") e.preventDefault();
});
toolbar?.addEventListener("animationend", () => {
  toolbar.classList.add("glow-settled");
});
chrome.storage.local.get(TOOLBAR_EFFECT_KEY, (store) => {
  if (store[TOOLBAR_EFFECT_KEY] !== false) toolbar?.classList.add("fx-on");
});
var params = new URLSearchParams(location.search);
var key = params.get("key");
var SENSITIVE_DETECTED_KEY = "bugezy:sensitive-detected";
var SENSITIVE_RECTS_KEY = "bugezy:sensitive-rects";
function applyMosaic(c, x, y, w, h) {
  const block = 10;
  const x0 = Math.max(0, x);
  const y0 = Math.max(0, y);
  const x1 = Math.min(canvas.width, x + w);
  const y1 = Math.min(canvas.height, y + h);
  for (let bx = x0; bx < x1; bx += block) {
    for (let by = y0; by < y1; by += block) {
      const pw = Math.min(block, x1 - bx);
      const ph = Math.min(block, y1 - by);
      if (pw <= 0 || ph <= 0) continue;
      const px = c.getImageData(bx, by, pw, ph).data;
      let r = 0, g = 0, b = 0;
      const n = px.length / 4;
      for (let i = 0; i < px.length; i += 4) {
        r += px[i];
        g += px[i + 1];
        b += px[i + 2];
      }
      c.fillStyle = `rgb(${Math.round(r / n)},${Math.round(g / n)},${Math.round(b / n)})`;
      c.fillRect(bx, by, pw, ph);
    }
  }
}
var currentTool = "pen";
var MOSAIC_SIZE = 16;
var drawing = false;
var startX = 0;
var startY = 0;
var snapshot = null;
var baseImage = null;
var history = [];
var toolButtons = {
  pen: penTool,
  arrow: arrowTool,
  rect: rectTool,
  text: textTool,
  mosaic: mosaicTool
};
function setTool(tool) {
  currentTool = tool;
  Object.keys(toolButtons).forEach((t2) => {
    toolButtons[t2].classList.toggle("active", t2 === tool);
  });
  canvas.style.cursor = tool === "mosaic" ? "crosshair" : "crosshair";
}
penTool.addEventListener("click", () => setTool("pen"));
arrowTool.addEventListener("click", () => setTool("arrow"));
rectTool.addEventListener("click", () => setTool("rect"));
textTool.addEventListener("click", () => setTool("text"));
mosaicTool.addEventListener("click", () => setTool("mosaic"));
function paintMosaic(x, y) {
  const bx = Math.floor(x / MOSAIC_SIZE) * MOSAIC_SIZE;
  const by = Math.floor(y / MOSAIC_SIZE) * MOSAIC_SIZE;
  const w = Math.min(MOSAIC_SIZE, canvas.width - bx);
  const h = Math.min(MOSAIC_SIZE, canvas.height - by);
  if (w <= 0 || h <= 0) return;
  const img = ctx.getImageData(bx, by, w, h);
  const px = img.data;
  let r = 0, g = 0, b = 0;
  const n = px.length / 4;
  for (let i = 0; i < px.length; i += 4) {
    r += px[i];
    g += px[i + 1];
    b += px[i + 2];
  }
  ctx.fillStyle = `rgb(${Math.round(r / n)},${Math.round(g / n)},${Math.round(b / n)})`;
  ctx.fillRect(bx, by, w, h);
}
function applyStyle() {
  ctx.strokeStyle = colorPicker.value;
  ctx.fillStyle = colorPicker.value;
  ctx.lineWidth = Number(lineWidthSel.value);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
}
function fontSize() {
  return 12 + Number(lineWidthSel.value) * 4;
}
function saveState() {
  history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
  if (history.length > 50) history.shift();
}
function pos(e) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (e.clientX - rect.left) * (canvas.width / rect.width),
    y: (e.clientY - rect.top) * (canvas.height / rect.height)
  };
}
function drawArrow(x1, y1, x2, y2) {
  const head = Math.max(10, Number(lineWidthSel.value) * 3);
  const angle = Math.atan2(y2 - y1, x2 - x1);
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - head * Math.cos(angle - Math.PI / 6), y2 - head * Math.sin(angle - Math.PI / 6));
  ctx.lineTo(x2 - head * Math.cos(angle + Math.PI / 6), y2 - head * Math.sin(angle + Math.PI / 6));
  ctx.closePath();
  ctx.fill();
}
canvas.addEventListener("mousedown", (e) => {
  const { x, y } = pos(e);
  if (currentTool === "text") {
    const text = prompt("\u8F38\u5165\u6587\u5B57\uFF1A");
    if (text) {
      saveState();
      applyStyle();
      ctx.font = `${fontSize()}px system-ui, sans-serif`;
      ctx.textBaseline = "top";
      ctx.fillText(text, x, y);
    }
    return;
  }
  drawing = true;
  startX = x;
  startY = y;
  saveState();
  snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
  if (currentTool === "pen") {
    applyStyle();
    ctx.beginPath();
    ctx.moveTo(x, y);
  } else if (currentTool === "mosaic") {
    paintMosaic(x, y);
  }
});
canvas.addEventListener("mousemove", (e) => {
  if (!drawing) return;
  const { x, y } = pos(e);
  if (currentTool === "mosaic") {
    paintMosaic(x, y);
    return;
  }
  applyStyle();
  if (currentTool === "pen") {
    ctx.lineTo(x, y);
    ctx.stroke();
  } else if (snapshot) {
    ctx.putImageData(snapshot, 0, 0);
    if (currentTool === "rect") {
      ctx.strokeRect(startX, startY, x - startX, y - startY);
    } else if (currentTool === "arrow") {
      drawArrow(startX, startY, x, y);
    }
  }
});
function endDraw() {
  drawing = false;
  snapshot = null;
}
canvas.addEventListener("mouseup", endDraw);
canvas.addEventListener("mouseleave", endDraw);
undoBtn.addEventListener("click", () => {
  const prev = history.pop();
  if (prev) ctx.putImageData(prev, 0, 0);
});
clearBtn.addEventListener("click", () => {
  if (!baseImage) return;
  saveState();
  ctx.putImageData(baseImage, 0, 0);
});
var win = window;
var SR = win.SpeechRecognition || win.webkitSpeechRecognition;
var recognition = null;
var listening = false;
var captionText = $("captionText");
var liveCaptions = $("liveCaptions");
var voiceToggle = $("voice-toggle");
var voiceOn = true;
function setVoiceToggleUI(on) {
  voiceOn = on;
  voiceToggle.textContent = on ? "\u2328\uFE0F" : "\u{1F399}\uFE0F";
  voiceToggle.title = on ? "\u5207\u63DB\u5230\u9375\u76E4\u8F38\u5165" : "\u5207\u63DB\u5230\u8A9E\u97F3\u8F38\u5165";
  voiceToggle.classList.toggle("mic-on", !on);
}
voiceToggle.addEventListener("click", () => {
  if (voiceOn) {
    setVoiceToggleUI(false);
    stopListening();
  } else {
    setVoiceToggleUI(true);
    void startListening();
  }
});
var autoRestartFails = 0;
function createAnnotateRecognition() {
  if (!SR) return null;
  const rec = new SR();
  rec.lang = "zh-TW";
  rec.continuous = true;
  rec.interimResults = true;
  rec.onresult = (e) => {
    let interim = "";
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const res = e.results[i];
      const text = res[0].transcript;
      if (res.isFinal) {
        const cursorPos = descInput.selectionStart;
        const isAtEnd = cursorPos === descInput.value.length;
        descInput.value += text;
        if (!isAtEnd) {
          descInput.selectionStart = cursorPos;
          descInput.selectionEnd = cursorPos;
        }
        captionText.textContent = `\u2705 ${text}`;
        window.setTimeout(() => {
          if (listening) captionText.textContent = "\u{1F534} \u8046\u807D\u4E2D...";
        }, 1500);
      } else {
        interim = text;
      }
    }
    if (interim) {
      captionText.textContent = `\u{1F534} ${interim}`;
      liveCaptions.classList.remove("hidden");
    }
  };
  rec.onend = () => {
    if (listening) {
      try {
        rec.start();
        autoRestartFails = 0;
      } catch {
        autoRestartFails++;
        if (autoRestartFails >= 3) {
          void (async () => {
            try {
              const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
              stream.getTracks().forEach((t2) => t2.stop());
              await new Promise((r) => setTimeout(r, 300));
              if (!listening) return;
              recognition = createAnnotateRecognition();
              if (recognition) {
                recognition.start();
                autoRestartFails = 0;
                captionText.textContent = "\u{1F534} \u8A9E\u97F3\u5DF2\u91CD\u555F...";
              }
            } catch {
              captionText.textContent = "\u26A0 \u8A9E\u97F3\u4E2D\u65B7\uFF0C\u6309 \u{1F3A4} \u91CD\u65B0\u555F\u52D5";
              stopListening();
            }
          })();
        }
      }
    }
  };
  rec.onerror = (e) => {
    captionText.textContent = `\u8A9E\u97F3\u932F\u8AA4\uFF1A${e.error}`;
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      setVoiceToggleUI(false);
      stopListening();
    }
  };
  return rec;
}
async function startWebSpeech() {
  if (!SR || listening) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t2) => t2.stop());
  } catch {
    voiceStatus.textContent = "\u274C \u9EA5\u514B\u98A8\u7121\u6CD5\u5B58\u53D6";
    return;
  }
  autoRestartFails = 0;
  recognition = createAnnotateRecognition();
  if (!recognition) return;
  recognition.start();
  listening = true;
  voiceInputBtn.classList.add("listening");
  voiceInputBtn.textContent = "\u23F9";
  voiceStatus.textContent = "";
  captionText.textContent = "\u{1F534} \u8046\u807D\u4E2D\uFF0C\u908A\u756B\u908A\u8AAA\u63CF\u8FF0\u554F\u984C...";
  liveCaptions.classList.remove("hidden");
}
function stopWebSpeech() {
  if (!listening) return;
  listening = false;
  if (recognition) {
    try {
      recognition.stop();
    } catch {
    }
    recognition = null;
  }
  voiceInputBtn.classList.remove("listening");
  voiceInputBtn.textContent = "\u{1F3A4}";
  voiceStatus.textContent = "\u8A9E\u97F3\u5DF2\u505C\u6B62";
  liveCaptions.classList.add("hidden");
}
var useWhisper = false;
var whisperRecorder = null;
var whisperChunks = [];
var whisperStream = null;
function releaseWhisperStream() {
  whisperStream?.getTracks().forEach((tk) => tk.stop());
  whisperStream = null;
}
async function startWhisper() {
  if (listening) return;
  try {
    whisperStream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    voiceStatus.textContent = "\u274C \u9EA5\u514B\u98A8\u7121\u6CD5\u5B58\u53D6";
    return;
  }
  whisperChunks = [];
  whisperRecorder = new MediaRecorder(whisperStream, { mimeType: "audio/webm" });
  whisperRecorder.ondataavailable = (e) => {
    if (e.data.size) whisperChunks.push(e.data);
  };
  whisperRecorder.start();
  listening = true;
  voiceInputBtn.classList.add("listening");
  voiceInputBtn.textContent = "\u23F9";
  voiceStatus.textContent = "";
  captionText.textContent = "\u{1F534} Whisper \u9304\u97F3\u4E2D\uFF0C\u8B1B\u5B8C\u6309 \u23F9 \u8F49\u9304\u2026";
  liveCaptions.classList.remove("hidden");
}
async function stopWhisper() {
  if (!listening) return;
  listening = false;
  voiceInputBtn.classList.remove("listening");
  voiceInputBtn.textContent = "\u{1F3A4}";
  const rec = whisperRecorder;
  whisperRecorder = null;
  if (!rec || rec.state === "inactive") {
    releaseWhisperStream();
    liveCaptions.classList.add("hidden");
    return;
  }
  await new Promise((resolve) => {
    rec.onstop = () => resolve();
    try {
      rec.stop();
    } catch {
      resolve();
    }
  });
  releaseWhisperStream();
  const blob = new Blob(whisperChunks, { type: "audio/webm" });
  whisperChunks = [];
  if (blob.size < 1e3) {
    voiceStatus.textContent = "\u8A9E\u97F3\u592A\u77ED";
    liveCaptions.classList.add("hidden");
    return;
  }
  voiceStatus.textContent = "\u23F3 Whisper \u8F49\u9304\u4E2D\u2026";
  captionText.textContent = "\u23F3 \u8F49\u9304\u4E2D\u2026";
  try {
    const form = new FormData();
    form.append("audio", blob, "annotate-voice.webm");
    const langStore = await chrome.storage.local.get(LANG_KEY);
    form.append("language", langStore[LANG_KEY] || "zh");
    const res = await fetch(`${API_BASE}/api/transcribe`, {
      method: "POST",
      headers: await getAuthHeaderOnly(),
      // multipart：只帶 Authorization，不設 Content-Type
      body: form
    });
    const data = await res.json();
    if (res.ok && data.text) {
      descInput.value += (descInput.value ? " " : "") + data.text;
      voiceStatus.textContent = "\u2705 \u5DF2\u8F49\u9304";
    } else if (res.status === 403) {
      voiceStatus.textContent = "Whisper \u70BA\u4ED8\u8CBB\u529F\u80FD\uFF0C\u8ACB\u5347\u7D1A\uFF08\u6216\u6539\u7528\u9375\u76E4\uFF09";
    } else {
      voiceStatus.textContent = "\u8F49\u9304\u5931\u6557\uFF0C\u53EF\u6539\u7528\u9375\u76E4\u8F38\u5165";
    }
  } catch {
    voiceStatus.textContent = "\u8F49\u9304\u5931\u6557\uFF0C\u53EF\u6539\u7528\u9375\u76E4\u8F38\u5165";
  } finally {
    liveCaptions.classList.add("hidden");
  }
}
async function startListening() {
  return useWhisper ? startWhisper() : startWebSpeech();
}
async function stopListening() {
  return useWhisper ? stopWhisper() : stopWebSpeech();
}
voiceInputBtn.addEventListener("click", () => {
  if (!SR) {
    voiceStatus.textContent = "\u6B64\u700F\u89BD\u5668\u4E0D\u652F\u63F4\u8A9E\u97F3\u8FA8\u8B58";
    return;
  }
  if (listening) stopListening();
  else startListening();
});
chrome.storage.local.get([KEYBOARD_MODE_KEY, USER_PLAN_KEY, MIC_MODE_KEY], (r) => {
  const plan = r[USER_PLAN_KEY] || "free";
  const isPaid = plan === "paid" || plan === "cancelled" || plan === "day_pass";
  const micMode = r[MIC_MODE_KEY] || "whisper";
  useWhisper = isPaid && micMode === "whisper";
  if (r[KEYBOARD_MODE_KEY] === true) {
    voiceStatus.textContent = "\u{1F507} \u9375\u76E4\u6A21\u5F0F\uFF08\u8A9E\u97F3\u5DF2\u95DC\u9589\uFF09";
    setVoiceToggleUI(false);
  } else if (useWhisper) {
    voiceStatus.textContent = "\u{1F399}\uFE0F \u4ED8\u8CBB\u7248 Whisper\uFF1A\u6309 \u{1F3A4} \u9304\u97F3\u63CF\u8FF0\uFF0C\u8B1B\u5B8C\u6309 \u23F9 \u8F49\u9304";
  } else {
    window.setTimeout(() => void startListening(), 800);
  }
});
saveBtn.addEventListener("click", async () => {
  const annotatedDataUrl = canvas.toDataURL("image/png");
  await stopListening();
  const ssStore = await chrome.storage.local.get([ALLOW_SCREENSHOT_KEY, SESSION_KEY]);
  const allowScreenshotImages = ssStore[ALLOW_SCREENSHOT_KEY] === true;
  const session = ssStore[SESSION_KEY];
  const collected = await chrome.runtime.sendMessage({ type: "GET_COLLECTED_ERRORS" }).catch(() => null);
  const payload = {
    rrwebEvents: [],
    consoleLogs: collected?.consoleLogs ?? [],
    networkErrors: collected?.networkErrors ?? [],
    voiceTranscript: [],
    screenshots: [{ dataUrl: annotatedDataUrl, timestamp: Date.now() }],
    description: descInput.value.trim(),
    allow_screenshot_images: allowScreenshotImages,
    ...session?.user_id ? { user_id: session.user_id } : {},
    // PM-156：截圖標注也帶網路快照（annotate 是擴充頁，可直接用 navigator API）
    networkSnapshot: { atStart: getNetworkSnapshot() },
    pageInfo: {
      url: params.get("pageUrl") ?? "",
      title: params.get("pageTitle") ?? "",
      browser: navigator.userAgent,
      screenSize: `${screen.width}x${screen.height}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
  saveBtn.textContent = "\u23F3 \u4E0A\u50B3\u4E2D...";
  saveBtn.disabled = true;
  try {
    const res = await fetch(`${API_BASE}/api/reports`, {
      method: "POST",
      // PM-98/129：帶 session token，讓 server 端防呆能在漏帶 user_id 時從 header 補回
      headers: await getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.share_url && data.report_id) {
      await chrome.runtime.sendMessage({
        type: "SCREENSHOT_UPLOADED",
        shareUrl: data.share_url,
        reportId: data.report_id
      });
      blog("\u622A\u5716\u7368\u7ACB\u4E0A\u50B3\u5B8C\u6210", data.share_url);
    }
  } catch (err) {
    blog("\u622A\u5716\u4E0A\u50B3\u5931\u6557", err);
  }
  if (key) await chrome.storage.local.remove(key);
  window.close();
});
cancelBtn.addEventListener("click", async () => {
  stopListening();
  if (key) await chrome.storage.local.remove(key);
  window.close();
});
async function init() {
  if (!key) {
    document.body.textContent = "\u7F3A\u5C11\u622A\u5716 key";
    return;
  }
  const store = await chrome.storage.local.get(key);
  const dataUrl = store[key];
  if (!dataUrl) {
    document.body.textContent = "\u627E\u4E0D\u5230\u66AB\u5B58\u622A\u5716";
    return;
  }
  const img = new Image();
  img.src = dataUrl;
  await img.decode();
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  ctx.drawImage(img, 0, 0);
  baseImage = ctx.getImageData(0, 0, canvas.width, canvas.height);
  blog("\u6A19\u6CE8\u9801\u8F09\u5165\u622A\u5716", `${canvas.width}x${canvas.height}`);
  const s = await chrome.storage.local.get([SENSITIVE_RECTS_KEY, SENSITIVE_DETECTED_KEY]);
  void chrome.storage.local.remove([SENSITIVE_RECTS_KEY, SENSITIVE_DETECTED_KEY]);
  const payload = s[SENSITIVE_RECTS_KEY];
  const tip = document.getElementById("sensitiveTip");
  let autoMasked = 0;
  if (payload?.rects?.length && (payload.viewportWidth ?? 0) > 0 && (payload.viewportHeight ?? 0) > 0) {
    const scaleX = canvas.width / payload.viewportWidth;
    const scaleY = canvas.height / payload.viewportHeight;
    if (Math.abs(scaleX - scaleY) / Math.max(scaleX, scaleY) < 0.05) {
      for (const r of payload.rects) {
        applyMosaic(ctx, Math.round(r.x * scaleX), Math.round(r.y * scaleY), Math.round(r.width * scaleX), Math.round(r.height * scaleY));
      }
      autoMasked = payload.rects.length;
    }
  }
  if (tip) {
    if (autoMasked > 0) {
      tip.textContent = t("auto-masked", annotateUILang, { n: autoMasked }) + "  ";
      const undoBtn2 = document.createElement("button");
      undoBtn2.textContent = t("undo-mask", annotateUILang);
      undoBtn2.style.cssText = "margin-left:8px;background:#fff;color:#000;border:none;border-radius:4px;padding:3px 12px;cursor:pointer;font-size:12px;font-weight:600;";
      undoBtn2.onclick = () => {
        if (baseImage) ctx.putImageData(baseImage, 0, 0);
        tip.style.display = "none";
      };
      tip.appendChild(undoBtn2);
      tip.style.display = "block";
    } else if (s[SENSITIVE_DETECTED_KEY]) {
      tip.textContent = t("sensitive-tip", annotateUILang);
      tip.style.display = "block";
    }
  }
}
void init();
//# sourceMappingURL=annotate.js.map
