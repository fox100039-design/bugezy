// src/types.ts
var API_BASE = "https://bugezy.dev";
var SESSION_TOKEN_KEY = "bugezy:session-token";

// src/auth.ts
async function getAuthToken() {
  const store = await chrome.storage.local.get(SESSION_TOKEN_KEY);
  return store[SESSION_TOKEN_KEY];
}
async function getAuthHeaders() {
  const token = await getAuthToken();
  return {
    "Content-Type": "application/json",
    ...token ? { Authorization: `Bearer ${token}` } : {}
  };
}

// src/checkout.ts
var statusEl = document.getElementById("status");
function setStatus(msg) {
  if (statusEl) statusEl.textContent = msg;
}
void (async () => {
  const headers = await getAuthHeaders();
  if (!headers.Authorization) {
    setStatus("\u8ACB\u5148\u5728 BugEzy \u767B\u5165\u5F8C\u518D\u5347\u7D1A\u4ED8\u8CBB\u7248\u3002");
    return;
  }
  try {
    const res = await fetch(`${API_BASE}/checkout`, {
      method: "POST",
      headers
    });
    const text = await res.text();
    if (!res.ok) {
      let msg = "\u5EFA\u7ACB\u8A02\u95B1\u8A02\u55AE\u5931\u6557\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\u3002";
      try {
        msg = JSON.parse(text).error ?? msg;
      } catch {
      }
      setStatus(msg);
      return;
    }
    document.body.innerHTML = text;
    const form = document.getElementById("ecpay");
    if (form) form.submit();
    else setStatus("\u4ED8\u6B3E\u9801\u8F09\u5165\u7570\u5E38\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\u3002");
  } catch {
    setStatus("\u7DB2\u8DEF\u932F\u8AA4\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\u3002");
  }
})();
//# sourceMappingURL=checkout.js.map
