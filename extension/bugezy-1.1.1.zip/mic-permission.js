// src/types.ts
var MIC_KEY = "bugezy:mic-enabled";

// src/mic-permission.ts
(async () => {
  const status = document.getElementById("status");
  if (!status) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
    status.textContent = "\u2705 \u9EA5\u514B\u98A8\u5DF2\u6388\u6B0A\u6210\u529F\uFF01\u6B64\u9801\u9762 3 \u79D2\u5F8C\u81EA\u52D5\u95DC\u9589...";
    status.style.color = "#3fb950";
    await chrome.runtime.sendMessage({ type: "MIC_PERMISSION_GRANTED" });
    await chrome.storage.local.set({ [MIC_KEY]: true });
    setTimeout(() => window.close(), 3e3);
  } catch {
    status.textContent = "\u274C \u6388\u6B0A\u88AB\u62D2\u7D55\u3002\u8ACB\u5728\u700F\u89BD\u5668\u8A2D\u5B9A\u4E2D\u5141\u8A31\u9EA5\u514B\u98A8\u5F8C\u91CD\u8A66\u3002";
    status.style.color = "#f85149";
  }
})();
//# sourceMappingURL=mic-permission.js.map
