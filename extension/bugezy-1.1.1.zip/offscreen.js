// src/offscreen.ts
var mediaRecorder = null;
var chunks = [];
var audioCtx = null;
var analyser = null;
var volumeTimer = null;
async function startVolumeMeter(stream) {
  try {
    audioCtx = new AudioContext();
    if (audioCtx.state === "suspended") {
      try {
        await audioCtx.resume();
      } catch (e) {
        console.warn("[BugEzy offscreen] AudioContext resume \u5931\u6557:", e);
      }
    }
    const source = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    volumeTimer = setInterval(() => {
      if (!analyser) return;
      analyser.getByteFrequencyData(dataArray);
      const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
      const level = Math.min(avg / 128, 1);
      chrome.runtime.sendMessage({ type: "MIC_VOLUME", level }).catch(() => {
      });
    }, 200);
    console.log("[BugEzy offscreen] \u97F3\u91CF\u5206\u6790\u555F\u52D5\uFF08AudioContext state=" + audioCtx.state + "\uFF09");
  } catch (err) {
    console.error("[BugEzy offscreen] \u97F3\u91CF\u5206\u6790\u555F\u52D5\u5931\u6557:", err);
  }
}
function stopVolumeMeter() {
  if (volumeTimer) {
    clearInterval(volumeTimer);
    volumeTimer = null;
  }
  if (audioCtx) {
    void audioCtx.close();
    audioCtx = null;
    analyser = null;
  }
}
async function startRecording() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        sampleRate: 16e3,
        // Whisper 最佳
        echoCancellation: true,
        noiseSuppression: true
      }
    });
    chunks = [];
    mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm;codecs=opus" });
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };
    mediaRecorder.start(1e3);
    void startVolumeMeter(stream);
    console.log("[BugEzy offscreen] \u9304\u97F3\u958B\u59CB");
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
    console.error("[BugEzy offscreen] getUserMedia \u5931\u6557:", msg);
    return { ok: false, error: msg };
  }
}
function stopRecording() {
  return new Promise((resolve) => {
    if (!mediaRecorder || mediaRecorder.state === "inactive") {
      resolve({ error: "\u672A\u5728\u9304\u97F3\u4E2D" });
      return;
    }
    const rec = mediaRecorder;
    stopVolumeMeter();
    rec.onstop = () => {
      const blob = new Blob(chunks, { type: "audio/webm;codecs=opus" });
      console.log(
        `[BugEzy offscreen] recording stopped, blob size=${blob.size}, type=${blob.type}, chunks=${chunks.length}`
      );
      chunks = [];
      rec.stream.getTracks().forEach((t) => t.stop());
      mediaRecorder = null;
      if (blob.size < 100) {
        console.warn(`[BugEzy offscreen] Blob \u592A\u77ED\uFF08size=${blob.size}\uFF09\u2192 \u4E0D\u8F49\u9304`);
        resolve({ error: "\u9304\u97F3\u592A\u77ED" });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => resolve({ audioBlob: reader.result });
      reader.readAsDataURL(blob);
    };
    rec.stop();
  });
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "OFFSCREEN_START_MIC") {
    startRecording().then(sendResponse);
    return true;
  } else if (msg?.type === "OFFSCREEN_STOP_MIC") {
    stopRecording().then(sendResponse);
    return true;
  }
});
//# sourceMappingURL=offscreen.js.map
