// src/types.ts
var BUGEZY_DEBUG = true;
var BUGEZY_SOURCE = "bugezy";
var STORAGE_KEY = "bugezy:lastPayload";
var LANG_KEY = "bugezy:language";
var SPEECH_LANG_MAP = {
  zh: "zh-TW",
  yue: "zh-HK",
  ja: "ja",
  ko: "ko",
  en: "en",
  vi: "vi"
};
var KEYBOARD_MODE_KEY = "bugezy:keyboardMode";
var TOOLBAR_EFFECT_KEY = "bugezy:toolbar-effect";
var MIC_KEY = "bugezy:mic-enabled";
var MIC_MODE_KEY = "bugezy:mic-mode";
var USER_PLAN_KEY = "bugezy:user-plan";
function blog(...args) {
  if (BUGEZY_DEBUG) console.log("[BugEzy]", ...args);
}

// src/i18n.ts
function getUILang(speechLang) {
  if (speechLang === "zh" || speechLang === "yue") return "zh";
  return "en";
}
var dict = {
  // ── 登入 ──
  "login-hint": { zh: "\u767B\u5165\u5F8C\u958B\u59CB\u4F7F\u7528", en: "Sign in to get started" },
  "login-google": { zh: "\u7528 Google \u767B\u5165", en: "Sign in with Google" },
  "login-loading": { zh: "\u767B\u5165\u4E2D...", en: "Signing in..." },
  "login-failed": { zh: "\u767B\u5165\u5931\u6557\uFF0C\u91CD\u8A66", en: "Login failed, retry" },
  // ── 頂部 ──
  logout: { zh: "\u767B\u51FA", en: "Logout" },
  "voice-bug-report": { zh: "\u8A9E\u97F3 Bug \u56DE\u5831", en: "Voice Bug Report" },
  "voice-mode": { zh: "\u8A9E\u97F3\u6A21\u5F0F", en: "Voice Mode" },
  "mode-realtime": { zh: "\u5373\u6642\u5B57\u5E55", en: "Live Caption" },
  "mode-whisper": { zh: "\u7CBE\u6E96\u8F49\u9304", en: "Precise" },
  "settings-locked": { zh: "\u{1F512} \u9304\u88FD\u4E2D\uFF0C\u8A2D\u5B9A\u5DF2\u9396\u5B9A", en: "\u{1F512} Recording, settings locked" },
  // ── 三大模式卡片 ──
  "mode-record": { zh: "\u9304\u88FD", en: "Record" },
  "mode-record-desc": { zh: "DOM + \u8A9E\u97F3 + Console", en: "DOM + Voice + Console" },
  "mode-rewind": { zh: "\u56DE\u6EAF 30s", en: "Rewind 30s" },
  "mode-rewind-desc": { zh: "\u6293\u525B\u624D\u7684 Bug", en: "Catch recent Bug" },
  "mode-screenshot": { zh: "\u622A\u5716\u6A19\u6CE8", en: "Screenshot" },
  "mode-screenshot-desc": { zh: "\u5FEB\u901F\u64F7\u53D6 + \u756B\u91CD\u9EDE", en: "Capture + Annotate" },
  // ── 用量（動態）──
  unlimited: { zh: "\u2728 \u7121\u9650\u6B21", en: "\u2728 Unlimited" },
  remaining: { zh: "\u5269 {n} \u6B21", en: "{n} left" },
  "used-up": { zh: "\u5DF2\u7528\u5B8C\uFF08\u5347\u7D1A\u89E3\u9396\uFF09", en: "Used up (upgrade)" },
  // ── 日票 / 月費 ──
  "upgrade-unlock": { zh: "\u5347\u7D1A\u89E3\u9396\u7121\u9650\u6B21", en: "Upgrade for unlimited" },
  "my-reports": { zh: "\u{1F4CB} \u6211\u7684\u5831\u544A", en: "\u{1F4CB} My Reports" },
  // PM-184
  // PM-185：截圖敏感偵測 + 馬賽克
  "sf-password": { zh: "\u5BC6\u78BC\u6B04\u4F4D", en: "password fields" },
  "sf-token": { zh: "Token \u6B04\u4F4D", en: "token fields" },
  "sf-secret": { zh: "Secret \u6B04\u4F4D", en: "secret fields" },
  "sf-key": { zh: "API Key \u6B04\u4F4D", en: "API key fields" },
  "sf-card": { zh: "\u4FE1\u7528\u5361\u6B04\u4F4D", en: "credit card fields" },
  "sf-cvv": { zh: "CVV \u6B04\u4F4D", en: "CVV fields" },
  "sf-marked": { zh: "\u6A19\u8A18\u70BA\u654F\u611F\u7684\u5143\u7D20", en: "sensitive-marked elements" },
  "sensitive-sep": { zh: "\u3001", en: ", " },
  "sensitive-title": { zh: "\u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D", en: "Sensitive fields detected" },
  "sensitive-page-has": { zh: "\u9801\u9762\u4E0A\u6709\uFF1A{fields}", en: "This page contains: {fields}" },
  "sensitive-hint": {
    zh: "\u622A\u5716\u5F8C\u53EF\u7528 \u{1F512} \u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u654F\u611F\u5340\u57DF\u518D\u4E0A\u50B3",
    en: "Use the \u{1F512} mosaic brush to cover sensitive areas before uploading"
  },
  "sensitive-continue": { zh: "\u7E7C\u7E8C\u622A\u5716", en: "Continue" },
  "sensitive-cancel": { zh: "\u53D6\u6D88", en: "Cancel" },
  "sensitive-tip": {
    zh: "\u{1F512} \u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D\uFF0C\u5EFA\u8B70\u7528\u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u518D\u4E0A\u50B3",
    en: "\u{1F512} Sensitive fields detected \u2014 use the mosaic brush to cover them before uploading"
  },
  "annotate-mosaic": { zh: "\u{1F512} \u99AC\u8CFD\u514B", en: "\u{1F512} Mosaic" },
  // PM-186：自動遮罩
  "auto-masked": { zh: "\u{1F512} \u5DF2\u81EA\u52D5\u906E\u7F69 {n} \u500B\u654F\u611F\u6B04\u4F4D", en: "\u{1F512} Auto-masked {n} sensitive field(s)" },
  "undo-mask": { zh: "\u64A4\u92B7\u906E\u7F69", en: "Undo mask" },
  "day-pass-btn": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr\uFF09", en: "\u26A1 Day Pass NT$20 (24hr)" },
  "monthly-btn": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708", en: "\u2728 Monthly NT$80/mo" },
  // PM-170：用完升級引導 overlay
  "usage-exhausted": { zh: "\u672C\u6708\u984D\u5EA6\u5DF2\u7528\u5B8C", en: "Monthly quota exhausted" },
  "usage-desc-record": { zh: "\u9304\u88FD {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Recording {used}/{max} used" },
  "usage-desc-rewind": { zh: "\u56DE\u6EAF {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Rewind {used}/{max} used" },
  "usage-desc-mcp": { zh: "MCP AI \u8B80\u53D6 {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "MCP AI reads {used}/{max} used" },
  "usage-reset-hint": { zh: "\u{1F4A1} \u514D\u8CBB\u984D\u5EA6\u6BCF\u6708\u81EA\u52D5\u91CD\u7F6E", en: "\u{1F4A1} Free quota resets monthly" },
  "day-pass-btn-full": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr \u7121\u9650\uFF09", en: "\u26A1 Day Pass NT$20 (24hr unlimited)" },
  "monthly-btn-full": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708\uFF08\u6700\u5212\u7B97\uFF09", en: "\u2728 Monthly NT$80/mo (best value)" },
  // PM-171：非台灣付費 coming soon
  "intl-coming-soon": { zh: "\u{1F30F} \u570B\u969B\u4ED8\u6B3E\u5373\u5C07\u958B\u653E", en: "\u{1F30F} International Payments Coming Soon!" },
  "intl-desc": {
    zh: "\u6211\u5011\u6B63\u5728\u958B\u901A\u570B\u969B\u4FE1\u7528\u5361\u4ED8\u6B3E\uFF0C\u656C\u8ACB\u671F\u5F85\uFF01",
    en: "We're working on enabling international credit card payments. Stay tuned!"
  },
  "intl-free-hint": {
    zh: "\u{1F4A1} \u514D\u8CBB\u7248\u73FE\u5728\u5C31\u80FD\u7528 \u2014 \u6BCF\u6708 10 \u6B21\u9304\u88FD + 20 \u6B21 MCP AI \u8B80\u53D6",
    en: "\u{1F4A1} Free plan available now \u2014 10 recordings + 20 MCP AI reads per month"
  },
  "day-pass-badge": { zh: "\u26A1 \u65E5\u7968", en: "\u26A1 Day Pass" },
  "day-pass-remaining": { zh: "\u5269\u9918 {h}h {m}m {s}s", en: "{h}h {m}m {s}s left" },
  "day-pass-expire-hint": {
    zh: "\u65E5\u7968\u5230\u671F\u5F8C\u53EF\u5347\u7D1A\u6708\u8CBB",
    en: "Upgrade to monthly after day pass expires"
  },
  "paid-badge": { zh: "\u2728 \u4ED8\u8CBB\u7248\u6703\u54E1", en: "\u2728 Premium Member" },
  "cancel-sub": { zh: "\u53D6\u6D88\u8A02\u95B1", en: "Cancel" },
  "cancelled-prefix": { zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\uFF0C\u53EF\u7528\u5230", en: "Cancelled, active until" },
  resub: { zh: "\u91CD\u65B0\u8A02\u95B1", en: "Resubscribe" },
  // ── 進階設定 ──
  "lang-label": { zh: "\u{1F310} \u8A9E\u97F3\u8A9E\u8A00", en: "\u{1F310} Voice Language" },
  "advanced-settings": { zh: "\u2699\uFE0F \u9032\u968E\u8A2D\u5B9A", en: "\u2699\uFE0F Advanced Settings" },
  "monitor-toggle": { zh: "\u{1F50D} \u5373\u6642\u76E3\u63A7\uFF08AI \u53EF\u67E5 error\uFF09", en: "\u{1F50D} Live Monitor (AI reads errors)" },
  "keyboard-toggle": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F\uFF08\u95DC\u9589\u8A9E\u97F3\uFF09", en: "\u{1F507} Keyboard Mode (no voice)" },
  "hq-toggle": { zh: "\u{1F4F8} \u9AD8\u756B\u8CEA AI \u5206\u6790\uFF08\u9AD8 Token\uFF09", en: "\u{1F4F8} HQ AI Analysis (high Token)" },
  "effect-toggle": { zh: "\u2728 \u5DE5\u5177\u5217\u7279\u6548", en: "\u2728 Toolbar Effects" },
  // ── AI 輪盤 ──
  "carousel-title": { zh: "\u4E00\u9375\u8907\u88FD\u6307\u4EE4\u8CBC\u7D66 AI", en: "Copy prompt to AI" },
  "copy-btn": { zh: "\u8907\u88FD", en: "Copy" },
  "edit-btn": { zh: "\u270F\uFE0F \u7DE8\u8F2F", en: "\u270F\uFE0F Edit" },
  "save-btn": { zh: "\u{1F4BE} \u5132\u5B58", en: "\u{1F4BE} Save" },
  "cancel-btn": { zh: "\u53D6\u6D88", en: "Cancel" },
  // ── 錄製中 / 完成 ──
  "stop-recording": { zh: "\u23F9 \u505C\u6B62\u9304\u88FD", en: "\u23F9 Stop Recording" },
  "done-title": { zh: "\u2705 \u9304\u88FD\u5B8C\u6210\uFF01", en: "\u2705 Recording Done!" },
  "sum-dom": { zh: "DOM \u4E8B\u4EF6", en: "DOM Events" },
  "sum-console": { zh: "Console", en: "Console" },
  "sum-network": { zh: "Network \u932F\u8AA4", en: "Network Errors" },
  "sum-voice": { zh: "\u8A9E\u97F3\u7247\u6BB5", en: "Voice Clips" },
  "sum-time": { zh: "\u6642\u9593", en: "Duration" },
  "duration-sec": { zh: "{n} \u79D2", en: "{n}s" },
  "copy-json": { zh: "\u{1F4CB} \u8907\u88FD JSON", en: "\u{1F4CB} Copy JSON" },
  "export-json": { zh: "\u{1F4BE} \u532F\u51FA JSON\uFF08\u7D66 AI \u8B80\uFF09", en: "\u{1F4BE} Export JSON (for AI)" },
  "clear-restart": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\uFF0C\u91CD\u65B0\u9304\u88FD", en: "\u{1F5D1}\uFE0F Clear & Restart" },
  "copy-link": { zh: "\u{1F4CB} \u8907\u88FD\u9023\u7D50", en: "\u{1F4CB} Copy Link" },
  // ── mic OFF 提示 ──
  "mic-prompt-title": { zh: "\u9EA5\u514B\u98A8\u76EE\u524D\u95DC\u9589", en: "Microphone is off" },
  "mic-prompt-desc": { zh: "\u8981\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \u55CE\uFF1F", en: "Use voice to describe the bug?" },
  "mic-prompt-on": { zh: "\u958B\u555F\u4E26\u9304\u88FD", en: "Turn on & record" },
  "mic-prompt-skip": { zh: "\u76F4\u63A5\u9304\u88FD\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Record without voice" },
  // ── 版本（動態）──
  "update-available": {
    zh: "\u{1F195} \u76EE\u524D v{cur} \u2192 \u65B0\u7248 v{new} \u53EF\u7528",
    en: "\u{1F195} v{cur} \u2192 v{new} available"
  },
  // ── PM-139：截圖工具列（content.ts）──
  "toolbar-fullpage": { zh: "\u{1F4F7} \u6574\u9801", en: "\u{1F4F7} Full Page" },
  "toolbar-region": { zh: "\u2B1C \u5340\u57DF\uFF08\u5169\u9EDE\uFF09", en: "\u2B1C Region (2 clicks)" },
  "toolbar-freeform": { zh: "\u2702\uFE0F \u81EA\u7531\u5F62\u72C0", en: "\u2702\uFE0F Freeform" },
  "toolbar-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "toolbar-select-mode": { zh: "\u9078\u64C7\u622A\u5716\u6A21\u5F0F", en: "Select screenshot mode" },
  "toolbar-region-hint": { zh: "\u53EF\u81EA\u7531\u6372\u52D5\u9801\u9762\uFF0C\u9EDE\u7B2C\u4E8C\u4E0B\u6A19\u8A18\u7D42\u9EDE", en: "Scroll freely, click again to set the end point" },
  "transcribing": { zh: "\u23F3 \u8A9E\u97F3\u8F49\u9304\u4E2D\u2026", en: "\u23F3 Transcribing\u2026" },
  // ── PM-139：即時監控（inject.ts，經 it()）──
  "monitor-active": { zh: "\u{1F7E2} BugEzy \u76E3\u63A7\u4E2D", en: "\u{1F7E2} BugEzy Monitoring" },
  "monitor-errors": { zh: "\u26A0\uFE0F \u767C\u73FE {n} \u500B\u932F\u8AA4\uFF08\u9EDE\u6211\u67E5\u770B\uFF09", en: "\u26A0\uFE0F {n} error(s) found (click to view)" },
  "monitor-errors-title": { zh: "BugEzy \u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4\uFF0C\u9EDE\u6211\u67E5\u770B", en: "BugEzy found {n} error(s), click to view" },
  "monitor-panel-title": { zh: "\u{1F41B} \u5373\u6642\u76E3\u63A7\u932F\u8AA4", en: "\u{1F41B} Live Monitor Errors" },
  "monitor-empty": { zh: "\u2713 \u76EE\u524D\u7121\u932F\u8AA4", en: "\u2713 No errors" },
  "monitor-upload": { zh: "\u{1F4E4} \u4E0A\u50B3\u5831\u544A\u8B93 AI \u5206\u6790", en: "\u{1F4E4} Upload report for AI analysis" },
  "monitor-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D\u2026", en: "\u23F3 Uploading\u2026" },
  "monitor-uploaded": { zh: "\u2705 \u5DF2\u4E0A\u50B3\uFF01\u9EDE\u6B64\u67E5\u770B\u5831\u544A", en: "\u2705 Uploaded! Click to view report" },
  "monitor-upload-fail": { zh: "\u274C \u4E0A\u50B3\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66", en: "\u274C Upload failed, click to retry" },
  "monitor-desc": { zh: "\u5373\u6642\u76E3\u63A7\u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4", en: "Live monitor found {n} error(s)" },
  // ── PM-139：錄製字幕 / 麥克風授權（inject.ts，經 it()）──
  "caption-recording": { zh: "\u{1F399} \u9304\u88FD\u4E2D\uFF0C\u53EF\u4EE5\u7528\u4E2D\u6587\u63CF\u8FF0\u554F\u984C\u2026", en: "\u{1F399} Recording \u2014 describe the issue by voice\u2026" },
  "caption-voice-log": { zh: "\u{1F4DD} \u8A9E\u97F3\u8A18\u9304", en: "\u{1F4DD} Voice Log" },
  "keyboard-bar": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F \u2014 \u9304\u88FD\u4E2D\uFF08\u8A9E\u97F3\u5DF2\u95DC\u9589\uFF09", en: "\u{1F507} Keyboard mode \u2014 recording (voice off)" },
  "whisper-bar": { zh: "\u{1F399}\uFE0F \u9304\u97F3\u4E2D\u2026\uFF08\u505C\u6B62\u5F8C\u81EA\u52D5\u8F49\u9304\uFF09", en: "\u{1F399}\uFE0F Recording\u2026\uFF08auto-transcribe on stop\uFF09" },
  "mic-perm-title": { zh: "BugEzy \u9700\u8981\u9EA5\u514B\u98A8\u6B0A\u9650", en: "BugEzy needs microphone access" },
  "mic-perm-desc": { zh: "\u5141\u8A31\u5F8C\u53EF\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \xB7 \u6B64\u7DB2\u7AD9\u53EA\u9700\u6388\u6B0A\u4E00\u6B21", en: "Allow to describe bugs by voice \xB7 one-time per site" },
  "mic-perm-allow": { zh: "\u5141\u8A31\u9EA5\u514B\u98A8", en: "Allow microphone" },
  "mic-perm-skip": { zh: "\u8DF3\u904E\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Skip (no voice)" },
  // ── PM-139：截圖標注頁（annotate）──
  "annotate-pen": { zh: "\u270F\uFE0F \u756B\u7B46", en: "\u270F\uFE0F Pen" },
  "annotate-arrow": { zh: "\u27A1\uFE0F \u7BAD\u982D", en: "\u27A1\uFE0F Arrow" },
  "annotate-rect": { zh: "\u2B1C \u6846\u6846", en: "\u2B1C Box" },
  "annotate-text": { zh: "\u{1F4DD} \u6587\u5B57", en: "\u{1F4DD} Text" },
  "annotate-color": { zh: "\u984F\u8272", en: "Color" },
  "annotate-thickness": { zh: "\u7C97\u7D30", en: "Width" },
  "annotate-thin": { zh: "\u7D30", en: "Thin" },
  "annotate-mid": { zh: "\u4E2D", en: "Medium" },
  "annotate-thick": { zh: "\u7C97", en: "Thick" },
  "annotate-undo": { zh: "\u21A9\uFE0F \u5FA9\u539F", en: "\u21A9\uFE0F Undo" },
  "annotate-clear": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\u5168\u90E8", en: "\u{1F5D1}\uFE0F Clear All" },
  "annotate-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "annotate-save": { zh: "\u2705 \u5B8C\u6210\u5132\u5B58", en: "\u2705 Save" },
  "annotate-desc-label": { zh: "\u{1F4AC} \u554F\u984C\u63CF\u8FF0\uFF08\u9078\u586B\uFF09", en: "\u{1F4AC} Description (optional)" },
  "annotate-desc-ph": { zh: "\u63CF\u8FF0\u4F60\u770B\u5230\u7684\u554F\u984C\uFF0C\u6216\u6309\u53F3\u908A\u9EA5\u514B\u98A8\u8A9E\u97F3\u8F38\u5165...", en: "Describe the issue, or tap the mic on the right to dictate..." },
  "annotate-listening": { zh: "\u{1F534} \u8046\u807D\u4E2D\uFF0C\u908A\u756B\u908A\u8AAA\u63CF\u8FF0\u554F\u984C...", en: "\u{1F534} Listening \u2014 describe while you draw..." },
  "annotate-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D...", en: "\u23F3 Uploading..." },
  // ── PM-139：alert / confirm（popup.ts）──
  "confirm-cancel-sub": {
    zh: "\u78BA\u5B9A\u8981\u53D6\u6D88\u6708\u8CBB\u8A02\u95B1\u55CE\uFF1F\n\u53D6\u6D88\u5F8C\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\uFF0C\u5230\u671F\u5F8C\u81EA\u52D5\u964D\u56DE\u514D\u8CBB\u7248\u3002",
    en: "Cancel your monthly subscription?\nYou can still use premium features until the end of your billing period."
  },
  "alert-cancelled": {
    zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\u3002\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\u3002",
    en: "Subscription cancelled. Premium features remain active until end of billing period."
  },
  "alert-cancel-fail": { zh: "\u53D6\u6D88\u5931\u6557\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66", en: "Cancellation failed, please try again later" }
};
function t(key, lang, params) {
  const entry = dict[key];
  let text = entry?.[lang] || entry?.["zh"] || key;
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      text = text.replace(`{${k}}`, String(v));
    }
  }
  return text;
}

// src/content.ts
blog("content loaded\uFF08ISOLATED world\uFF09", location.href);
var contentUILang = "zh";
function ct(key, params) {
  return t(key, contentUILang, params);
}
function applyBugezyLang(speechLang) {
  document.documentElement.setAttribute("data-bugezy-lang", speechLang);
  contentUILang = getUILang(speechLang);
}
void chrome.storage.local.get(LANG_KEY, (r) => applyBugezyLang(r[LANG_KEY] || "zh"));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[LANG_KEY]) {
    applyBugezyLang(changes[LANG_KEY].newValue || "zh");
  }
});
var injectReady = false;
function sendToInject(cmd, keyboardMode, micEnabled, whisperMode, speechLang) {
  const msg = {
    source: BUGEZY_SOURCE,
    dir: "to-inject",
    cmd,
    keyboardMode,
    micEnabled,
    whisperMode,
    speechLang
  };
  blog(
    `\u2192 \u8F49\u9001 ${cmd} \u7D66 inject\uFF08keyboardMode=${keyboardMode === true}, micEnabled=${micEnabled === true}, whisperMode=${whisperMode === true}\uFF09`
  );
  window.postMessage(msg, "*");
}
async function computeStartFlags() {
  const r = await chrome.storage.local.get([
    KEYBOARD_MODE_KEY,
    MIC_KEY,
    USER_PLAN_KEY,
    MIC_MODE_KEY,
    LANG_KEY
  ]);
  const keyboardMode = r[KEYBOARD_MODE_KEY] === true;
  const speechLang = SPEECH_LANG_MAP[r[LANG_KEY] || "zh"] || "zh-TW";
  const micEnabled = r[MIC_KEY] === true;
  if (!micEnabled) return { keyboardMode, useOldVoice: false, whisperMode: false, speechLang };
  const plan = r[USER_PLAN_KEY] || "free";
  const mode = plan === "free" ? "realtime" : r[MIC_MODE_KEY] || "whisper";
  return {
    keyboardMode,
    useOldVoice: mode === "realtime",
    whisperMode: mode === "whisper",
    speechLang
  };
}
function summarize(payload) {
  return {
    domEvents: payload.rrwebEvents.length,
    consoleLogs: payload.consoleLogs.length,
    networkErrors: payload.networkErrors.length,
    pageInfo: payload.pageInfo,
    durationMs: 0,
    // 由 background 依 startedAt 回填
    voiceSegments: payload.voiceTranscript.length,
    uploadStatus: "idle",
    // 由 background RECORDING_DONE 後接手上傳
    shareUrl: null,
    uploadError: null
  };
}
window.addEventListener("message", async (e) => {
  if (e.source !== window) return;
  const data = e.data;
  if (!data || data.source !== BUGEZY_SOURCE || data.dir !== "to-content") return;
  if (data.kind === "FLUSH_VOICE") {
    chrome.runtime.sendMessage({ type: "FLUSH_VOICE", segment: data.segment });
    return;
  }
  if (data.kind === "FLUSH_CONSOLE") {
    chrome.runtime.sendMessage({ type: "FLUSH_CONSOLE", log: data.log });
    return;
  }
  if (data.kind === "FLUSH_NETWORK") {
    chrome.runtime.sendMessage({ type: "FLUSH_NETWORK", error: data.error });
    return;
  }
  if (data.kind === "FLUSH_RRWEB") {
    chrome.runtime.sendMessage({ type: "FLUSH_RRWEB", events: data.events });
    return;
  }
  if (data.kind === "REQUEST_VOICE_HISTORY") {
    chrome.runtime.sendMessage({ type: "GET_VOICE_BUFFER" }, (response) => {
      const segments = response?.segments;
      if (segments && segments.length > 0) {
        window.postMessage(
          { source: BUGEZY_SOURCE, dir: "to-inject", kind: "VOICE_HISTORY", segments },
          "*"
        );
      }
    });
    return;
  }
  if (data.kind === "READY") {
    injectReady = true;
    blog("\u2713 inject \u5DF2\u5831\u5230\uFF08READY\uFF09");
    window.postMessage({ source: BUGEZY_SOURCE, dir: "to-inject", kind: "READY_ACK" }, "*");
    return;
  }
  if (data.kind === "STARTED") {
    blog(`\u2713 inject \u5DF2\u958B\u59CB\u9304\u88FD\uFF08rrwebOk=${data.rrwebOk}\uFF09`);
    return;
  }
  if (data.kind === "RESULT") {
    const payload = data.payload;
    blog("\u2713 \u6536\u5230 inject \u6253\u5305\u8CC7\u6599", {
      dom: payload.rrwebEvents.length,
      console: payload.consoleLogs.length,
      network: payload.networkErrors.length,
      voice: payload.voiceTranscript.length
    });
    chrome.storage.local.set({ [STORAGE_KEY]: payload }, () => {
      chrome.runtime.sendMessage({ type: "RECORDING_DONE", summary: summarize(payload) });
    });
  }
  if (data.kind === "UPLOAD_MONITOR") {
    chrome.runtime.sendMessage(
      { type: "UPLOAD_MONITOR_REPORT", payload: data.payload },
      (resp) => {
        window.postMessage(
          {
            source: BUGEZY_SOURCE,
            dir: "to-inject",
            kind: "MONITOR_UPLOADED",
            reportUrl: resp?.shareUrl,
            error: resp?.ok ? void 0 : resp?.error ?? "\u4E0A\u50B3\u5931\u6557"
          },
          "*"
        );
      }
    );
  }
  if (data.kind === "REWIND_RESULT") {
    const payload = data.payload;
    blog("\u2713 \u6536\u5230 REWIND \u6253\u5305\u8CC7\u6599", {
      dom: payload.rrwebEvents.length,
      console: payload.consoleLogs.length,
      network: payload.networkErrors.length
    });
    chrome.storage.local.set({ [STORAGE_KEY]: payload }, () => {
      chrome.runtime.sendMessage({ type: "REWIND_DONE", summary: summarize(payload) });
    });
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "START_RECORDING") {
    void computeStartFlags().then(({ keyboardMode, useOldVoice, whisperMode, speechLang }) => {
      sendToInject("START", keyboardMode, useOldVoice, whisperMode, speechLang);
      sendResponse({ ok: true });
    });
  } else if (msg.type === "STOP_RECORDING") {
    sendToInject("STOP");
    sendResponse({ ok: true });
  } else if (msg.type === "WHISPER_TRANSCRIBING") {
    const el = document.getElementById("bugezy-caption-text");
    if (el) el.textContent = ct("transcribing");
    sendResponse({ ok: true });
  } else if (msg.type === "MIC_VOLUME") {
    window.dispatchEvent(new CustomEvent("bugezy-mic-volume", { detail: { level: msg.level } }));
    sendResponse({ ok: true });
  } else if (msg.type === "START_SCREENSHOT") {
    const sensitive = detectSensitiveFields();
    if (sensitive.length > 0) {
      const rectPayload = {
        rects: getSensitiveRects(),
        viewportWidth: window.innerWidth,
        viewportHeight: window.innerHeight
      };
      showSensitiveWarning(sensitive, () => {
        void chrome.storage.local.set({ [SENSITIVE_DETECTED_KEY]: true, [SENSITIVE_RECTS_KEY]: rectPayload });
        injectScreenshotOverlay();
      });
    } else {
      void chrome.storage.local.remove([SENSITIVE_DETECTED_KEY, SENSITIVE_RECTS_KEY]);
      injectScreenshotOverlay();
    }
    sendResponse({ ok: true });
  } else if (msg.type === "REWIND_30S") {
    sendToInject("REWIND");
    sendResponse({ ok: true });
  } else if (msg.type === "GET_LIVE_ERRORS") {
    void queryInjectLiveErrors().then(sendResponse);
  } else if (msg.type === "SET_MONITOR_BADGE") {
    sendToInject(msg.show ? "SHOW_MONITOR" : "HIDE_MONITOR");
    sendResponse({ ok: true });
  }
  return true;
});
(async () => {
  try {
    const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
    if (!state?.recording) return;
    blog("\u5075\u6E2C\u5230\u6B63\u5728\u9304\u88FD\u4E2D\uFF0C\u81EA\u52D5\u6062\u5FA9 inject \u9304\u88FD");
    const { keyboardMode: km, useOldVoice, whisperMode, speechLang } = await computeStartFlags();
    const waitForInject = (retries = 0) => {
      if (injectReady) {
        sendToInject("START", km, useOldVoice, whisperMode, speechLang);
        blog("\u5DF2\u9001 START \u7D66 inject\uFF08\u8DF3\u9801\u6062\u5FA9\uFF09");
      } else if (retries < 40) {
        setTimeout(() => waitForInject(retries + 1), 50);
      } else {
        blog("\u26A0 inject \u672A\u5C31\u7DD2\uFF0C\u8DF3\u9801\u6062\u5FA9\u5931\u6557");
      }
    };
    waitForInject();
  } catch {
  }
})();
var SENSITIVE_DETECTED_KEY = "bugezy:sensitive-detected";
var SENSITIVE_RECTS_KEY = "bugezy:sensitive-rects";
var SENSITIVE_RECT_SELECTORS = [
  { sel: 'input[type="password"]', label: "password" },
  { sel: 'input[name*="password" i]', label: "password" },
  { sel: 'input[name*="passwd" i]', label: "password" },
  { sel: 'input[autocomplete="current-password"]', label: "password" },
  { sel: 'input[autocomplete="new-password"]', label: "password" },
  { sel: 'input[name*="secret" i]', label: "secret" },
  { sel: 'input[name*="token" i]', label: "token" },
  { sel: 'input[name*="key" i]:not([name*="keyboard" i])', label: "key" },
  { sel: 'input[name*="card" i]', label: "card" },
  { sel: 'input[autocomplete*="cc-"]', label: "card" },
  { sel: 'input[name*="cvv" i]', label: "cvv" },
  { sel: 'input[name*="cvc" i]', label: "cvv" },
  { sel: "[data-sensitive]", label: "sensitive" }
];
function getSensitiveRects() {
  const seen = /* @__PURE__ */ new Set();
  const rects = [];
  for (const { sel, label } of SENSITIVE_RECT_SELECTORS) {
    let els;
    try {
      els = document.querySelectorAll(sel);
    } catch {
      continue;
    }
    els.forEach((el) => {
      if (seen.has(el)) return;
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0 && r.top < window.innerHeight && r.left < window.innerWidth) {
        seen.add(el);
        rects.push({ x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width), height: Math.round(r.height), label });
      }
    });
  }
  return rects;
}
function detectSensitiveFields() {
  const groups = [
    { key: "sf-password", sels: ['input[type="password"]', 'input[name*="password" i]', 'input[name*="passwd" i]', 'input[autocomplete="current-password"]', 'input[autocomplete="new-password"]'] },
    { key: "sf-token", sels: ['input[name*="token" i]'] },
    { key: "sf-secret", sels: ['input[name*="secret" i]'] },
    { key: "sf-key", sels: ['input[name*="key" i]', 'input[name*="apikey" i]'] },
    { key: "sf-card", sels: ['input[name*="card" i]', 'input[autocomplete*="cc-"]'] },
    { key: "sf-cvv", sels: ['input[name*="cvv" i]', 'input[name*="cvc" i]'] },
    { key: "sf-marked", sels: ["[data-sensitive]"] }
  ];
  const found = [];
  for (const g of groups) {
    if (g.sels.some((s) => document.querySelector(s))) found.push(g.key);
  }
  return found;
}
function showSensitiveWarning(fieldKeys, onContinue) {
  document.getElementById("bugezy-sensitive-warning")?.remove();
  const overlay = document.createElement("div");
  overlay.id = "bugezy-sensitive-warning";
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;z-index:2147483647;font-family:-apple-system,system-ui,"Microsoft JhengHei",sans-serif;';
  const fieldsDesc = fieldKeys.map((k) => ct(k)).join(ct("sensitive-sep"));
  const card = document.createElement("div");
  card.style.cssText = "background:#1a1a2e;border:2px solid #f59e0b;border-radius:16px;padding:24px;max-width:360px;text-align:center;";
  card.innerHTML = `<p style="font-size:28px;margin:0 0 8px;">\u26A0\uFE0F</p><p style="color:#f59e0b;font-size:16px;font-weight:700;margin:0 0 8px;"></p><p style="color:#e6edf3;font-size:13px;margin:0 0 4px;"></p><p style="color:#9aa3b2;font-size:12px;margin:0 0 16px;"></p><div style="display:flex;gap:8px;justify-content:center;"><button id="bz-sens-continue" style="background:#7c3aed;color:#fff;border:none;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:600;cursor:pointer;"></button><button id="bz-sens-cancel" style="background:transparent;color:#888;border:1px solid #444;border-radius:8px;padding:10px 20px;font-size:14px;cursor:pointer;"></button></div>`;
  const ps = card.querySelectorAll("p");
  ps[1].textContent = ct("sensitive-title");
  ps[2].textContent = ct("sensitive-page-has", { fields: fieldsDesc });
  ps[3].textContent = ct("sensitive-hint");
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  card.querySelector("#bz-sens-continue").textContent = ct("sensitive-continue");
  card.querySelector("#bz-sens-cancel").textContent = ct("sensitive-cancel");
  card.querySelector("#bz-sens-continue").onclick = () => {
    overlay.remove();
    onContinue();
  };
  card.querySelector("#bz-sens-cancel").onclick = () => overlay.remove();
}
var SS_TOOLBAR_ID = "bugezy-ss-toolbar";
var SS_OVERLAY_ID = "bugezy-ss-overlay";
var SS_CANVAS_ID = "bugezy-ss-canvas";
var SS_DOT_ID = "bugezy-ss-dot";
var Z_TOP = "2147483647";
var Z_LAYER = "2147483646";
var ssKeyHandler = null;
function ssCleanup() {
  [SS_TOOLBAR_ID, SS_OVERLAY_ID, SS_CANVAS_ID, SS_DOT_ID].forEach(
    (id) => document.getElementById(id)?.remove()
  );
  if (ssKeyHandler) {
    window.removeEventListener("keydown", ssKeyHandler);
    ssKeyHandler = null;
  }
}
var raf = () => new Promise((r) => requestAnimationFrame(() => r()));
async function settle() {
  await raf();
  await raf();
  await new Promise((r) => setTimeout(r, 350));
}
async function captureSegment() {
  const resp = await chrome.runtime.sendMessage({ type: "CAPTURE_SEGMENT" });
  if (!resp?.dataUrl) throw new Error(resp?.error ?? "capture \u5931\u6557");
  return resp.dataUrl;
}
function loadImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("image load \u5931\u6557"));
    img.src = dataUrl;
  });
}
function queryInjectLiveErrors() {
  return new Promise((resolve) => {
    let done = false;
    const finish = (result) => {
      if (done) return;
      done = true;
      window.removeEventListener("message", handler);
      resolve(result);
    };
    const handler = (e) => {
      const d = e.data;
      if (e.source === window && d?.source === BUGEZY_SOURCE && d?.kind === "LIVE_ERRORS_RESULT") {
        finish({ consoleLogs: d.consoleLogs ?? [], networkErrors: d.networkErrors ?? [] });
      }
    };
    window.addEventListener("message", handler);
    sendToInject("GET_LIVE_ERRORS");
    setTimeout(() => finish({ consoleLogs: [], networkErrors: [] }), 2e3);
  });
}
async function sendReady(dataUrl) {
  const { consoleLogs, networkErrors } = await queryInjectLiveErrors();
  chrome.runtime.sendMessage({
    type: "SCREENSHOT_READY",
    dataUrl,
    pageUrl: location.href,
    pageTitle: document.title,
    consoleLogs,
    networkErrors
  });
}
function setHint(text) {
  const hint = document.getElementById("bugezy-ss-hint");
  if (hint) hint.textContent = text;
}
function applyOrangePulse(bar) {
  if (!document.getElementById("bugezy-orange-pulse-style")) {
    const style = document.createElement("style");
    style.id = "bugezy-orange-pulse-style";
    style.textContent = `
      @keyframes bugezy-orange-pulse {
        0%, 100% { box-shadow: 0 0 8px rgba(255,140,0,0.3); border-color: #ff8c00; }
        50% { box-shadow: 0 0 30px rgba(255,140,0,1), 0 0 60px rgba(255,140,0,0.5); border-color: #ffaa00; }
      }
    `;
    document.head.appendChild(style);
  }
  bar.style.border = "2px solid #ff8c00";
  bar.style.boxShadow = "0 0 20px rgba(255,140,0,0.8)";
  bar.style.animation = "bugezy-orange-pulse 0.7s ease-in-out 10";
  window.setTimeout(() => {
    bar.style.animation = "none";
    bar.style.borderColor = "#444";
    bar.style.boxShadow = "0 2px 8px rgba(255,140,0,0.15)";
    bar.style.transition = "border-color 0.5s, box-shadow 0.5s";
    document.getElementById("bugezy-orange-pulse-style")?.remove();
  }, 7e3);
}
function createToolbar(onMode) {
  const bar = document.createElement("div");
  bar.id = SS_TOOLBAR_ID;
  bar.style.cssText = `position:fixed;top:0;left:0;right:0;z-index:${Z_TOP};display:flex;align-items:center;gap:8px;padding:10px 16px;background:#16213e;border-bottom:1px solid #333;font-family:system-ui,sans-serif;font-size:14px;color:#fff;`;
  chrome.storage.local.get(TOOLBAR_EFFECT_KEY, (store) => {
    if (store[TOOLBAR_EFFECT_KEY] !== false) applyOrangePulse(bar);
  });
  const modes = [
    ["full", ct("toolbar-fullpage")],
    ["area", ct("toolbar-region")],
    ["free", ct("toolbar-freeform")],
    ["cancel", ct("toolbar-cancel")]
  ];
  for (const [mode, label] of modes) {
    const b = document.createElement("button");
    b.textContent = label;
    b.dataset.mode = mode;
    b.style.cssText = `background:${mode === "cancel" ? "#dc2626" : "#333"};color:#fff;border:1px solid #555;border-radius:6px;padding:6px 14px;cursor:pointer;font-size:14px;`;
    b.addEventListener("click", () => onMode(mode));
    bar.appendChild(b);
  }
  const hint = document.createElement("span");
  hint.id = "bugezy-ss-hint";
  hint.textContent = ct("toolbar-select-mode");
  hint.style.cssText = "margin-left:8px;color:#9aa3b2;";
  bar.appendChild(hint);
  document.body.appendChild(bar);
}
function createSelectionLayer() {
  const overlay = document.createElement("div");
  overlay.id = SS_OVERLAY_ID;
  overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.3);z-index:${Z_LAYER};cursor:crosshair;`;
  document.body.appendChild(overlay);
  const canvas = document.createElement("canvas");
  canvas.id = SS_CANVAS_ID;
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.cssText = `position:fixed;inset:0;z-index:${Z_LAYER};pointer-events:none;`;
  document.body.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas 2d \u4E0D\u53EF\u7528");
  return { overlay, canvas, ctx };
}
function injectScreenshotOverlay() {
  ssCleanup();
  createToolbar((mode) => {
    if (mode === "cancel") {
      ssCleanup();
    } else if (mode === "full") {
      void startFullCapture();
    } else if (mode === "area") {
      startAreaCapture();
    } else if (mode === "free") {
      startFreeCapture();
    }
  });
}
async function startFullCapture() {
  ssCleanup();
  await settle();
  try {
    await sendReady(await captureSegment());
  } catch (err) {
    blog("\u6574\u9801\u622A\u5716\u5931\u6557", err);
  }
}
function startAreaCapture() {
  setHint("\u9EDE\u7B2C\u4E00\u4E0B\u6A19\u8A18\u8D77\u9EDE");
  const { overlay, canvas, ctx } = createSelectionLayer();
  let start = null;
  const toDoc = (e) => ({ x: e.clientX + window.scrollX, y: e.clientY + window.scrollY });
  overlay.addEventListener("mousemove", (e) => {
    if (!start) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const sx = start.x - window.scrollX;
    const sy = start.y - window.scrollY;
    ctx.strokeStyle = "#7c3aed";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(Math.min(sx, e.clientX), Math.min(sy, e.clientY), Math.abs(e.clientX - sx), Math.abs(e.clientY - sy));
  });
  overlay.addEventListener("click", (e) => {
    if (!start) {
      start = toDoc(e);
      setHint(ct("toolbar-region-hint"));
      const dot = document.createElement("div");
      dot.id = SS_DOT_ID;
      dot.style.cssText = `position:absolute;left:${start.x - 5}px;top:${start.y - 5}px;width:10px;height:10px;border-radius:50%;background:#ef4444;z-index:${Z_TOP};pointer-events:none;`;
      document.body.appendChild(dot);
      return;
    }
    const end = toDoc(e);
    const s = start;
    ssCleanup();
    void stitchArea(s, end);
  });
}
async function stitchArea(start, end) {
  const left = Math.min(start.x, end.x);
  const top = Math.min(start.y, end.y);
  const rectW = Math.max(1, Math.abs(end.x - start.x));
  const rectH = Math.max(1, Math.abs(end.y - start.y));
  const dpr = window.devicePixelRatio || 1;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const orig = { x: window.scrollX, y: window.scrollY };
  try {
    const big = document.createElement("canvas");
    big.width = Math.round(vw * dpr);
    big.height = Math.round(rectH * dpr);
    const bctx = big.getContext("2d");
    if (!bctx) throw new Error("canvas 2d \u4E0D\u53EF\u7528");
    let target = top;
    let guard = 0;
    while (target < top + rectH && guard < 40) {
      guard++;
      window.scrollTo(0, target);
      await settle();
      const actualY = window.scrollY;
      const img = await loadImage(await captureSegment());
      bctx.drawImage(img, 0, Math.round((actualY - top) * dpr), Math.round(vw * dpr), Math.round(vh * dpr));
      if (actualY + vh >= top + rectH) break;
      target = actualY + vh;
    }
    window.scrollTo(orig.x, orig.y);
    const out = document.createElement("canvas");
    out.width = Math.round(rectW * dpr);
    out.height = Math.round(rectH * dpr);
    const octx = out.getContext("2d");
    if (!octx) throw new Error("canvas 2d \u4E0D\u53EF\u7528");
    octx.drawImage(big, Math.round(left * dpr), 0, out.width, out.height, 0, 0, out.width, out.height);
    await sendReady(out.toDataURL("image/png"));
  } catch (err) {
    blog("\u5340\u57DF\u622A\u5716\u62FC\u63A5\u5931\u6557", err);
    window.scrollTo(orig.x, orig.y);
  }
}
function startFreeCapture() {
  setHint("\u9023\u7E8C\u9EDE\u64CA\u756B\u591A\u908A\u5F62\uFF0C\u96D9\u64CA\u6216\u6309 Enter \u5C01\u9589");
  const { overlay, canvas, ctx } = createSelectionLayer();
  const points = [];
  function redraw(cursor) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (points.length === 0) return;
    ctx.strokeStyle = "#7c3aed";
    ctx.lineWidth = 2;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
    if (cursor) {
      ctx.setLineDash([6, 4]);
      ctx.lineTo(cursor.x, cursor.y);
    }
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#ef4444";
    for (const p of points) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  overlay.addEventListener("mousemove", (e) => redraw({ x: e.clientX, y: e.clientY }));
  overlay.addEventListener("click", (e) => {
    points.push({ x: e.clientX, y: e.clientY });
    redraw();
  });
  overlay.addEventListener("dblclick", () => void closeFree());
  ssKeyHandler = (e) => {
    if (e.key === "Enter") void closeFree();
    else if (e.key === "Escape") ssCleanup();
  };
  window.addEventListener("keydown", ssKeyHandler);
  async function closeFree() {
    if (points.length < 3) {
      setHint("\u81F3\u5C11\u9700\u8981 3 \u500B\u9EDE");
      return;
    }
    const pts = points.slice();
    const dpr = window.devicePixelRatio || 1;
    ssCleanup();
    await settle();
    try {
      const img = await loadImage(await captureSegment());
      const out = document.createElement("canvas");
      out.width = Math.round(window.innerWidth * dpr);
      out.height = Math.round(window.innerHeight * dpr);
      const octx = out.getContext("2d");
      if (!octx) throw new Error("canvas 2d \u4E0D\u53EF\u7528");
      octx.beginPath();
      octx.moveTo(pts[0].x * dpr, pts[0].y * dpr);
      for (let i = 1; i < pts.length; i++) octx.lineTo(pts[i].x * dpr, pts[i].y * dpr);
      octx.closePath();
      octx.clip();
      octx.drawImage(img, 0, 0, out.width, out.height);
      await sendReady(out.toDataURL("image/png"));
    } catch (err) {
      blog("\u81EA\u7531\u5F62\u72C0\u622A\u5716\u5931\u6557", err);
    }
  }
}
//# sourceMappingURL=content.js.map
