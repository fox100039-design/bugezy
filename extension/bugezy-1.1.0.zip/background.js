// src/types.ts
var API_BASE = "https://bugezy.dev";
var BUGEZY_DEBUG = true;
var STORAGE_KEY = "bugezy:lastPayload";
var STATE_KEY = "bugezy:state";
var LAST_SCREENSHOT_KEY = "bugezy:lastScreenshot";
var SESSION_KEY = "bugezy:session";
var SESSION_TOKEN_KEY = "bugezy:session-token";
var LANG_KEY = "bugezy:language";
var MIC_KEY = "bugezy:mic-enabled";
var MIC_PERMISSION_KEY = "bugezy:mic-permitted";
var MIC_MODE_KEY = "bugezy:mic-mode";
var VOICE_TRANSCRIPT_KEY = "bugezy:voice-transcript";
var USER_PLAN_KEY = "bugezy:user-plan";
var BUFFER_VOICE_KEY = "bugezy:buffer:voice";
var BUFFER_CONSOLE_KEY = "bugezy:buffer:console";
var BUFFER_NETWORK_KEY = "bugezy:buffer:network";
var BUFFER_RRWEB_KEY = "bugezy:buffer:rrweb";
function blog(...args) {
  if (BUGEZY_DEBUG) console.log("[BugEzy]", ...args);
}

// src/auth.ts
async function getAuthToken() {
  const store = await chrome.storage.local.get(SESSION_TOKEN_KEY);
  return store[SESSION_TOKEN_KEY];
}
async function getAuthHeaders() {
  const token = await getAuthToken();
  return {
    "Content-Type": "application/json",
    ...token ? { Authorization: `Bearer ${token}` } : {}
  };
}
async function getAuthHeaderOnly() {
  const token = await getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// src/background.ts
var BUFFER_KEYS = [BUFFER_VOICE_KEY, BUFFER_CONSOLE_KEY, BUFFER_NETWORK_KEY, BUFFER_RRWEB_KEY];
function dedupeBy(arr, keyFn) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const x of arr) {
    const k = keyFn(x);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(x);
  }
  return out;
}
async function buildFullPayload() {
  const [voiceR, consoleR, networkR, rrwebR, payloadR] = await Promise.all([
    chrome.storage.local.get(BUFFER_VOICE_KEY),
    chrome.storage.local.get(BUFFER_CONSOLE_KEY),
    chrome.storage.local.get(BUFFER_NETWORK_KEY),
    chrome.storage.local.get(BUFFER_RRWEB_KEY),
    chrome.storage.local.get(STORAGE_KEY)
  ]);
  const inj = payloadR[STORAGE_KEY];
  const voiceTranscript = dedupeBy(
    [...voiceR[BUFFER_VOICE_KEY] ?? [], ...inj?.voiceTranscript ?? []],
    (s) => `${s.timestamp}-${s.text}`
  );
  const consoleLogs = dedupeBy(
    [...consoleR[BUFFER_CONSOLE_KEY] ?? [], ...inj?.consoleLogs ?? []],
    (l) => `${l.timestamp}-${l.level}-${l.message}`
  );
  const networkErrors = dedupeBy(
    [...networkR[BUFFER_NETWORK_KEY] ?? [], ...inj?.networkErrors ?? []],
    (e) => `${e.timestamp}-${e.method}-${e.url}-${e.status}`
  );
  const rrwebEvents = dedupeBy(
    [...rrwebR[BUFFER_RRWEB_KEY] ?? [], ...inj?.rrwebEvents ?? []],
    (ev) => JSON.stringify(ev)
  );
  return {
    rrwebEvents,
    consoleLogs,
    networkErrors,
    voiceTranscript,
    pageInfo: inj?.pageInfo ?? { url: "", title: "", browser: "", screenSize: "", timestamp: "" }
  };
}
var DEFAULT_STATE = {
  recording: false,
  startedAt: null,
  tabId: null,
  summary: null
};
function setBadgeRecording() {
  chrome.action.setBadgeText({ text: "REC" });
  chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
}
function clearBadge() {
  chrome.action.setBadgeText({ text: "" });
}
async function syncBadge() {
  const s = await getState();
  if (s.recording) setBadgeRecording();
  else clearBadge();
}
chrome.runtime.onStartup.addListener(syncBadge);
chrome.runtime.onInstalled.addListener(syncBadge);
void syncBadge();
async function getState() {
  const r = await chrome.storage.local.get(STATE_KEY);
  return { ...DEFAULT_STATE, ...r[STATE_KEY] };
}
async function setState(patch) {
  const next = { ...await getState(), ...patch };
  await chrome.storage.local.set({ [STATE_KEY]: next });
  return next;
}
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}
async function checkUsage(type) {
  const headers = await getAuthHeaders();
  if (!headers.Authorization) return null;
  try {
    const res = await fetch(`${API_BASE}/api/user/usage`, {
      method: "POST",
      headers,
      body: JSON.stringify({ type })
    });
    if (res.status === 403) {
      const err = await res.json();
      if (err.error === "limit_reached") return err.message || "\u514D\u8CBB\u7248\u7528\u91CF\u5DF2\u9054\u4E0A\u9650\uFF0C\u8ACB\u5347\u7D1A\u4ED8\u8CBB\u7248";
    }
    return null;
  } catch (e) {
    blog("checkUsage failed", e);
    return null;
  }
}
var checkRecordingUsage = () => checkUsage("recording");
var checkRewindUsage = () => checkUsage("rewind");
var recordingTabId = null;
var lastCollectedConsoleLogs = [];
var lastCollectedNetworkErrors = [];
async function startRecording() {
  const limitReached = await checkRecordingUsage();
  if (limitReached) {
    return { recording: false, startedAt: null, summary: null, limitReached };
  }
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error("\u627E\u4E0D\u5230 active tab");
  await chrome.storage.local.set({
    [BUFFER_VOICE_KEY]: [],
    [BUFFER_CONSOLE_KEY]: [],
    [BUFFER_NETWORK_KEY]: [],
    [BUFFER_RRWEB_KEY]: []
  });
  if (await getMicMode() === "whisper") {
    try {
      const ready = await ensureMicReady();
      if (ready) {
        await chrome.runtime.sendMessage({ type: "OFFSCREEN_START_MIC" });
        blog("\u8A9E\u97F3\u5F15\u64CE\uFF1AGroq Whisper\uFF08\u4ED8\u8CBB\u7248\u7CBE\u6E96\u8F49\u9304\uFF09");
      } else {
        blog("\u9EA5\u514B\u98A8\u672A\u6388\u6B0A\uFF0C\u672C\u6B21\u4E0D\u9304\u8A9E\u97F3\uFF08\u8ACB\u5728 popup \u958B\u9EA5\u514B\u98A8 toggle \u6388\u6B0A\uFF09");
      }
    } catch (err) {
      blog("offscreen \u9EA5\u514B\u98A8\u555F\u52D5\u5931\u6557\uFF08\u4E0D\u963B\u64CB\u9304\u88FD\uFF09", err);
    }
  }
  await chrome.tabs.sendMessage(tab.id, { type: "START_RECORDING" });
  const s = await setState({
    recording: true,
    startedAt: Date.now(),
    tabId: tab.id,
    summary: null
  });
  recordingTabId = tab.id;
  setBadgeRecording();
  return toResponse(s);
}
async function stopRecording() {
  const s = await getState();
  const tabId = s.tabId ?? (await getActiveTab())?.id;
  if (tabId) {
    await chrome.tabs.sendMessage(tabId, { type: "STOP_RECORDING" });
  }
  const next = await setState({ recording: false });
  recordingTabId = null;
  clearBadge();
  return toResponse(next);
}
async function clearRecording() {
  await chrome.storage.local.remove([STORAGE_KEY, STATE_KEY, ...BUFFER_KEYS]);
  clearBadge();
  return toResponse(DEFAULT_STATE);
}
async function captureScreenshot() {
  const tab = await getActiveTab();
  if (!tab?.id) return { ok: false, error: "\u627E\u4E0D\u5230 active tab" };
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "START_SCREENSHOT" });
    return { ok: true };
  } catch (err) {
    blog("START_SCREENSHOT \u9001\u9054\u5931\u6557\uFF08\u8A72\u9801\u7121\u6CD5\u622A\u5716\uFF09", err);
    return { ok: false, error: "\u6B64\u9801\u9762\u7121\u6CD5\u622A\u5716" };
  }
}
async function captureSegment() {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
    return { dataUrl };
  } catch (err) {
    blog("captureSegment \u5931\u6557", err);
    return { error: String(err) };
  }
}
async function openAnnotate(dataUrl, pageUrl, pageTitle) {
  const ts = Date.now();
  const tempKey = `bugezy:ss-temp-${ts}`;
  await chrome.storage.local.set({ [tempKey]: dataUrl });
  const q = new URLSearchParams({ key: tempKey, timestamp: String(ts), pageUrl, pageTitle });
  await chrome.tabs.create({ url: `annotate.html?${q.toString()}` });
  blog("\u622A\u5716\u5B8C\u6210\uFF0C\u958B\u6A19\u6CE8\u9801", tempKey);
}
function toResponse(s) {
  return { recording: s.recording, startedAt: s.startedAt, summary: s.summary };
}
async function openEditReport() {
  await chrome.tabs.create({ url: "edit-report.html" });
  blog("\u958B\u555F\u5831\u544A\u7DE8\u8F2F\u9801");
}
async function uploadReport(description, markers) {
  const r = await chrome.storage.local.get([STORAGE_KEY, SESSION_KEY]);
  const payload = r[STORAGE_KEY];
  if (!payload) return { ok: false, error: "\u6C92\u6709\u5831\u544A\u8CC7\u6599" };
  payload.description = description ?? "";
  payload.markers = markers ?? [];
  const userId = r[SESSION_KEY]?.user_id;
  if (userId) payload.user_id = userId;
  try {
    const res = await fetch(`${API_BASE}/api/reports`, {
      method: "POST",
      headers: await getAuthHeaders(),
      // PM-129：帶 session token（server 可從 header 補回 user_id）
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`);
    const data = await res.json();
    blog("uploadReport: \u4E0A\u50B3\u6210\u529F", data.share_url);
    await chrome.storage.local.remove(BUFFER_KEYS);
    return { ok: true, shareUrl: data.share_url, reportId: data.report_id };
  } catch (err) {
    blog("uploadReport: \u4E0A\u50B3\u5931\u6557", err);
    return { ok: false, error: String(err) };
  }
}
var monitorInterval = null;
function startMonitoring() {
  if (monitorInterval) return;
  monitorInterval = setInterval(async () => {
    try {
      const tab = await getActiveTab();
      if (!tab?.id) return;
      const result = await chrome.tabs.sendMessage(tab.id, {
        type: "GET_LIVE_ERRORS"
      });
      if (!result) return;
      const leHeaders = await getAuthHeaders();
      if (leHeaders.Authorization) {
        await fetch(`${API_BASE}/api/live-errors`, {
          method: "POST",
          headers: leHeaders,
          body: JSON.stringify({
            url: tab.url,
            title: tab.title,
            consoleLogs: result.consoleLogs ?? [],
            networkErrors: result.networkErrors ?? [],
            timestamp: Date.now()
          })
        });
      }
      const total = (result.consoleLogs?.length ?? 0) + (result.networkErrors?.length ?? 0);
      if (!(await getState()).recording) {
        if (total > 0) {
          chrome.action.setBadgeText({ text: String(total) });
          chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
        } else {
          chrome.action.setBadgeText({ text: "" });
        }
      }
    } catch (err) {
      blog("\u5373\u6642\u76E3\u63A7\u63A8\u9001\u5931\u6557\uFF08\u5DF2\u5FFD\u7565\uFF09", err);
    }
  }, 1e4);
  blog("\u5373\u6642\u76E3\u63A7\u5DF2\u555F\u52D5");
}
function stopMonitoring() {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
  }
  void syncBadge();
  blog("\u5373\u6642\u76E3\u63A7\u5DF2\u505C\u6B62");
}
var OFFSCREEN_URL = "offscreen.html";
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (contexts.length > 0) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "BugEzy \u9EA5\u514B\u98A8\u9304\u97F3\uFF08\u8A9E\u97F3 Bug \u63CF\u8FF0\uFF09"
  });
}
async function ensureMicReady() {
  const store = await chrome.storage.local.get(MIC_PERMISSION_KEY);
  if (!store[MIC_PERMISSION_KEY]) {
    blog("\u9EA5\u514B\u98A8\u672A\u6388\u6B0A\uFF0C\u8DF3\u904E\u8A9E\u97F3\uFF08\u8ACB\u5728 popup \u958B\u555F\u9EA5\u514B\u98A8 toggle \u6388\u6B0A\uFF09");
    return false;
  }
  await ensureOffscreen();
  return true;
}
async function getMicMode() {
  const r = await chrome.storage.local.get([MIC_KEY, USER_PLAN_KEY, MIC_MODE_KEY]);
  if (r[MIC_KEY] !== true) return "off";
  const plan = r[USER_PLAN_KEY] || "free";
  if (plan === "free") return "realtime";
  return r[MIC_MODE_KEY] === "realtime" ? "realtime" : "whisper";
}
async function stopMicAndTranscribe() {
  const res = await chrome.runtime.sendMessage({ type: "OFFSCREEN_STOP_MIC" });
  if (!res?.audioBlob) return res ?? { error: "\u672A\u53D6\u5F97\u97F3\u8A0A" };
  try {
    const blob = await (await fetch(res.audioBlob)).blob();
    const form = new FormData();
    form.append("audio", blob, "recording.webm");
    const langStore = await chrome.storage.local.get(LANG_KEY);
    form.append("language", langStore[LANG_KEY] || "zh");
    const transcribeRes = await fetch(`${API_BASE}/api/transcribe`, {
      method: "POST",
      headers: await getAuthHeaderOnly(),
      body: form
    });
    const result = await transcribeRes.json();
    if (result.ok) {
      await chrome.storage.local.set({
        [VOICE_TRANSCRIPT_KEY]: {
          text: result.text,
          segments: result.segments,
          duration: result.duration,
          timestamp: Date.now()
        }
      });
      blog("\u8A9E\u97F3\u8F49\u9304\u5B8C\u6210:", (result.text ?? "").substring(0, 50));
    }
    return result;
  } catch (err) {
    blog("\u8F49\u9304\u5931\u6557:", err);
    return { error: "\u8F49\u9304\u5931\u6557" };
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case "START_RECORDING":
          sendResponse(await startRecording());
          break;
        case "STOP_RECORDING": {
          if (await getMicMode() === "whisper") {
            const st = await getState();
            const tid = st.tabId ?? (await getActiveTab())?.id;
            if (tid) {
              try {
                await chrome.tabs.sendMessage(tid, {
                  type: "WHISPER_TRANSCRIBING"
                });
              } catch {
              }
            }
            await stopMicAndTranscribe();
          }
          sendResponse(await stopRecording());
          break;
        }
        case "MIC_VOLUME": {
          if (recordingTabId !== null) {
            const level = msg.level ?? 0;
            chrome.tabs.sendMessage(recordingTabId, { type: "MIC_VOLUME", level }).catch(() => {
            });
          }
          sendResponse({ ok: true });
          break;
        }
        case "GET_RECORDING_STATE":
          sendResponse({ recording: recordingTabId !== null });
          break;
        case "UPLOAD_MONITOR_REPORT": {
          const m = msg;
          const store = await chrome.storage.local.get(SESSION_KEY);
          const uid = store[SESSION_KEY]?.user_id;
          const payload = uid ? { ...m.payload, user_id: uid } : m.payload;
          try {
            const res = await fetch(`${API_BASE}/api/reports`, {
              method: "POST",
              headers: await getAuthHeaders(),
              // PM-129：帶 session token
              body: JSON.stringify(payload)
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();
            if (data.share_url) {
              await chrome.storage.local.set({ "bugezy:latest-report-url": data.share_url });
              blog("\u5373\u6642\u76E3\u63A7\u5831\u544A\u4E0A\u50B3\u6210\u529F:", data.share_url);
              sendResponse({ ok: true, shareUrl: data.share_url, reportId: data.report_id });
            } else {
              sendResponse({ ok: false, error: "\u672A\u53D6\u5F97\u5831\u544A\u9023\u7D50" });
            }
          } catch (err) {
            blog("\u5373\u6642\u76E3\u63A7\u4E0A\u50B3\u5931\u6557:", err);
            sendResponse({ ok: false, error: "\u4E0A\u50B3\u5931\u6557" });
          }
          break;
        }
        case "CLEAR_RECORDING":
          sendResponse(await clearRecording());
          break;
        case "GET_STATE":
          sendResponse(toResponse(await getState()));
          break;
        case "GET_LAST_PAYLOAD": {
          const r = await chrome.storage.local.get(STORAGE_KEY);
          sendResponse({ payload: r[STORAGE_KEY] ?? null });
          break;
        }
        case "CAPTURE_SCREENSHOT":
          sendResponse(await captureScreenshot());
          break;
        case "CAPTURE_SEGMENT":
          sendResponse(await captureSegment());
          break;
        case "SCREENSHOT_READY": {
          const m = msg;
          lastCollectedConsoleLogs = m.consoleLogs ?? [];
          lastCollectedNetworkErrors = m.networkErrors ?? [];
          await openAnnotate(m.dataUrl, m.pageUrl, m.pageTitle);
          sendResponse({ ok: true });
          break;
        }
        case "GET_COLLECTED_ERRORS": {
          sendResponse({
            consoleLogs: lastCollectedConsoleLogs,
            networkErrors: lastCollectedNetworkErrors
          });
          break;
        }
        case "SCREENSHOT_UPLOADED": {
          const m = msg;
          await chrome.storage.local.set({
            [LAST_SCREENSHOT_KEY]: { shareUrl: m.shareUrl, reportId: m.reportId, timestamp: Date.now() }
          });
          blog("\u622A\u5716\u4E0A\u50B3\u5B8C\u6210:", m.shareUrl);
          sendResponse({ ok: true });
          break;
        }
        case "RECORDING_DONE": {
          const prev = await getState();
          const incoming = msg.summary;
          const merged = await buildFullPayload();
          const wStore = await chrome.storage.local.get(VOICE_TRANSCRIPT_KEY);
          const whisper = wStore[VOICE_TRANSCRIPT_KEY];
          if (whisper?.text?.trim()) {
            merged.voiceTranscript = [
              {
                text: whisper.text,
                timestamp: whisper.timestamp ?? Date.now(),
                isFinal: true,
                source: "whisper"
              }
            ];
            await chrome.storage.local.remove(VOICE_TRANSCRIPT_KEY);
          } else {
            merged.voiceTranscript.forEach((s2) => {
              if (!s2.source) s2.source = "web-speech";
            });
          }
          await chrome.storage.local.set({ [STORAGE_KEY]: merged });
          const summary = {
            ...incoming,
            domEvents: merged.rrwebEvents.length,
            consoleLogs: merged.consoleLogs.length,
            networkErrors: merged.networkErrors.length,
            voiceSegments: merged.voiceTranscript.length,
            pageInfo: merged.pageInfo,
            durationMs: prev.startedAt ? Date.now() - prev.startedAt : 0,
            uploadStatus: "idle",
            shareUrl: null,
            uploadError: null
          };
          blog("RECORDING_DONE \u5408\u4F75\u5B8C\u6210", {
            dom: merged.rrwebEvents.length,
            console: merged.consoleLogs.length,
            network: merged.networkErrors.length,
            voice: merged.voiceTranscript.length
          });
          const s = await setState({ recording: false, startedAt: null, tabId: null, summary });
          clearBadge();
          await openEditReport();
          sendResponse(toResponse(s));
          break;
        }
        case "UPLOAD_REPORT": {
          const m = msg;
          sendResponse(await uploadReport(m.description, m.markers));
          break;
        }
        case "REWIND_30S": {
          const limitReached = await checkRewindUsage();
          if (limitReached) {
            sendResponse({ ok: false, limitReached });
            break;
          }
          const tab = await getActiveTab();
          if (tab?.id) {
            await chrome.tabs.sendMessage(tab.id, { type: "REWIND_30S" });
            sendResponse({ ok: true });
          } else {
            sendResponse({ ok: false, error: "\u627E\u4E0D\u5230 active tab" });
          }
          break;
        }
        case "REWIND_DONE": {
          const incoming = msg.summary;
          const summary = {
            ...incoming,
            durationMs: 3e4,
            // 回溯視窗約 30 秒
            uploadStatus: "idle",
            shareUrl: null,
            uploadError: null
          };
          const s = await setState({ recording: false, startedAt: null, tabId: null, summary });
          clearBadge();
          await openEditReport();
          sendResponse(toResponse(s));
          break;
        }
        case "START_MONITORING": {
          startMonitoring();
          const tab = await getActiveTab();
          if (tab?.id) {
            await chrome.tabs.sendMessage(tab.id, { type: "SET_MONITOR_BADGE", show: true }).catch(() => {
            });
          }
          sendResponse({ ok: true });
          break;
        }
        case "STOP_MONITORING": {
          stopMonitoring();
          const tab = await getActiveTab();
          if (tab?.id) {
            await chrome.tabs.sendMessage(tab.id, { type: "SET_MONITOR_BADGE", show: false }).catch(() => {
            });
          }
          sendResponse({ ok: true });
          break;
        }
        case "FLUSH_VOICE": {
          const seg = msg.segment;
          const r = await chrome.storage.local.get(BUFFER_VOICE_KEY);
          const arr = r[BUFFER_VOICE_KEY] ?? [];
          arr.push(seg);
          await chrome.storage.local.set({ [BUFFER_VOICE_KEY]: arr });
          sendResponse({ ok: true });
          break;
        }
        case "FLUSH_CONSOLE": {
          const log = msg.log;
          const r = await chrome.storage.local.get(BUFFER_CONSOLE_KEY);
          const arr = r[BUFFER_CONSOLE_KEY] ?? [];
          arr.push(log);
          await chrome.storage.local.set({ [BUFFER_CONSOLE_KEY]: arr });
          sendResponse({ ok: true });
          break;
        }
        case "FLUSH_NETWORK": {
          const error = msg.error;
          const r = await chrome.storage.local.get(BUFFER_NETWORK_KEY);
          const arr = r[BUFFER_NETWORK_KEY] ?? [];
          arr.push(error);
          await chrome.storage.local.set({ [BUFFER_NETWORK_KEY]: arr });
          sendResponse({ ok: true });
          break;
        }
        case "FLUSH_RRWEB": {
          const evs = msg.events;
          const r = await chrome.storage.local.get(BUFFER_RRWEB_KEY);
          const arr = r[BUFFER_RRWEB_KEY] ?? [];
          arr.push(...evs);
          await chrome.storage.local.set({ [BUFFER_RRWEB_KEY]: arr });
          sendResponse({ ok: true });
          break;
        }
        case "GET_VOICE_BUFFER": {
          const r = await chrome.storage.local.get(BUFFER_VOICE_KEY);
          sendResponse({ segments: r[BUFFER_VOICE_KEY] ?? [] });
          break;
        }
        case "MIC_START": {
          await ensureOffscreen();
          const res = await chrome.runtime.sendMessage({ type: "OFFSCREEN_START_MIC" });
          sendResponse(res);
          break;
        }
        case "MIC_STOP": {
          sendResponse(await stopMicAndTranscribe());
          break;
        }
        case "MIC_PERMISSION_GRANTED": {
          await chrome.storage.local.set({ [MIC_PERMISSION_KEY]: true });
          blog("\u9EA5\u514B\u98A8\u6388\u6B0A\u5B8C\u6210");
          sendResponse({ ok: true });
          break;
        }
        case "REQUEST_MIC_PERMISSION": {
          const store = await chrome.storage.local.get(MIC_PERMISSION_KEY);
          if (!store[MIC_PERMISSION_KEY]) {
            await chrome.tabs.create({ url: "mic-permission.html" });
          }
          sendResponse({ ok: true });
          break;
        }
        default:
          sendResponse({ ok: false, error: "unknown message" });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) });
    }
  })();
  return true;
});
//# sourceMappingURL=background.js.map
