// src/types.ts
var API_BASE = "https://bugezy.dev";
var LAST_SCREENSHOT_KEY = "bugezy:lastScreenshot";
var SESSION_KEY = "bugezy:session";
var SESSION_TOKEN_KEY = "bugezy:session-token";
var LANG_KEY = "bugezy:language";
var KEYBOARD_MODE_KEY = "bugezy:keyboardMode";
var MONITOR_MODE_KEY = "bugezy:monitorMode";
var ALLOW_SCREENSHOT_KEY = "bugezy:allow-screenshot-images";
var TOOLBAR_EFFECT_KEY = "bugezy:toolbar-effect";
var MIC_KEY = "bugezy:mic-enabled";
var MIC_PERMISSION_KEY = "bugezy:mic-permitted";
var MIC_MODE_KEY = "bugezy:mic-mode";
var USER_PLAN_KEY = "bugezy:user-plan";

// src/auth.ts
async function getAuthToken() {
  const store = await chrome.storage.local.get(SESSION_TOKEN_KEY);
  return store[SESSION_TOKEN_KEY];
}
async function getAuthHeaders() {
  const token = await getAuthToken();
  return {
    "Content-Type": "application/json",
    ...token ? { Authorization: `Bearer ${token}` } : {}
  };
}
async function applyRotatedToken(data) {
  const newToken = data?.new_session_token;
  if (newToken && typeof newToken === "string") {
    await chrome.storage.local.set({ [SESSION_TOKEN_KEY]: newToken });
  }
}

// src/i18n.ts
function getUILang(speechLang) {
  if (speechLang === "zh" || speechLang === "yue") return "zh";
  return "en";
}
var dict = {
  // ── 登入 ──
  "login-hint": { zh: "\u767B\u5165\u5F8C\u958B\u59CB\u4F7F\u7528", en: "Sign in to get started" },
  "login-google": { zh: "\u7528 Google \u767B\u5165", en: "Sign in with Google" },
  "login-loading": { zh: "\u767B\u5165\u4E2D...", en: "Signing in..." },
  "login-failed": { zh: "\u767B\u5165\u5931\u6557\uFF0C\u91CD\u8A66", en: "Login failed, retry" },
  // ── 頂部 ──
  logout: { zh: "\u767B\u51FA", en: "Logout" },
  "voice-bug-report": { zh: "\u8A9E\u97F3 Bug \u56DE\u5831", en: "Voice Bug Report" },
  "voice-mode": { zh: "\u8A9E\u97F3\u6A21\u5F0F", en: "Voice Mode" },
  "mode-realtime": { zh: "\u5373\u6642\u5B57\u5E55", en: "Live Caption" },
  "mode-whisper": { zh: "\u7CBE\u6E96\u8F49\u9304", en: "Precise" },
  "settings-locked": { zh: "\u{1F512} \u9304\u88FD\u4E2D\uFF0C\u8A2D\u5B9A\u5DF2\u9396\u5B9A", en: "\u{1F512} Recording, settings locked" },
  // ── 三大模式卡片 ──
  "mode-record": { zh: "\u9304\u88FD", en: "Record" },
  "mode-record-desc": { zh: "DOM + \u8A9E\u97F3 + Console", en: "DOM + Voice + Console" },
  "mode-rewind": { zh: "\u56DE\u6EAF 30s", en: "Rewind 30s" },
  "mode-rewind-desc": { zh: "\u6293\u525B\u624D\u7684 Bug", en: "Catch recent Bug" },
  "mode-screenshot": { zh: "\u622A\u5716\u6A19\u6CE8", en: "Screenshot" },
  "mode-screenshot-desc": { zh: "\u5FEB\u901F\u64F7\u53D6 + \u756B\u91CD\u9EDE", en: "Capture + Annotate" },
  // ── 用量（動態）──
  unlimited: { zh: "\u2728 \u7121\u9650\u6B21", en: "\u2728 Unlimited" },
  remaining: { zh: "\u5269 {n} \u6B21", en: "{n} left" },
  "used-up": { zh: "\u5DF2\u7528\u5B8C\uFF08\u5347\u7D1A\u89E3\u9396\uFF09", en: "Used up (upgrade)" },
  // ── 日票 / 月費 ──
  "upgrade-unlock": { zh: "\u5347\u7D1A\u89E3\u9396\u7121\u9650\u6B21", en: "Upgrade for unlimited" },
  "my-reports": { zh: "\u{1F4CB} \u6211\u7684\u5831\u544A", en: "\u{1F4CB} My Reports" },
  // PM-184
  // PM-185：截圖敏感偵測 + 馬賽克
  "sf-password": { zh: "\u5BC6\u78BC\u6B04\u4F4D", en: "password fields" },
  "sf-token": { zh: "Token \u6B04\u4F4D", en: "token fields" },
  "sf-secret": { zh: "Secret \u6B04\u4F4D", en: "secret fields" },
  "sf-key": { zh: "API Key \u6B04\u4F4D", en: "API key fields" },
  "sf-card": { zh: "\u4FE1\u7528\u5361\u6B04\u4F4D", en: "credit card fields" },
  "sf-cvv": { zh: "CVV \u6B04\u4F4D", en: "CVV fields" },
  "sf-marked": { zh: "\u6A19\u8A18\u70BA\u654F\u611F\u7684\u5143\u7D20", en: "sensitive-marked elements" },
  "sensitive-sep": { zh: "\u3001", en: ", " },
  "sensitive-title": { zh: "\u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D", en: "Sensitive fields detected" },
  "sensitive-page-has": { zh: "\u9801\u9762\u4E0A\u6709\uFF1A{fields}", en: "This page contains: {fields}" },
  "sensitive-hint": {
    zh: "\u622A\u5716\u5F8C\u53EF\u7528 \u{1F512} \u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u654F\u611F\u5340\u57DF\u518D\u4E0A\u50B3",
    en: "Use the \u{1F512} mosaic brush to cover sensitive areas before uploading"
  },
  "sensitive-continue": { zh: "\u7E7C\u7E8C\u622A\u5716", en: "Continue" },
  "sensitive-cancel": { zh: "\u53D6\u6D88", en: "Cancel" },
  "sensitive-tip": {
    zh: "\u{1F512} \u5075\u6E2C\u5230\u654F\u611F\u6B04\u4F4D\uFF0C\u5EFA\u8B70\u7528\u99AC\u8CFD\u514B\u7B46\u5237\u5857\u6389\u518D\u4E0A\u50B3",
    en: "\u{1F512} Sensitive fields detected \u2014 use the mosaic brush to cover them before uploading"
  },
  "annotate-mosaic": { zh: "\u{1F512} \u99AC\u8CFD\u514B", en: "\u{1F512} Mosaic" },
  // PM-186：自動遮罩
  "auto-masked": { zh: "\u{1F512} \u5DF2\u81EA\u52D5\u906E\u7F69 {n} \u500B\u654F\u611F\u6B04\u4F4D", en: "\u{1F512} Auto-masked {n} sensitive field(s)" },
  "undo-mask": { zh: "\u64A4\u92B7\u906E\u7F69", en: "Undo mask" },
  "day-pass-btn": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr\uFF09", en: "\u26A1 Day Pass NT$20 (24hr)" },
  "monthly-btn": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708", en: "\u2728 Monthly NT$80/mo" },
  // PM-170：用完升級引導 overlay
  "usage-exhausted": { zh: "\u672C\u6708\u984D\u5EA6\u5DF2\u7528\u5B8C", en: "Monthly quota exhausted" },
  "usage-desc-record": { zh: "\u9304\u88FD {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Recording {used}/{max} used" },
  "usage-desc-rewind": { zh: "\u56DE\u6EAF {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "Rewind {used}/{max} used" },
  "usage-desc-mcp": { zh: "MCP AI \u8B80\u53D6 {used}/{max} \u6B21\u5DF2\u4F7F\u7528", en: "MCP AI reads {used}/{max} used" },
  "usage-reset-hint": { zh: "\u{1F4A1} \u514D\u8CBB\u984D\u5EA6\u6BCF\u6708\u81EA\u52D5\u91CD\u7F6E", en: "\u{1F4A1} Free quota resets monthly" },
  "day-pass-btn-full": { zh: "\u26A1 \u65E5\u7968 NT$20\uFF0824hr \u7121\u9650\uFF09", en: "\u26A1 Day Pass NT$20 (24hr unlimited)" },
  "monthly-btn-full": { zh: "\u2728 \u6708\u8CBB NT$80/\u6708\uFF08\u6700\u5212\u7B97\uFF09", en: "\u2728 Monthly NT$80/mo (best value)" },
  // PM-171：非台灣付費 coming soon
  "intl-coming-soon": { zh: "\u{1F30F} \u570B\u969B\u4ED8\u6B3E\u5373\u5C07\u958B\u653E", en: "\u{1F30F} International Payments Coming Soon!" },
  "intl-desc": {
    zh: "\u6211\u5011\u6B63\u5728\u958B\u901A\u570B\u969B\u4FE1\u7528\u5361\u4ED8\u6B3E\uFF0C\u656C\u8ACB\u671F\u5F85\uFF01",
    en: "We're working on enabling international credit card payments. Stay tuned!"
  },
  "intl-free-hint": {
    zh: "\u{1F4A1} \u514D\u8CBB\u7248\u73FE\u5728\u5C31\u80FD\u7528 \u2014 \u6BCF\u6708 10 \u6B21\u9304\u88FD + 20 \u6B21 MCP AI \u8B80\u53D6",
    en: "\u{1F4A1} Free plan available now \u2014 10 recordings + 20 MCP AI reads per month"
  },
  "day-pass-badge": { zh: "\u26A1 \u65E5\u7968", en: "\u26A1 Day Pass" },
  "day-pass-remaining": { zh: "\u5269\u9918 {h}h {m}m {s}s", en: "{h}h {m}m {s}s left" },
  "day-pass-expire-hint": {
    zh: "\u65E5\u7968\u5230\u671F\u5F8C\u53EF\u5347\u7D1A\u6708\u8CBB",
    en: "Upgrade to monthly after day pass expires"
  },
  "paid-badge": { zh: "\u2728 \u4ED8\u8CBB\u7248\u6703\u54E1", en: "\u2728 Premium Member" },
  "cancel-sub": { zh: "\u53D6\u6D88\u8A02\u95B1", en: "Cancel" },
  "cancelled-prefix": { zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\uFF0C\u53EF\u7528\u5230", en: "Cancelled, active until" },
  resub: { zh: "\u91CD\u65B0\u8A02\u95B1", en: "Resubscribe" },
  // ── 進階設定 ──
  "lang-label": { zh: "\u{1F310} \u8A9E\u97F3\u8A9E\u8A00", en: "\u{1F310} Voice Language" },
  "advanced-settings": { zh: "\u2699\uFE0F \u9032\u968E\u8A2D\u5B9A", en: "\u2699\uFE0F Advanced Settings" },
  "monitor-toggle": { zh: "\u{1F50D} \u5373\u6642\u76E3\u63A7\uFF08AI \u53EF\u67E5 error\uFF09", en: "\u{1F50D} Live Monitor (AI reads errors)" },
  "keyboard-toggle": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F\uFF08\u95DC\u9589\u8A9E\u97F3\uFF09", en: "\u{1F507} Keyboard Mode (no voice)" },
  "hq-toggle": { zh: "\u{1F4F8} \u9AD8\u756B\u8CEA AI \u5206\u6790\uFF08\u9AD8 Token\uFF09", en: "\u{1F4F8} HQ AI Analysis (high Token)" },
  "effect-toggle": { zh: "\u2728 \u5DE5\u5177\u5217\u7279\u6548", en: "\u2728 Toolbar Effects" },
  // ── AI 輪盤 ──
  "carousel-title": { zh: "\u4E00\u9375\u8907\u88FD\u6307\u4EE4\u8CBC\u7D66 AI", en: "Copy prompt to AI" },
  "copy-btn": { zh: "\u8907\u88FD", en: "Copy" },
  "edit-btn": { zh: "\u270F\uFE0F \u7DE8\u8F2F", en: "\u270F\uFE0F Edit" },
  "save-btn": { zh: "\u{1F4BE} \u5132\u5B58", en: "\u{1F4BE} Save" },
  "cancel-btn": { zh: "\u53D6\u6D88", en: "Cancel" },
  // ── 錄製中 / 完成 ──
  "stop-recording": { zh: "\u23F9 \u505C\u6B62\u9304\u88FD", en: "\u23F9 Stop Recording" },
  "done-title": { zh: "\u2705 \u9304\u88FD\u5B8C\u6210\uFF01", en: "\u2705 Recording Done!" },
  "sum-dom": { zh: "DOM \u4E8B\u4EF6", en: "DOM Events" },
  "sum-console": { zh: "Console", en: "Console" },
  "sum-network": { zh: "Network \u932F\u8AA4", en: "Network Errors" },
  "sum-voice": { zh: "\u8A9E\u97F3\u7247\u6BB5", en: "Voice Clips" },
  "sum-time": { zh: "\u6642\u9593", en: "Duration" },
  "duration-sec": { zh: "{n} \u79D2", en: "{n}s" },
  "copy-json": { zh: "\u{1F4CB} \u8907\u88FD JSON", en: "\u{1F4CB} Copy JSON" },
  "export-json": { zh: "\u{1F4BE} \u532F\u51FA JSON\uFF08\u7D66 AI \u8B80\uFF09", en: "\u{1F4BE} Export JSON (for AI)" },
  "clear-restart": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\uFF0C\u91CD\u65B0\u9304\u88FD", en: "\u{1F5D1}\uFE0F Clear & Restart" },
  "copy-link": { zh: "\u{1F4CB} \u8907\u88FD\u9023\u7D50", en: "\u{1F4CB} Copy Link" },
  // ── mic OFF 提示 ──
  "mic-prompt-title": { zh: "\u9EA5\u514B\u98A8\u76EE\u524D\u95DC\u9589", en: "Microphone is off" },
  "mic-prompt-desc": { zh: "\u8981\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \u55CE\uFF1F", en: "Use voice to describe the bug?" },
  "mic-prompt-on": { zh: "\u958B\u555F\u4E26\u9304\u88FD", en: "Turn on & record" },
  "mic-prompt-skip": { zh: "\u76F4\u63A5\u9304\u88FD\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Record without voice" },
  // ── 版本（動態）──
  "update-available": {
    zh: "\u{1F195} \u76EE\u524D v{cur} \u2192 \u65B0\u7248 v{new} \u53EF\u7528",
    en: "\u{1F195} v{cur} \u2192 v{new} available"
  },
  // ── PM-139：截圖工具列（content.ts）──
  "toolbar-fullpage": { zh: "\u{1F4F7} \u6574\u9801", en: "\u{1F4F7} Full Page" },
  "toolbar-region": { zh: "\u2B1C \u5340\u57DF\uFF08\u5169\u9EDE\uFF09", en: "\u2B1C Region (2 clicks)" },
  "toolbar-freeform": { zh: "\u2702\uFE0F \u81EA\u7531\u5F62\u72C0", en: "\u2702\uFE0F Freeform" },
  "toolbar-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "toolbar-select-mode": { zh: "\u9078\u64C7\u622A\u5716\u6A21\u5F0F", en: "Select screenshot mode" },
  "toolbar-region-hint": { zh: "\u53EF\u81EA\u7531\u6372\u52D5\u9801\u9762\uFF0C\u9EDE\u7B2C\u4E8C\u4E0B\u6A19\u8A18\u7D42\u9EDE", en: "Scroll freely, click again to set the end point" },
  "transcribing": { zh: "\u23F3 \u8A9E\u97F3\u8F49\u9304\u4E2D\u2026", en: "\u23F3 Transcribing\u2026" },
  // ── PM-139：即時監控（inject.ts，經 it()）──
  "monitor-active": { zh: "\u{1F7E2} BugEzy \u76E3\u63A7\u4E2D", en: "\u{1F7E2} BugEzy Monitoring" },
  "monitor-errors": { zh: "\u26A0\uFE0F \u767C\u73FE {n} \u500B\u932F\u8AA4\uFF08\u9EDE\u6211\u67E5\u770B\uFF09", en: "\u26A0\uFE0F {n} error(s) found (click to view)" },
  "monitor-errors-title": { zh: "BugEzy \u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4\uFF0C\u9EDE\u6211\u67E5\u770B", en: "BugEzy found {n} error(s), click to view" },
  "monitor-panel-title": { zh: "\u{1F41B} \u5373\u6642\u76E3\u63A7\u932F\u8AA4", en: "\u{1F41B} Live Monitor Errors" },
  "monitor-empty": { zh: "\u2713 \u76EE\u524D\u7121\u932F\u8AA4", en: "\u2713 No errors" },
  "monitor-upload": { zh: "\u{1F4E4} \u4E0A\u50B3\u5831\u544A\u8B93 AI \u5206\u6790", en: "\u{1F4E4} Upload report for AI analysis" },
  "monitor-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D\u2026", en: "\u23F3 Uploading\u2026" },
  "monitor-uploaded": { zh: "\u2705 \u5DF2\u4E0A\u50B3\uFF01\u9EDE\u6B64\u67E5\u770B\u5831\u544A", en: "\u2705 Uploaded! Click to view report" },
  "monitor-upload-fail": { zh: "\u274C \u4E0A\u50B3\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66", en: "\u274C Upload failed, click to retry" },
  "monitor-desc": { zh: "\u5373\u6642\u76E3\u63A7\u5075\u6E2C\u5230 {n} \u500B\u932F\u8AA4", en: "Live monitor found {n} error(s)" },
  // ── PM-139：錄製字幕 / 麥克風授權（inject.ts，經 it()）──
  "caption-recording": { zh: "\u{1F399} \u9304\u88FD\u4E2D\uFF0C\u53EF\u4EE5\u7528\u4E2D\u6587\u63CF\u8FF0\u554F\u984C\u2026", en: "\u{1F399} Recording \u2014 describe the issue by voice\u2026" },
  "caption-voice-log": { zh: "\u{1F4DD} \u8A9E\u97F3\u8A18\u9304", en: "\u{1F4DD} Voice Log" },
  "keyboard-bar": { zh: "\u{1F507} \u9375\u76E4\u6A21\u5F0F \u2014 \u9304\u88FD\u4E2D\uFF08\u8A9E\u97F3\u5DF2\u95DC\u9589\uFF09", en: "\u{1F507} Keyboard mode \u2014 recording (voice off)" },
  "whisper-bar": { zh: "\u{1F399}\uFE0F \u9304\u97F3\u4E2D\u2026\uFF08\u505C\u6B62\u5F8C\u81EA\u52D5\u8F49\u9304\uFF09", en: "\u{1F399}\uFE0F Recording\u2026\uFF08auto-transcribe on stop\uFF09" },
  "mic-perm-title": { zh: "BugEzy \u9700\u8981\u9EA5\u514B\u98A8\u6B0A\u9650", en: "BugEzy needs microphone access" },
  "mic-perm-desc": { zh: "\u5141\u8A31\u5F8C\u53EF\u7528\u8A9E\u97F3\u63CF\u8FF0 Bug \xB7 \u6B64\u7DB2\u7AD9\u53EA\u9700\u6388\u6B0A\u4E00\u6B21", en: "Allow to describe bugs by voice \xB7 one-time per site" },
  "mic-perm-allow": { zh: "\u5141\u8A31\u9EA5\u514B\u98A8", en: "Allow microphone" },
  "mic-perm-skip": { zh: "\u8DF3\u904E\uFF08\u4E0D\u9304\u8A9E\u97F3\uFF09", en: "Skip (no voice)" },
  // ── PM-139：截圖標注頁（annotate）──
  "annotate-pen": { zh: "\u270F\uFE0F \u756B\u7B46", en: "\u270F\uFE0F Pen" },
  "annotate-arrow": { zh: "\u27A1\uFE0F \u7BAD\u982D", en: "\u27A1\uFE0F Arrow" },
  "annotate-rect": { zh: "\u2B1C \u6846\u6846", en: "\u2B1C Box" },
  "annotate-text": { zh: "\u{1F4DD} \u6587\u5B57", en: "\u{1F4DD} Text" },
  "annotate-color": { zh: "\u984F\u8272", en: "Color" },
  "annotate-thickness": { zh: "\u7C97\u7D30", en: "Width" },
  "annotate-thin": { zh: "\u7D30", en: "Thin" },
  "annotate-mid": { zh: "\u4E2D", en: "Medium" },
  "annotate-thick": { zh: "\u7C97", en: "Thick" },
  "annotate-undo": { zh: "\u21A9\uFE0F \u5FA9\u539F", en: "\u21A9\uFE0F Undo" },
  "annotate-clear": { zh: "\u{1F5D1}\uFE0F \u6E05\u9664\u5168\u90E8", en: "\u{1F5D1}\uFE0F Clear All" },
  "annotate-cancel": { zh: "\u2717 \u53D6\u6D88", en: "\u2717 Cancel" },
  "annotate-save": { zh: "\u2705 \u5B8C\u6210\u5132\u5B58", en: "\u2705 Save" },
  "annotate-desc-label": { zh: "\u{1F4AC} \u554F\u984C\u63CF\u8FF0\uFF08\u9078\u586B\uFF09", en: "\u{1F4AC} Description (optional)" },
  "annotate-desc-ph": { zh: "\u63CF\u8FF0\u4F60\u770B\u5230\u7684\u554F\u984C\uFF0C\u6216\u6309\u53F3\u908A\u9EA5\u514B\u98A8\u8A9E\u97F3\u8F38\u5165...", en: "Describe the issue, or tap the mic on the right to dictate..." },
  "annotate-listening": { zh: "\u{1F534} \u8046\u807D\u4E2D\uFF0C\u908A\u756B\u908A\u8AAA\u63CF\u8FF0\u554F\u984C...", en: "\u{1F534} Listening \u2014 describe while you draw..." },
  "annotate-uploading": { zh: "\u23F3 \u4E0A\u50B3\u4E2D...", en: "\u23F3 Uploading..." },
  // ── PM-139：alert / confirm（popup.ts）──
  "confirm-cancel-sub": {
    zh: "\u78BA\u5B9A\u8981\u53D6\u6D88\u6708\u8CBB\u8A02\u95B1\u55CE\uFF1F\n\u53D6\u6D88\u5F8C\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\uFF0C\u5230\u671F\u5F8C\u81EA\u52D5\u964D\u56DE\u514D\u8CBB\u7248\u3002",
    en: "Cancel your monthly subscription?\nYou can still use premium features until the end of your billing period."
  },
  "alert-cancelled": {
    zh: "\u5DF2\u53D6\u6D88\u8A02\u95B1\u3002\u5230\u671F\u65E5\u524D\u4ECD\u53EF\u4F7F\u7528\u4ED8\u8CBB\u529F\u80FD\u3002",
    en: "Subscription cancelled. Premium features remain active until end of billing period."
  },
  "alert-cancel-fail": { zh: "\u53D6\u6D88\u5931\u6557\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66", en: "Cancellation failed, please try again later" }
};
var DEFAULT_PROMPTS = {
  zh: [
    { text: "\u8ACB\u8B80\u53D6\u6211\u6700\u65B0\u7684 BugEzy \u5831\u544A\uFF0C\u5E6B\u6211\u627E\u51FA\u554F\u984C\u4E26\u4FEE\u5FA9", color: "#ef4444" },
    {
      text: "\u8ACB\u8B80\u53D6\u6700\u65B0 BugEzy \u5831\u544A\uFF0C\u5206\u6790\uFF1A\n1. \u771F\u6B63\u7684 root cause\n2. \u4FEE\u5FA9\u65B9\u6848\n3. \u4FEE\u6539\u54EA\u4E9B\u6A94\u6848\n4. \u7522\u751F fix plan\n\u8ACB\u4E0D\u8981\u731C\u6E2C\uFF0C\u5982\u679C\u8CC7\u6599\u4E0D\u8DB3\u8ACB\u544A\u77E5\u9700\u8981\u54EA\u4E9B\u8CC7\u8A0A",
      color: "#3b82f6"
    },
    { text: "\u8ACB\u8B80\u53D6\u6211\u6700\u65B0\u7684\u622A\u5716\u5831\u544A\uFF0C\u770B\u756B\u9762\u54EA\u88E1\u6709\u554F\u984C\uFF0C\u7D66\u6211 CSS/HTML \u4FEE\u5FA9\u5EFA\u8B70", color: "#22c55e" },
    { text: "\u8ACB\u8B80\u53D6\u6700\u65B0 BugEzy \u5831\u544A\uFF0C\u76F4\u63A5\u7D66\u6211\u53EF\u4EE5\u8CBC\u4E0A\u7684\u4FEE\u5FA9\u7A0B\u5F0F\u78BC", color: "#f59e0b" }
  ],
  en: [
    { text: "Read my latest BugEzy report and help me find and fix the bug", color: "#ef4444" },
    {
      text: "Read my latest BugEzy report and analyze:\n1. Root cause\n2. Fix approach\n3. Which files to change\n4. Generate a fix plan\nDon't guess \u2014 if you need more info, tell me what to provide",
      color: "#3b82f6"
    },
    { text: "Read my latest screenshot report, identify UI issues, and give me CSS/HTML fixes", color: "#22c55e" },
    { text: "Read my latest BugEzy report and give me copy-paste ready fix code", color: "#f59e0b" }
  ]
};
function t(key, lang, params) {
  const entry = dict[key];
  let text = entry?.[lang] || entry?.["zh"] || key;
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      text = text.replace(`{${k}}`, String(v));
    }
  }
  return text;
}

// src/popup.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing #${id}`);
  return el;
};
var idleView = $("idleView");
var recordingView = $("recordingView");
var doneView = $("doneView");
var startBtn = $("startBtn");
var stopBtn = $("stopBtn");
var screenshotBtn = $("screenshotBtn");
var copyBtn = $("copyBtn");
var exportBtn = $("exportBtn");
var clearBtn = $("clearBtn");
var elapsed = $("elapsed");
var domCount = $("domCount");
var consoleCount = $("consoleCount");
var networkCount = $("networkCount");
var voiceCount = $("voiceCount");
var durationVal = $("durationVal");
var pageUrl = $("pageUrl");
var lastScreenshot = $("lastScreenshot");
var uploadStatusEl = $("uploadStatus");
var shareUrlRow = $("shareUrlRow");
var shareLink = $("shareLink");
var copyLinkBtn = $("copyLinkBtn");
var loginView = $("loginView");
var mainView = $("mainView");
var googleLoginBtn = $("googleLoginBtn");
var logoutBtn = $("logoutBtn");
var userAvatar = $("userAvatar");
var userName = $("userName");
var upgradeHint = $("upgradeHint");
var upgradeBtn = $("upgradeBtn");
var paidBadge = $("paidBadge");
var cancelledBadge = $("cancelledBadge");
var expiresDate = $("expiresDate");
var cancelSubBtn = $("cancelSubBtn");
var resubBtn = $("resubBtn");
var dayPassBtn = $("dayPassBtn");
var dayPassStatus = $("dayPassStatus");
var dayPassCountdown = $("dayPassCountdown");
var dayPassHint = $("dayPassHint");
var dayPassTimer;
var upgradeOverlay = $("upgradeOverlay");
var upgradeOverlayClose = $("upgradeOverlayClose");
var upgradeOverlayDesc = $("upgradeOverlayDesc");
var overlayDayPassBtn = $("overlayDayPassBtn");
var overlayMonthlyBtn = $("overlayMonthlyBtn");
var freeLimits = null;
var intlNotice = $("intlNotice");
var overlayIntlNotice = $("overlayIntlNotice");
var currentCountry = "UNKNOWN";
var isTaiwanUser = () => currentCountry === "TW";
var keyboardMode = $("keyboardMode");
chrome.storage.local.get(KEYBOARD_MODE_KEY, (r) => {
  keyboardMode.checked = r[KEYBOARD_MODE_KEY] === true;
});
keyboardMode.addEventListener("change", () => {
  chrome.storage.local.set({ [KEYBOARD_MODE_KEY]: keyboardMode.checked });
});
var monitorMode = $("monitorMode");
chrome.storage.local.get(MONITOR_MODE_KEY, (r) => {
  monitorMode.checked = r[MONITOR_MODE_KEY] === true;
});
monitorMode.addEventListener("change", async () => {
  const enabled = monitorMode.checked;
  await chrome.storage.local.set({ [MONITOR_MODE_KEY]: enabled });
  await send(enabled ? "START_MONITORING" : "STOP_MONITORING");
});
var allowScreenshots = $("allowScreenshots");
chrome.storage.local.get(ALLOW_SCREENSHOT_KEY, (r) => {
  allowScreenshots.checked = r[ALLOW_SCREENSHOT_KEY] === true;
});
allowScreenshots.addEventListener("change", () => {
  chrome.storage.local.set({ [ALLOW_SCREENSHOT_KEY]: allowScreenshots.checked });
});
var toolbarEffect = $("toolbarEffect");
chrome.storage.local.get(TOOLBAR_EFFECT_KEY, (r) => {
  toolbarEffect.checked = r[TOOLBAR_EFFECT_KEY] !== false;
});
toolbarEffect.addEventListener("change", () => {
  chrome.storage.local.set({ [TOOLBAR_EFFECT_KEY]: toolbarEffect.checked });
});
var langSelect = $("langSelect");
var currentUILang = "zh";
function applyTranslations() {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (key) el.textContent = t(key, currentUILang);
  });
}
chrome.storage.local.get(LANG_KEY, (r) => {
  const speechLang = r[LANG_KEY] || "zh";
  langSelect.value = speechLang;
  currentUILang = getUILang(speechLang);
  applyTranslations();
  void loadPlan();
  void initPrompts();
});
langSelect.addEventListener("change", () => {
  const speechLang = langSelect.value;
  void chrome.storage.local.set({ [LANG_KEY]: speechLang });
  const newUILang = getUILang(speechLang);
  if (newUILang === currentUILang) return;
  void chrome.storage.local.get(PROMPTS_CUSTOMIZED_KEY).then((store) => {
    const isCustomized = store[PROMPTS_CUSTOMIZED_KEY] === true;
    if (!isCustomized) {
      prompts = [...DEFAULT_PROMPTS[newUILang]];
      void chrome.storage.local.set({ [PROMPTS_KEY]: prompts });
      promptCurrent = 0;
      renderPrompt();
    }
  });
  currentUILang = newUILang;
  applyTranslations();
  void loadPlan();
});
var micToggle = $("micToggle");
var micIcon = $("micIcon");
var micMode = $("micMode");
var modeBtns = Array.from(document.querySelectorAll(".mic-mode-btn"));
var micPlan = "free";
function updateMicModeUI() {
  micMode.style.display = micPlan !== "free" && micToggle.checked ? "flex" : "none";
}
function updateMicUI() {
  micIcon.style.opacity = micToggle.checked ? "1" : "0.3";
  updateMicModeUI();
}
chrome.storage.local.get(MIC_KEY, (r) => {
  micToggle.checked = r[MIC_KEY] === true;
  updateMicUI();
});
micToggle.addEventListener("change", async () => {
  if (micToggle.checked) {
    const store = await chrome.storage.local.get(MIC_PERMISSION_KEY);
    if (!store[MIC_PERMISSION_KEY]) {
      const state = await chrome.runtime.sendMessage({ type: "GET_RECORDING_STATE" });
      if (state?.recording) {
        await chrome.storage.local.set({ [MIC_KEY]: true });
        updateMicUI();
        return;
      }
      micToggle.checked = false;
      updateMicUI();
      await chrome.runtime.sendMessage({ type: "REQUEST_MIC_PERMISSION" });
      return;
    }
  }
  await chrome.storage.local.set({ [MIC_KEY]: micToggle.checked });
  updateMicUI();
});
chrome.storage.local.get([USER_PLAN_KEY, MIC_MODE_KEY], (r) => {
  micPlan = r[USER_PLAN_KEY] || "free";
  const mode = r[MIC_MODE_KEY] || "whisper";
  modeBtns.forEach((btn) => btn.classList.toggle("active", btn.dataset.mode === mode));
  updateMicModeUI();
});
modeBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    modeBtns.forEach((b) => b.classList.toggle("active", b === btn));
    void chrome.storage.local.set({ [MIC_MODE_KEY]: btn.dataset.mode });
  });
});
var rewindBtn = $("rewindBtn");
rewindBtn.addEventListener("click", async () => {
  const label = rewindBtn.querySelector(".action-label");
  rewindBtn.disabled = true;
  if (label) label.textContent = "\u23EA \u64F7\u53D6\u4E2D...";
  try {
    const res = await send("REWIND_30S");
    if (res?.limitReached) {
      showUpgradeOverlay("rewind");
      void loadPlan();
    }
  } catch (err) {
    console.error("[BugEzy popup] rewind failed", err);
  }
  rewindBtn.disabled = false;
  if (label) label.textContent = "\u56DE\u6EAF 30s";
});
var startedAt = null;
var tick;
var uploadPoll;
function send(type) {
  return chrome.runtime.sendMessage({ type });
}
function fmt(ms) {
  const total = Math.max(0, Math.floor(ms / 1e3));
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
}
function renderElapsed() {
  if (startedAt) elapsed.textContent = fmt(Date.now() - startedAt);
}
function show(view) {
  idleView.classList.toggle("hidden", view !== "idle");
  recordingView.classList.toggle("hidden", view !== "recording");
  doneView.classList.toggle("hidden", view !== "done");
}
function stopTick() {
  if (tick !== void 0) {
    clearInterval(tick);
    tick = void 0;
  }
}
function stopUploadPoll() {
  if (uploadPoll !== void 0) {
    clearInterval(uploadPoll);
    uploadPoll = void 0;
  }
}
function renderUpload(summary) {
  if (!summary) {
    uploadStatusEl.textContent = "";
    shareUrlRow.style.display = "none";
    return;
  }
  switch (summary.uploadStatus) {
    case "uploading":
      uploadStatusEl.textContent = "\u23F3 \u6B63\u5728\u4E0A\u50B3\u5230\u96F2\u7AEF...";
      shareUrlRow.style.display = "none";
      break;
    case "success":
      uploadStatusEl.textContent = "\u2705 \u5DF2\u4E0A\u50B3";
      if (summary.shareUrl) {
        shareUrlRow.style.display = "flex";
        shareLink.href = summary.shareUrl;
        shareLink.textContent = summary.shareUrl;
      }
      break;
    case "error":
      uploadStatusEl.textContent = "\u274C \u4E0A\u50B3\u5931\u6557\uFF08\u53EF\u624B\u52D5\u532F\u51FA JSON\uFF09";
      shareUrlRow.style.display = "none";
      break;
    default:
      uploadStatusEl.textContent = "";
      shareUrlRow.style.display = "none";
  }
}
var settingsHint = $("settingsHint");
function lockSettings(locked) {
  const toggles = [
    micToggle,
    // 麥克風（標題列，錄製中仍可見 → 最關鍵）
    keyboardMode,
    monitorMode,
    allowScreenshots,
    toolbarEffect
  ];
  toggles.forEach((t2) => {
    t2.disabled = locked;
    t2.style.opacity = locked ? "0.4" : "1";
    t2.style.cursor = locked ? "not-allowed" : "pointer";
  });
  modeBtns.forEach((b) => {
    b.disabled = locked;
    b.style.opacity = locked ? "0.4" : "1";
    b.style.cursor = locked ? "not-allowed" : "pointer";
  });
  langSelect.disabled = locked;
  langSelect.style.opacity = locked ? "0.4" : "1";
  langSelect.style.cursor = locked ? "not-allowed" : "pointer";
  settingsHint.style.display = locked ? "block" : "none";
}
function render(state) {
  startedAt = state.startedAt;
  lockSettings(!!state.recording);
  if (state.recording) {
    show("recording");
    renderElapsed();
    if (tick === void 0) tick = window.setInterval(renderElapsed, 500);
    return;
  }
  stopTick();
  if (state.summary) {
    show("done");
    domCount.textContent = String(state.summary.domEvents);
    consoleCount.textContent = String(state.summary.consoleLogs);
    networkCount.textContent = String(state.summary.networkErrors);
    voiceCount.textContent = String(state.summary.voiceSegments ?? 0);
    durationVal.textContent = t("duration-sec", currentUILang, {
      n: Math.round(state.summary.durationMs / 1e3)
    });
    pageUrl.textContent = state.summary.pageInfo.url;
    renderUpload(state.summary);
    if (state.summary.uploadStatus === "uploading") {
      if (uploadPoll === void 0) {
        uploadPoll = window.setInterval(async () => {
          const fresh = await send("GET_STATE");
          renderUpload(fresh.summary);
          if (fresh.summary?.uploadStatus !== "uploading") stopUploadPoll();
        }, 1e3);
      }
    } else {
      stopUploadPoll();
    }
  } else {
    stopUploadPoll();
    show("idle");
    void updateLastScreenshot();
  }
}
async function updateLastScreenshot() {
  const r = await chrome.storage.local.get(LAST_SCREENSHOT_KEY);
  const last = r[LAST_SCREENSHOT_KEY];
  if (last?.shareUrl && Date.now() - last.timestamp < 5 * 60 * 1e3) {
    lastScreenshot.textContent = "";
    const label = document.createTextNode("\u6700\u8FD1\u622A\u5716\uFF1A");
    const a = document.createElement("a");
    a.href = last.shareUrl;
    a.target = "_blank";
    a.textContent = last.shareUrl;
    a.style.color = "#818cf8";
    lastScreenshot.append(label, a);
    lastScreenshot.style.display = "block";
  } else {
    lastScreenshot.style.display = "none";
  }
}
async function doStartRecording() {
  startBtn.disabled = true;
  try {
    const res = await send("START_RECORDING");
    if (res.limitReached) {
      setRecordDesc(t("used-up", currentUILang));
      showUpgradeOverlay("recording");
      void loadPlan();
      return;
    }
    render(res);
  } catch (err) {
    console.error("[BugEzy popup]", err);
  } finally {
    startBtn.disabled = false;
  }
}
var micPrompt = $("micPrompt");
function showMicPrompt() {
  micPrompt.style.display = "flex";
}
function hideMicPrompt() {
  micPrompt.style.display = "none";
}
startBtn.addEventListener("click", async () => {
  const store = await chrome.storage.local.get([MIC_KEY, KEYBOARD_MODE_KEY]);
  const micOn = store[MIC_KEY] === true;
  const kbOn = store[KEYBOARD_MODE_KEY] === true;
  if (!micOn && !kbOn) {
    showMicPrompt();
    return;
  }
  await doStartRecording();
});
$("micPromptOn").addEventListener("click", async () => {
  const permStore = await chrome.storage.local.get(MIC_PERMISSION_KEY);
  if (!permStore[MIC_PERMISSION_KEY]) {
    hideMicPrompt();
    await chrome.runtime.sendMessage({ type: "REQUEST_MIC_PERMISSION" });
    return;
  }
  await chrome.storage.local.set({ [MIC_KEY]: true });
  micToggle.checked = true;
  updateMicUI();
  hideMicPrompt();
  await doStartRecording();
});
$("micPromptSkip").addEventListener("click", () => {
  hideMicPrompt();
  void doStartRecording();
});
stopBtn.addEventListener("click", async () => {
  stopBtn.disabled = true;
  try {
    let state = await send("STOP_RECORDING");
    for (let i = 0; i < 20 && !state.summary; i++) {
      await new Promise((r) => setTimeout(r, 150));
      state = await send("GET_STATE");
    }
    render(state);
  } catch (err) {
    console.error("[BugEzy popup]", err);
  } finally {
    stopBtn.disabled = false;
  }
});
screenshotBtn.addEventListener("click", async () => {
  screenshotBtn.disabled = true;
  try {
    await send("CAPTURE_SCREENSHOT");
  } catch (err) {
    console.error("[BugEzy popup]", err);
    screenshotBtn.disabled = false;
  }
});
clearBtn.addEventListener("click", async () => {
  clearBtn.disabled = true;
  try {
    render(await send("CLEAR_RECORDING"));
  } catch (err) {
    console.error("[BugEzy popup]", err);
  } finally {
    clearBtn.disabled = false;
  }
});
copyBtn.addEventListener("click", async () => {
  const { payload } = await send("GET_LAST_PAYLOAD");
  if (!payload) return;
  await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
  copyBtn.textContent = "\u2705 \u5DF2\u8907\u88FD";
  copyBtn.classList.add("copied");
  setTimeout(() => {
    copyBtn.textContent = "\u{1F4CB} \u8907\u88FD JSON";
    copyBtn.classList.remove("copied");
  }, 1500);
});
copyLinkBtn.addEventListener("click", () => {
  const url = shareLink.textContent?.trim();
  if (!url) return;
  navigator.clipboard.writeText(url);
  copyLinkBtn.textContent = "\u2705 \u5DF2\u8907\u88FD";
  setTimeout(() => {
    copyLinkBtn.textContent = "\u{1F4CB} \u8907\u88FD\u9023\u7D50";
  }, 1500);
});
exportBtn.addEventListener("click", async () => {
  const { payload } = await send("GET_LAST_PAYLOAD");
  if (!payload) return;
  const d = /* @__PURE__ */ new Date();
  const p = (n) => String(n).padStart(2, "0");
  const ts = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  try {
    await chrome.downloads.download({
      url,
      filename: `bugezy-debug/payload-${ts}.json`,
      // 相對 Downloads 根；子資料夾自動建立
      saveAs: false
    });
    exportBtn.textContent = "\u2705 \u5DF2\u532F\u51FA\u5230 Downloads/bugezy-debug";
    exportBtn.classList.add("done");
    setTimeout(() => {
      exportBtn.textContent = "\u{1F4BE} \u532F\u51FA JSON\uFF08\u7D66 AI \u8B80\uFF09";
      exportBtn.classList.remove("done");
    }, 2e3);
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  }
});
async function checkAuth() {
  const r = await chrome.storage.local.get(SESSION_KEY);
  return r[SESSION_KEY] ?? null;
}
function googleLogin(interactive = true) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError || !token) {
        if (interactive) reject(new Error(chrome.runtime.lastError?.message || "login failed"));
        else resolve(null);
      } else {
        resolve(token);
      }
    });
  });
}
async function fetchGoogleProfile(token) {
  try {
    const res = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) return { name: "", picture: "", email: "" };
    const u = await res.json();
    return { name: u.name ?? "", picture: u.picture ?? "", email: u.email ?? "" };
  } catch {
    return { name: "", picture: "", email: "" };
  }
}
async function exchangeSession(googleToken, name) {
  try {
    const res = await fetch(`${API_BASE}/api/auth/session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ google_token: googleToken, name })
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error("[BugEzy popup] exchangeSession", err);
    return null;
  }
}
async function doLogin(interactive = true) {
  const googleToken = await googleLogin(interactive);
  if (!googleToken) return null;
  const profile = await fetchGoogleProfile(googleToken);
  const data = await exchangeSession(googleToken, profile.name);
  if (!data?.session_token) return null;
  const session = {
    user_id: data.user_id,
    email: data.email || profile.email,
    name: profile.name,
    avatar_url: profile.picture,
    session_token: data.session_token
  };
  await chrome.storage.local.set({
    [SESSION_KEY]: session,
    [SESSION_TOKEN_KEY]: data.session_token
  });
  return session;
}
async function refreshSessionSilently() {
  const session = await doLogin(false);
  if (session) {
    userName.textContent = session.name || session.email;
    if (session.avatar_url) userAvatar.src = session.avatar_url;
    void loadPlan();
  }
}
function showLoginView() {
  loginView.classList.remove("hidden");
  mainView.classList.add("hidden");
}
function showMainView(session) {
  loginView.classList.add("hidden");
  mainView.classList.remove("hidden");
  userName.textContent = session.name || session.email;
  if (session.avatar_url) userAvatar.src = session.avatar_url;
  send("GET_STATE").then(render).catch((e) => console.error("[BugEzy popup]", e));
  void loadPlan();
}
function fmtDate(iso) {
  return iso ? iso.slice(0, 10).replace(/-/g, "/") : "\u672C\u671F\u7D50\u675F";
}
function setActionDesc(btn, text, low = false) {
  const desc = btn.querySelector(".action-desc");
  if (!desc) return;
  desc.textContent = text;
  desc.classList.toggle("low", low);
}
function setRecordDesc(text) {
  setActionDesc(startBtn, text);
}
function renderFreeUsage(limits) {
  const setRemain = (btn, used, max) => {
    const remain = Math.max(0, max - used);
    setActionDesc(
      btn,
      remain > 0 ? t("remaining", currentUILang, { n: remain }) : t("used-up", currentUILang),
      remain <= 2
    );
  };
  setRemain(startBtn, limits.recording.used, limits.recording.max);
  setRemain(rewindBtn, limits.rewind.used, limits.rewind.max);
  setActionDesc(screenshotBtn, t("unlimited", currentUILang));
}
function showUpgradeOverlay(type) {
  const lim = freeLimits?.[type];
  const max = lim?.max ?? 0;
  const descKey = type === "recording" ? "usage-desc-record" : type === "rewind" ? "usage-desc-rewind" : "usage-desc-mcp";
  upgradeOverlayDesc.textContent = t(descKey, currentUILang, { used: max, max });
  const taiwan = isTaiwanUser();
  overlayDayPassBtn.classList.toggle("hidden", !taiwan);
  overlayMonthlyBtn.classList.toggle("hidden", !taiwan);
  overlayIntlNotice.classList.toggle("hidden", taiwan);
  upgradeOverlay.classList.remove("hidden");
}
async function loadPlan() {
  try {
    const res = await fetch(`${API_BASE}/api/user/plan`, {
      headers: await getAuthHeaders()
    });
    if (!res.ok) return;
    const plan = await res.json();
    freeLimits = plan.limits;
    currentCountry = plan.country ?? "UNKNOWN";
    void chrome.storage.local.set({ [USER_PLAN_KEY]: plan.plan });
    micPlan = plan.plan;
    updateMicModeUI();
    upgradeHint.classList.add("hidden");
    intlNotice.classList.add("hidden");
    paidBadge.classList.add("hidden");
    cancelledBadge.classList.add("hidden");
    dayPassStatus.classList.add("hidden");
    dayPassHint.classList.add("hidden");
    if (dayPassTimer !== void 0) {
      clearInterval(dayPassTimer);
      dayPassTimer = void 0;
    }
    const dayPassRemainMs = plan.day_pass_expires_at ? new Date(plan.day_pass_expires_at).getTime() - Date.now() : 0;
    const setAllUnlimited = () => {
      setActionDesc(startBtn, t("unlimited", currentUILang));
      setActionDesc(rewindBtn, t("unlimited", currentUILang));
      setActionDesc(screenshotBtn, t("unlimited", currentUILang));
    };
    if (plan.plan === "paid") {
      setAllUnlimited();
      startBtn.disabled = false;
      paidBadge.classList.remove("hidden");
    } else if (plan.plan === "cancelled") {
      setAllUnlimited();
      startBtn.disabled = false;
      expiresDate.textContent = fmtDate(plan.plan_expires_at ?? plan.expires_at);
      cancelledBadge.classList.remove("hidden");
    } else if (plan.plan === "day_pass" && dayPassRemainMs > 0) {
      setAllUnlimited();
      startBtn.disabled = false;
      showDayPassActive(dayPassRemainMs);
    } else {
      if (plan.limits) renderFreeUsage(plan.limits);
      startBtn.disabled = (plan.limits?.recording.max ?? 1) - (plan.limits?.recording.used ?? 0) <= 0;
      if (isTaiwanUser()) {
        upgradeHint.classList.remove("hidden");
      } else {
        intlNotice.classList.remove("hidden");
      }
    }
  } catch {
  }
}
async function openCheckout() {
  const session = await checkAuth();
  if (session) {
    void chrome.tabs.create({ url: "checkout.html" });
  } else {
    chrome.tabs.create({ url: `${API_BASE}/#pricing` });
  }
}
upgradeBtn.addEventListener("click", () => void openCheckout());
resubBtn.addEventListener("click", () => void openCheckout());
dayPassBtn.addEventListener("click", () => {
  void chrome.tabs.create({ url: "day-pass-checkout.html" });
});
var myReportsBtn = $("myReportsBtn");
myReportsBtn.addEventListener("click", async () => {
  const store = await chrome.storage.local.get(SESSION_TOKEN_KEY);
  const token = store[SESSION_TOKEN_KEY] || "";
  void chrome.tabs.create({ url: `${API_BASE}/reports?token=${encodeURIComponent(token)}` });
});
overlayDayPassBtn.addEventListener("click", () => {
  upgradeOverlay.classList.add("hidden");
  void chrome.tabs.create({ url: "day-pass-checkout.html" });
});
overlayMonthlyBtn.addEventListener("click", () => {
  upgradeOverlay.classList.add("hidden");
  void openCheckout();
});
upgradeOverlayClose.addEventListener("click", () => upgradeOverlay.classList.add("hidden"));
upgradeOverlay.addEventListener("click", (e) => {
  if (e.target === upgradeOverlay) upgradeOverlay.classList.add("hidden");
});
function updateCountdown(ms) {
  const clamped = Math.max(0, ms);
  const h = Math.floor(clamped / 36e5);
  const m = Math.floor(clamped % 36e5 / 6e4);
  const s = Math.floor(clamped % 6e4 / 1e3);
  dayPassCountdown.textContent = t("day-pass-remaining", currentUILang, { h, m, s });
}
function showDayPassActive(remainMs) {
  upgradeHint.classList.add("hidden");
  dayPassStatus.classList.remove("hidden");
  dayPassHint.classList.remove("hidden");
  let remain = remainMs;
  updateCountdown(remain);
  if (dayPassTimer !== void 0) clearInterval(dayPassTimer);
  dayPassTimer = window.setInterval(() => {
    remain -= 1e3;
    if (remain <= 0) {
      clearInterval(dayPassTimer);
      dayPassTimer = void 0;
      location.reload();
      return;
    }
    updateCountdown(remain);
  }, 1e3);
}
cancelSubBtn.addEventListener("click", async () => {
  const confirmed = confirm(t("confirm-cancel-sub", currentUILang));
  if (!confirmed) return;
  const session = await checkAuth();
  if (!session) return;
  try {
    const res = await fetch(`${API_BASE}/api/user/cancel`, {
      method: "POST",
      headers: await getAuthHeaders()
    });
    const data = await res.json();
    await applyRotatedToken(data);
    if (data.ok) {
      alert(data.message ?? t("alert-cancelled", currentUILang));
      void loadPlan();
    } else {
      alert(data.error ?? t("alert-cancel-fail", currentUILang));
    }
  } catch (err) {
    console.error("[BugEzy popup] cancel", err);
    alert(t("alert-cancel-fail", currentUILang));
  }
});
googleLoginBtn.addEventListener("click", async () => {
  googleLoginBtn.disabled = true;
  googleLoginBtn.textContent = t("login-loading", currentUILang);
  try {
    const session = await doLogin(true);
    if (!session) throw new Error("auth failed");
    showMainView(session);
  } catch (err) {
    console.error("[BugEzy popup] login", err);
    googleLoginBtn.disabled = false;
    googleLoginBtn.textContent = t("login-failed", currentUILang);
  }
});
logoutBtn.addEventListener("click", async () => {
  try {
    await fetch(`${API_BASE}/api/auth/logout`, { method: "POST", headers: await getAuthHeaders() });
  } catch {
  }
  await chrome.storage.local.remove([SESSION_KEY, SESSION_TOKEN_KEY]);
  chrome.identity.clearAllCachedAuthTokens(() => {
  });
  showLoginView();
});
var LAST_VERSION_KEY = "bugezy:lastVersion";
function showUpdateNotice(version) {
  const notice = document.createElement("div");
  notice.className = "update-notice";
  notice.innerHTML = `
    <div class="update-title">\u{1F389} BugEzy \u66F4\u65B0\u5230 v${version}</div>
    <div class="update-body">\u611F\u8B1D\u4F7F\u7528 BugEzy\uFF01\u6B64\u7248\u672C\u6539\u5584\u4E86\u7A69\u5B9A\u5EA6\u548C\u4F7F\u7528\u9AD4\u9A57\u3002</div>
    <button class="update-dismiss" id="dismissUpdate">\u77E5\u9053\u4E86</button>
  `;
  document.body.prepend(notice);
  document.getElementById("dismissUpdate")?.addEventListener("click", () => notice.remove());
}
async function checkVersionNotice() {
  const currentVersion = chrome.runtime.getManifest().version;
  const stored = await chrome.storage.local.get(LAST_VERSION_KEY);
  const lastVersion = stored[LAST_VERSION_KEY];
  if (lastVersion && lastVersion !== currentVersion) showUpdateNotice(currentVersion);
  await chrome.storage.local.set({ [LAST_VERSION_KEY]: currentVersion });
}
var PROMPTS_KEY = "bugezy:ai-prompts";
var PROMPTS_CUSTOMIZED_KEY = "bugezy:prompts-customized";
var DEFAULT_COLORS = ["#ef4444", "#3b82f6", "#22c55e", "#f59e0b"];
var promptPreview = $("prompt-preview");
var promptColorDot = $("prompt-color-dot");
var promptIndex = $("prompt-index");
var promptPrev = $("prompt-prev");
var promptNext = $("prompt-next");
var promptCopy = $("prompt-copy");
var promptEdit = $("prompt-edit");
var promptEditor = $("prompt-editor");
var promptTextarea = $("prompt-textarea");
var promptSave = $("prompt-save");
var promptCancel = $("prompt-cancel");
var promptCopied = $("prompt-copied");
var colorOptions = Array.from(document.querySelectorAll(".color-option"));
var prompts = [];
var promptCurrent = 0;
var editingColor = DEFAULT_COLORS[0];
function renderPrompt() {
  const item = prompts[promptCurrent];
  if (!item) return;
  promptPreview.textContent = item.text.split("\n")[0];
  promptColorDot.style.background = item.color;
  promptIndex.textContent = `${promptCurrent + 1}/${prompts.length}`;
}
function normalizePrompts(raw) {
  if (!Array.isArray(raw) || raw.length === 0) return [...DEFAULT_PROMPTS[currentUILang]];
  return raw.map((entry, i) => {
    if (typeof entry === "string") {
      return { text: entry, color: DEFAULT_COLORS[i % DEFAULT_COLORS.length] };
    }
    const obj = entry;
    return {
      text: typeof obj.text === "string" ? obj.text : "",
      color: typeof obj.color === "string" ? obj.color : DEFAULT_COLORS[i % DEFAULT_COLORS.length]
    };
  });
}
async function initPrompts() {
  const store = await chrome.storage.local.get(PROMPTS_KEY);
  prompts = normalizePrompts(store[PROMPTS_KEY]);
  promptCurrent = 0;
  renderPrompt();
}
function highlightColorOption(color) {
  colorOptions.forEach((el) => el.classList.toggle("selected", el.dataset.color === color));
}
function syncEditorToCurrentPrompt() {
  const item = prompts[promptCurrent];
  if (!item) return;
  promptTextarea.value = item.text;
  editingColor = item.color;
  highlightColorOption(editingColor);
}
function switchPrompt(direction) {
  const editing = promptEditor.style.display !== "none";
  if (editing) {
    const newText = promptTextarea.value.trim();
    if (newText && newText !== prompts[promptCurrent]?.text) {
      prompts[promptCurrent] = { text: newText, color: editingColor };
      void chrome.storage.local.set({ [PROMPTS_KEY]: prompts, [PROMPTS_CUSTOMIZED_KEY]: true });
    }
  }
  promptCurrent = (promptCurrent + direction + prompts.length) % prompts.length;
  renderPrompt();
  if (editing) syncEditorToCurrentPrompt();
}
promptPrev.addEventListener("click", () => switchPrompt(-1));
promptNext.addEventListener("click", () => switchPrompt(1));
promptCopy.addEventListener("click", async () => {
  await navigator.clipboard.writeText(prompts[promptCurrent]?.text ?? "");
  promptCopied.style.display = "inline-block";
  setTimeout(() => {
    promptCopied.style.display = "none";
  }, 2e3);
});
promptEdit.addEventListener("click", () => {
  const item = prompts[promptCurrent];
  if (!item) return;
  promptTextarea.value = item.text;
  editingColor = item.color;
  highlightColorOption(editingColor);
  promptEditor.style.display = "block";
});
colorOptions.forEach((el) => {
  el.addEventListener("click", () => {
    editingColor = el.dataset.color || DEFAULT_COLORS[0];
    highlightColorOption(editingColor);
  });
});
promptSave.addEventListener("click", async () => {
  prompts[promptCurrent] = { text: promptTextarea.value.trim(), color: editingColor };
  await chrome.storage.local.set({ [PROMPTS_KEY]: prompts, [PROMPTS_CUSTOMIZED_KEY]: true });
  promptEditor.style.display = "none";
  renderPrompt();
});
promptCancel.addEventListener("click", () => {
  promptEditor.style.display = "none";
});
var SETTINGS_OPEN_KEY = "bugezy:settings-open";
var settingsHeader = $("settings-header");
var settingsBody = $("settings-body");
var settingsChevron = $("settings-chevron");
var settingsOpen = false;
function updateSettingsUI() {
  settingsBody.style.display = settingsOpen ? "block" : "none";
  settingsChevron.classList.toggle("open", settingsOpen);
}
chrome.storage.local.get(SETTINGS_OPEN_KEY, (r) => {
  settingsOpen = r[SETTINGS_OPEN_KEY] === true;
  updateSettingsUI();
});
settingsHeader.addEventListener("click", () => {
  settingsOpen = !settingsOpen;
  void chrome.storage.local.set({ [SETTINGS_OPEN_KEY]: settingsOpen });
  updateSettingsUI();
});
async function checkNewVersion() {
  try {
    const currentVersion = chrome.runtime.getManifest().version;
    const res = await fetch(`${API_BASE}/api/version`);
    if (!res.ok) return;
    const data = await res.json();
    if (data.latest && data.latest !== currentVersion) {
      const badge = $("update-badge");
      badge.style.display = "flex";
      badge.textContent = t("update-available", currentUILang, {
        cur: currentVersion,
        new: data.latest
      });
      const url = data.changelog_url || `${API_BASE}/changelog`;
      badge.addEventListener("click", () => void chrome.tabs.create({ url }));
    }
  } catch {
  }
}
$("popup-version").textContent = `BugEzy v${chrome.runtime.getManifest().version}`;
void checkVersionNotice();
void checkNewVersion();
void checkAuth().then((session) => {
  if (session) {
    showMainView(session);
    void refreshSessionSilently();
  } else {
    showLoginView();
  }
});
//# sourceMappingURL=popup.js.map
